"""Validate actual FBX round-trips, units, nonempty meshes and clear cabins.
Run with: blender --background --python ArtSource/Blender/validate_assets.py
"""
import bpy
import json
from mathutils import Vector
from pathlib import Path

root = Path(__file__).resolve().parents[2]
manifest = json.loads((root/'ArtSource/Blender/asset_manifest.json').read_text())
results = []
ships = {'Scout','Hauler','Explorer','Courier','Salvager','Prospector'}
for name, expected in manifest['assets'].items():
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)
    path = root/'Assets/Orbita/Art/Models'/expected['file']
    assert path.exists() and path.stat().st_size > 4096, str(path)
    bpy.ops.import_scene.fbx(filepath=str(path))
    objects = [o for o in bpy.context.scene.objects if o.type == 'MESH']
    assert len(objects) == expected['meshes'], name+' mesh count differs'
    points = [o.matrix_world @ v.co for o in objects for v in o.data.vertices]
    pts = [(p.x,p.z,-p.y) for p in points]
    mins = [min(p[i] for p in pts) for i in range(3)]
    maxs = [max(p[i] for p in pts) for i in range(3)]
    exp = expected['bounds_unity_authoring']
    error = max(abs(a-b) for a,b in zip(mins+maxs,exp['min']+exp['max']))
    assert error < .035, (name,'bounds error',error,mins,maxs,exp)
    if name in ships:
        # Test each whole mesh AABB, so a wall spanning the cabin is detected
        # even when its individual corner vertices fall outside the corridor.
        lower, upper = (-3.45,1.01,-6.95), (3.45,4.49,6.95)
        for obj in objects:
            world = [obj.matrix_world @ v.co for v in obj.data.vertices]
            local = [(p.x,p.z,-p.y) for p in world]
            lo = [min(p[i] for p in local) for i in range(3)]
            hi = [max(p[i] for p in local) for i in range(3)]
            intersects = all(lo[i] < upper[i] and hi[i] > lower[i] for i in range(3))
            assert not intersects, (name,'interior geometry',obj.name,lo,hi)
    results.append({'name':name,'meshes':len(objects),'bounds_error_m':round(error,6),'dimensions_m':[round(b-a,3) for a,b in zip(mins,maxs)],'cabin_clear':True if name in ships else None})
    print('PASS',name,results[-1])
(root/'ArtSource/Blender/validation_report.json').write_text(json.dumps(results,indent=2)+'\n')
print('PASS: all 14 FBX files imported, metre scale retained, all six cabins clear.')

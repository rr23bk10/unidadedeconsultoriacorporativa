"""Orbit Frontier original art. Blender 4.3+, no external add-ons or textures.

Run: blender --background --python ArtSource/Blender/build_assets.py
Authoring helpers accept Unity coordinates (X right, Y up, Z bow/forward), metres.
FBX is exported with -Z forward / Y up and applied object transforms.
"""
import bpy
import json
import math
from mathutils import Vector
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'ArtSource' / 'Blender'
OUTPUT = ROOT / 'Assets' / 'Orbita' / 'Art' / 'Models'
OUTPUT.mkdir(parents=True, exist_ok=True)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
for collection in list(bpy.data.collections):
    if collection.name != 'Collection': bpy.data.collections.remove(collection)
scene = bpy.context.scene
bpy.context.preferences.filepaths.save_version = 0
scene.unit_settings.system = 'METRIC'
scene.unit_settings.scale_length = 1.0

def mat(name, color, metallic=0.0, roughness=0.45, emission=0.0):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1.0)
    m.use_nodes = True
    p = m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value = (*color, 1.0)
    p.inputs['Metallic'].default_value = metallic
    p.inputs['Roughness'].default_value = roughness
    if emission:
        p.inputs['Emission Color'].default_value = (*color, 1.0)
        p.inputs['Emission Strength'].default_value = emission
    return m

M = {
 'HullIvory': mat('HullIvory', (.72,.78,.78), .62,.32),
 'HullGraphite': mat('HullGraphite', (.038,.055,.075), .72,.37),
 'PanelSteel': mat('PanelSteel', (.22,.29,.34), .8,.33),
 'GlassTeal': mat('GlassTeal', (.025,.20,.26), .82,.16),
 'EngineCyan': mat('EngineCyan', (.10,.88,1.0), .2,.22,3),
 'SignalAmber': mat('SignalAmber', (1.0,.48,.045), .2,.26,2),
 'SignalRed': mat('SignalRed', (1.0,.055,.022), .25,.3,2),
 'ScoutTeal': mat('ScoutTeal', (.04,.54,.57), .45,.36),
 'HaulerAmber': mat('HaulerAmber', (.90,.42,.07), .5,.39),
 'ExplorerBlue': mat('ExplorerBlue', (.075,.27,.70), .5,.34),
 'CourierRed': mat('CourierRed', (.74,.075,.045), .48,.33),
 'SalvagerYellow': mat('SalvagerYellow', (.92,.69,.065), .5,.40),
 'ProspectorPurple': mat('ProspectorPurple', (.42,.19,.66), .52,.36),
 'AstronautFabric': mat('AstronautFabric', (.62,.66,.65), .05,.75),
 'VisorGold': mat('VisorGold', (.88,.52,.16), .88,.13),
 'DustStone': mat('DustStone', (.22,.20,.18), .05,.92),
 'CityConcrete': mat('CityConcrete', (.38,.43,.46), .22,.7),
}
ASSETS = {}
CURRENT = None

def cv(p): return Vector((p[0], -p[2], p[1]))

def put(obj, name, material):
    obj.name = name
    for c in list(obj.users_collection): c.objects.unlink(obj)
    CURRENT.objects.link(obj)
    if material: obj.data.materials.append(M[material])
    return obj

def begin(name):
    global CURRENT
    CURRENT = bpy.data.collections.new(name)
    scene.collection.children.link(CURRENT)
    ASSETS[name] = CURRENT

def finish_mesh(obj, bevel=0):
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    if bevel:
        mod = obj.modifiers.new('Manufactured edge radius', 'BEVEL')
        mod.width = bevel
        mod.segments = 2
        mod.affect = 'EDGES'
        bpy.ops.object.modifier_apply(modifier=mod.name)
        for polygon in obj.data.polygons: polygon.use_smooth = True
        normal = obj.modifiers.new('Weighted face normals','WEIGHTED_NORMAL')
        normal.keep_sharp = True
        bpy.ops.object.modifier_apply(modifier=normal.name)
    return obj

def box(name, pos, size, material, bevel=.07):
    bpy.ops.mesh.primitive_cube_add(size=1, location=cv(pos))
    obj = put(bpy.context.object, name, material)
    obj.dimensions = (size[0],size[2],size[1])
    return finish_mesh(obj, bevel)

def ellipsoid(name, pos, size, material, subdivisions=2):
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=subdivisions, radius=1, location=cv(pos))
    obj = put(bpy.context.object, name, material)
    obj.scale = (size[0]/2,size[2]/2,size[1]/2)
    finish_mesh(obj)
    for p in obj.data.polygons: p.use_smooth=True
    return obj

def cylinder(name,pos,radius,length,material,axis=(0,1,0),vertices=12,radius_top=None):
    bpy.ops.mesh.primitive_cone_add(vertices=vertices,radius1=radius,radius2=radius if radius_top is None else radius_top,depth=length,location=cv(pos))
    obj=put(bpy.context.object,name,material)
    obj.rotation_mode='QUATERNION'
    obj.rotation_quaternion=Vector((0,0,1)).rotation_difference(cv(axis).normalized())
    return finish_mesh(obj,.035 if radius>.15 else 0)

def beam(name,a,b,radius,material,vertices=8):
    va,vb=Vector(a),Vector(b)
    return cylinder(name,(va+vb)/2,radius,(vb-va).length,material,vb-va,vertices)

def wedge(name,points,y_low,y_high,material):
    verts=[tuple(cv((x,y,z))) for y in [y_low,y_high] for x,z in points]
    n=len(points)
    faces=[tuple(reversed(range(n))),tuple(range(n,n*2))]
    faces += [(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    mesh=bpy.data.meshes.new(name)
    mesh.from_pydata(verts,[],faces)
    mesh.update()
    obj=bpy.data.objects.new(name,mesh)
    CURRENT.objects.link(obj)
    obj.data.materials.append(M[material])
    return finish_mesh(obj,.055)

def torus(name,pos,major,minor,material,rotation=None):
    bpy.ops.mesh.primitive_torus_add(major_segments=32,minor_segments=8,location=cv(pos),major_radius=major,minor_radius=minor)
    obj=put(bpy.context.object,name,material)
    if rotation: obj.rotation_euler=rotation
    for p in obj.data.polygons:p.use_smooth=True
    return obj

def engine(x,z,scale=1,color='EngineCyan'):
    cylinder('Drive shell',(x,2.3,z),.90*scale,4.5*scale,'PanelSteel',(0,0,1),16)
    cylinder('Drive forward armor',(x,2.3,z+2.2*scale),.97*scale,.5*scale,'HullIvory',(0,0,1),16,.72*scale)
    cylinder('Drive exit ring',(x,2.3,z-2.25*scale),1.0*scale,.40*scale,'HullGraphite',(0,0,1),16)
    cylinder('Drive luminous core',(x,2.3,z-2.48*scale),.65*scale,.08*scale,color,(0,0,1),16)
    for dx in [-.55,.55]: box('Engine spine',(x+dx*scale,2.95*scale,z),(.15,.18,2.9*scale),'HullGraphite',.035)

def base_ship(name,accent):
    begin(name)
    # The shared habitable clearance is x +-3.5, y 1..4.5, z +-7.
    box('Cabin belly',(0,.15,0),(8.6,.52,15.6),'HullGraphite',.13)
    wedge('Keel foreplate',[(-4.3,6.9),(4.3,6.9),(2.6,10),(-2.6,10)],-.05,.50,'HullIvory')
    box('Aft boarding threshold',(0,.30,-8),(4.4,.24,1.5),'PanelSteel')
    for side in [-1,1]:
        x=side*4.25
        box('Lower armored sill',(x,1.0,-.2),(.7,1.35,14.6),'HullIvory',.16)
        box('Colored broadside',(side*4.63,1.45,-.5),(.10,.28,13.3),accent,.025)
        for z in [-5.7,-1.4,3.1,6.5]:
            box('Structural rib',(x,3.0,z),(.40,3.6,.30),'PanelSteel')
        # Glazing stays outside the walkable volume. Gaps are deliberate doors.
        for z in [-3.5,1.0,5.0]:
            box('Side pressure window',(side*4.25,3.05,z),(.20,1.6,2.4),'GlassTeal',.035)
            box('Window header',(side*4.25,4.00,z),(.28,.15,2.6),accent,.03)
        box('Roof edge',(x,4.9,0),(.7,.32,15.0),'HullIvory')
        wedge('Dorsal pressure shell',[(side*2.3,-5.8),(side*4.5,-6.7),(side*4.5,6.5),(side*3.2,7.4),(side*2.3,4.6)],5.0,5.28,'HullIvory')
        box('Dorsal utility spine',(side*3.55,5.39,-.3),(.45,.16,7.7),accent,.035)
        for z in [-3.0,-1.8,-.6,.6]:
            box('Thermal vent',(side*3.15,5.435,z),(.48,.035,.14),'HullGraphite',.012)
        box('Dorsal luminous strip',(x,5.10,1.4),(.11,.04,7),'EngineCyan',.02)
        box('Nose light',(side*3.4,1.05,8.8),(.65,.22,.2),'EngineCyan')
        for z in [-5.9,5.5]:
            beam('Landing strut',(side*3.7,.25,z),(side*4.7,-.75,z),.14,'PanelSteel')
            box('Landing pad',(side*4.7,-.83,z),(1.3,.18,1.9),'HullGraphite')
    # Partial roof only; the interior is readable in external view.
    box('Aft transverse beam',(0,4.94,-6.8),(8.0,.28,.65),'HullIvory')
    box('Forward roof brow',(0,4.94,6.6),(8.0,.28,1.0),accent)
    box('Cockpit glass',(0,3.0,8.25),(5.8,1.8,.24),'GlassTeal',.08)
    box('Cockpit upper frame',(0,4.02,8.25),(6.0,.16,.4),'PanelSteel')
    for x in [-2.95,0,2.95]: box('Cockpit mullion',(x,3.0,8.30),(.12,2.0,.30),'HullIvory',.025)
    box('Aft port marker',(-4.35,3.7,-7.45),(.22,.20,.20),'SignalRed')
    box('Aft starboard marker',(4.35,3.7,-7.45),(.22,.20,.20),'EngineCyan')

base_ship('Scout','ScoutTeal')
for s in [-1,1]:
    wedge('Swept reconnaissance wing',[(s*4.5,-4),(s*7.0,-7),(s*6.1,2),(s*4.5,5)],1.1,1.5,'ScoutTeal')
    engine(s*5.7,-5.4,.85)
    box('Wing beacon',(s*6.8,1.55,-5),(.14,.10,1.7),'EngineCyan')
beam('Scanner antenna',(4.3,5.1,2.7),(4.3,6.4,2.7),.055,'PanelSteel')
ellipsoid('Scanner radome',(4.3,6.4,2.7),(.75,.55,.75),'HullIvory')

base_ship('Hauler','HaulerAmber')
for s in [-1,1]:
    box('Freight pod frame',(s*5.9,2.1,-.3),(2.7,3.3,13),'PanelSteel',.22)
    for z in [-4.1,0,4.1]:
        box('Sealed freight module',(s*6,2.2,z),(2.9,2.8,3.7),'HaulerAmber',.13)
        for y in [1.15,3.3]:box('Container band',(s*7.48,y,z),(.10,.19,3.3),'HullGraphite',.02)
        box('Freight latch',(s*7.5,2.1,z),(.1,.6,.4),'HullIvory')
    engine(s*5.8,-7.9,1.08)
    box('Cargo lift rail',(s*3.1,5.24,0),(.25,.3,12),'HaulerAmber')

base_ship('Explorer','ExplorerBlue')
for s in [-1,1]:
    wedge('Long range outrigger',[(s*4.5,-6),(s*7.7,-7),(s*7.0,5),(s*4.5,6)],.8,1.15,'ExplorerBlue')
    engine(s*6.3,-5.9,.94)
    cylinder('Survey antenna mast',(s*6.8,3.5,4),.12,4.5,'PanelSteel')
    cylinder('Survey dish',(s*6.8,5.7,4),1.4,.32,'HullIvory',(0,1,0),20,.5)
    ellipsoid('Survey focal receiver',(s*6.8,6.2,4),(.25,.4,.25),'EngineCyan')
    box('Sensor pod',(s*5.7,2.3,6.8),(1.8,1.8,3.5),'ExplorerBlue',.2)
    for z in [-3,0,3]:box('Blue solar cell',(s*7.2,1.35,z),(.8,.12,2.4),'GlassTeal',.015)

base_ship('Courier','CourierRed')
for s in [-1,1]:
    wedge('Racing needle',[(s*3.9,5),(s*4.45,13),(s*5.25,3),(s*7.0,-8),(s*4.4,-5)],.65,1.15,'CourierRed')
    engine(s*5.55,-7.5,1.18)
    box('Velocity stripe',(s*4.78,1.27,4.3),(.13,.08,9.3),'HullIvory',.018)
    fin=box('Racing vertical stabilizer',(s*5.7,4.2,-6.5),(.20,4.2,3.9),'CourierRed',.05)
    box('Racing fin inset',(s*5.84,4.5,-6.7),(.03,1.7,1.6),'HullIvory',.01)
    box('Cooling radiator',(s*4.8,2.7,-2.2),(.38,1.7,3.0),'HullGraphite')

base_ship('Salvager','SalvagerYellow')
for s in [-1,1]:
    engine(s*5.7,-6.3,.90,'SignalAmber')
    box('Salvage arm shoulder',(s*5.2,2.0,4.7),(1.8,2.5,3),'SalvagerYellow',.16)
    beam('Tow arm',(s*5.4,2.0,5.6),(s*7.1,2.0,10),.42,'SalvagerYellow')
    beam('Tow arm piston',(s*5.6,2.55,5.7),(s*6.8,2.55,9.1),.13,'PanelSteel')
    beam('Claw outer',(s*7.1,2.0,10),(s*6.5,2.0,12),.23,'PanelSteel')
    beam('Claw hook',(s*6.5,2.0,12),(s*5.2,2.0,12),.22,'SalvagerYellow')
    cylinder('Electromagnetic jaw',(s*5.5,2.0,12),.55,.35,'EngineCyan',(0,0,1))
    for z in [-4,-1,2]:box('Work hazard band',(s*4.67,1.7,z),(.08,.5,.35),'HullGraphite',.02)
    cylinder('Recovery winch',(s*5.6,3.9,-1.7),.78,1.6,'PanelSteel',(1,0,0),16)
    box('Work spotlight',(s*4.4,5.18,6.2),(.62,.35,.5),'SignalAmber')

base_ship('Prospector','ProspectorPurple')
for s in [-1,1]:
    engine(s*5.7,-6.3,.86)
    box('Ore hopper',(s*5.85,2.0,-.1),(2.5,2.8,8.8),'ProspectorPurple',.2)
    box('Hopper top',(s*5.85,3.5,-.1),(2.7,.15,9),'PanelSteel')
    for z in [-3.4,-1.0,1.4,3.8]:box('Ore hopper ribs',(s*7.15,2.0,z),(.10,3.0,.20),'HullIvory',.015)
    cylinder('Drill support',(s*5.8,2.1,6.3),.62,4.0,'PanelSteel',(0,0,1),12)
    cylinder('Mining auger',(s*5.8,2.1,9.5),1.00,3.0,'PanelSteel',(0,0,1),12,.12)
    for z,r in [(8.5,.98),(9.2,.7),(9.9,.47)]:
        cylinder('Auger tungsten cutting ring',(s*5.8,2.1,z),r,.16,'SignalAmber',(0,0,1),10)
    ellipsoid('Ore sensor',(s*4.3,5.25,4.4),(.75,.6,.75),'ProspectorPurple')

begin('Astronaut')
ellipsoid('Pressure torso',(0,1.12,0),(.60,.68,.37),'AstronautFabric',3)
box('Chest armor',(0,1.18,.20),(.43,.39,.10),'HullIvory',.05)
box('Chest control',(0,1.18,.26),(.23,.16,.05),'HullGraphite',.02)
for x in [-.06,.03,.10]:box('Suit telemetry',(x,1.2,.294),(.035,.06,.025),'EngineCyan',.01)
ellipsoid('Hip armor',(0,.79,0),(.52,.30,.36),'HullGraphite')
ellipsoid('Helmet',(0,1.66,0),(.50,.50,.47),'HullIvory',3)
ellipsoid('Gold polarized visor',(0,1.69,.19),(.40,.31,.17),'VisorGold',3)
cylinder('Helmet collar',(0,1.435,0),.20,.09,'PanelSteel',vertices=16)
box('Life support pack',(0,1.15,-.25),(.43,.55,.25),'PanelSteel',.06)
for x in [-.16,.16]:cylinder('Oxygen bottle',(x,1.16,-.43),.075,.47,'HullIvory')
for s in [-1,1]:
    ellipsoid('Shoulder',(s*.35,1.34,0),(.27,.29,.30),'HaulerAmber')
    beam('Upper arm',(s*.35,1.27,0),(s*.47,1.05,.03),.105,'AstronautFabric',12)
    ellipsoid('Elbow',(s*.475,1.02,.03),(.22,.19,.22),'HullGraphite')
    beam('Forearm',(s*.49,.98,.03),(s*.53,.77,.06),.10,'AstronautFabric',12)
    ellipsoid('Glove',(s*.53,.73,.07),(.18,.22,.19),'HullGraphite')
    beam('Thigh',(s*.15,.73,0),(s*.165,.46,.015),.125,'AstronautFabric',12)
    box('Knee guard',(s*.17,.46,.105),(.20,.18,.13),'HaulerAmber',.055)
    beam('Shin',(s*.17,.41,0),(s*.19,.17,.03),.10,'AstronautFabric',12)
    box('Magnetic boot',(s*.19,.105,.10),(.24,.21,.43),'HullGraphite',.055)

begin('CityTower')
box('Tower foundation',(0,.4,0),(9,.8,9),'PanelSteel',.2)
box('Monolithic tower',(0,12,0),(6.8,23,6.8),'CityConcrete',.25)
box('Stepped crown',(0,25,0),(4.5,3.5,4.5),'HullGraphite',.12)
for y in range(3,24,3):
    for s in [-1,1]:
        box('Illuminated facade',(s*3.44,y,0),(.06,.65,5.6),'EngineCyan',.015)
        box('Illuminated facade',(0,y,s*3.44),(5.6,.65,.06),'EngineCyan',.015)
for x in [-3.5,3.5]:
    for z in [-3.5,3.5]:box('External tower rib',(x,12,z),(.40,24,.40),'PanelSteel')
cylinder('Communication mast',(0,29,0),.13,6,'PanelSteel')
ellipsoid('Aircraft warning light',(0,32,0),(.40,.40,.40),'SignalAmber')

begin('IndustrialRig')
box('Mining platform',(0,2,0),(12,.60,10),'PanelSteel',.15)
for x in [-4.8,4.8]:
    for z in [-3.8,3.8]:
        box('Pylon',(x,.9,z),(.65,2.1,.65),'SalvagerYellow')
        box('Foundation',(x,.1,z),(1.8,.2,1.8),'HullGraphite')
for x in [-3.7,3.7]:
    box('Gantry column',(x,6.2,0),(.75,8,.75),'SalvagerYellow')
    for y in [3,5,7]:beam('Gantry cross brace',(x,y,-3),(x,y+2,0),.12,'PanelSteel')
box('Overhead beam',(0,10.1,0),(9,.8,1.0),'SalvagerYellow')
cylinder('Central drilling mast',(0,6.1,0),.52,7,'PanelSteel')
cylinder('Drill bit',(0,1.1,0),.7,2.1,'PanelSteel',radius_top=.25)
for z in [-3,3]:
    box('Equipment skid',(-3,3.0,z),(2.3,1.3,2.2),'HullGraphite')
    cylinder('Refinery tank',(3,4,z),1.05,3.4,'HullIvory',vertices=20)
    torus('Tank reinforcement',(3,4.7,z),1.06,.08,'HaulerAmber')

begin('RuinArch')
for s in [-1,1]:
    box('Ancient plinth',(s*3.8,.40,0),(2.4,.8,3),'DustStone',.16)
    box('Ancient pillar',(s*3.8,4.4,0),(1.6,7.4,1.9),'DustStone',.13)
    for y in [2,4,6]:box('Lost inscription',(s*3.8,y,1.00),(.65,.12,.06),'EngineCyan',.01)
for i in range(9):
    a=(i+.5)*math.pi/9
    x,y=3.8*math.cos(a),7.8+3.8*math.sin(a)
    obj=box('Radial arch stone',(x,y,0),(1.7,1.0,1.9),'DustStone',.12)
    obj.rotation_euler[1]=-a
box('Threshold slab',(0,.1,0),(6,.2,2.6),'DustStone',.08)

begin('Station')
cylinder('Orbital hub',(0,0,0),7.0,9.5,'HullIvory',vertices=24)
cylinder('Dorsal observatory',(0,6.6,0),4.4,3.6,'GlassTeal',vertices=24)
torus('Habitat pressure ring',(0,0,0),20,3.2,'HullIvory')
torus('Habitat blue stripe',(0,.25,0),23.18,.16,'ExplorerBlue')
torus('Ring navigational lights',(0,.5,0),23.25,.055,'EngineCyan')
for a in [0,math.pi/2,math.pi,math.pi*1.5]:
    x,z=math.cos(a),math.sin(a)
    beam('Pressurized spoke',(x*5,0,z*5),(x*19,0,z*19),1.2,'PanelSteel',12)
    box('Docking pier',(x*28,-1,z*28),(5,1,10),'HullGraphite',.12)
    cylinder('Docking marker',(x*26,1,z*26),.5,1.8,'EngineCyan')
for s in [-1,1]:
    box('Solar support',(s*13,7,0),(18,.3,.3),'PanelSteel')
    for z in [-4,4]:box('Photovoltaic array',(s*16,7,z),(12,.12,5.8),'GlassTeal')

begin('Crate')
box('Sealed salvage case',(0,.65,0),(1.4,1.3,1.2),'HaulerAmber',.10)
for x in [-.5,.5]:box('Case binding',(x,.66,0),(.12,1.36,1.27),'PanelSteel',.025)
box('Shipping identifier',(0,.75,.615),(.45,.27,.035),'HullIvory',.01)
box('Case latch',(0,.62,.65),(.22,.19,.07),'HullGraphite',.01)

begin('Asteroid')
rock=ellipsoid('Irregular asteroid',(0,0,0),(12,9,10),'DustStone',3)
for vert in rock.data.vertices:
    noise=math.sin(vert.co.x*2.71+vert.co.z*1.3)*math.cos(vert.co.y*3.3)
    vert.co*=1+noise*.14
for pos in [(2,3.3,1),(-3,1.8,2),(1.3,-2.8,2.1)]:ellipsoid('Exposed ore seam',pos,(1.8,.65,1.4),'SignalAmber',1)

begin('Beacon')
box('Survey beacon base',(0,.16,0),(1.2,.32,1.2),'PanelSteel')
cylinder('Survey transmitter',(0,1.4,0),.15,2.7,'HullIvory')
ellipsoid('Survey signal',(0,2.9,0),(.40,.65,.40),'EngineCyan')
for a in [0,2.094,4.188]:beam('Beacon tripod',(0,1.1,0),(math.cos(a)*.7,.1,math.sin(a)*.7),.045,'HaulerAmber')

def bounds(collection):
    vertices=[obj.matrix_basis@v.co for obj in collection.objects if obj.type=='MESH' for v in obj.data.vertices]
    mini=Vector(tuple(min(v[i] for v in vertices) for i in range(3)))
    maxi=Vector(tuple(max(v[i] for v in vertices) for i in range(3)))
    return {'min':[round(mini.x,4),round(mini.z,4),round(-maxi.y,4)],'max':[round(maxi.x,4),round(maxi.z,4),round(-mini.y,4)]}

manifest={'generator':'Blender '+bpy.app.version_string,'units':'metres','authoring':'Unity X right, Y up, +Z bow; Blender source X right, Z up, -Y bow','fbx_axes':{'forward':'-Z','up':'Y'},'interior_clearance':{'min':[-3.5,1,-7],'max':[3.5,4.5,7]},'materials':{n:{'base_color':list(m.diffuse_color),'metallic':m.node_tree.nodes['Principled BSDF'].inputs['Metallic'].default_value,'roughness':m.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value,'emission':m.node_tree.nodes['Principled BSDF'].inputs['Emission Strength'].default_value} for n,m in M.items()},'assets':{}}
for name,collection in ASSETS.items():
    bpy.ops.object.select_all(action='DESELECT')
    for obj in collection.objects:obj.select_set(True)
    manifest['assets'][name]={'file':name+'.fbx','bounds_unity_authoring':bounds(collection),'meshes':len(collection.objects),'triangles':sum(len(p.vertices)-2 for o in collection.objects if o.type=='MESH' for p in o.data.polygons)}
    bpy.context.view_layer.objects.active=next(iter(collection.objects))
    bpy.ops.export_scene.fbx(filepath=str(OUTPUT/(name+'.fbx')),use_selection=True,object_types={'MESH'},apply_unit_scale=True,apply_scale_options='FBX_SCALE_UNITS',bake_space_transform=True,axis_forward='-Z',axis_up='Y',use_mesh_modifiers=True,mesh_smooth_type='FACE',use_tspace=False,add_leaf_bones=False,bake_anim=False,path_mode='AUTO')
(SOURCE/'asset_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Keep the authoritative source models at the origin in separate collections.
for collection in ASSETS.values():collection.hide_render=True;collection.hide_viewport=True
bpy.ops.wm.save_as_mainfile(filepath=str(SOURCE/'orbita_assets.blend'))

# A composed fleet contact sheet is an additional scene within the source file.
preview=bpy.data.collections.new('Fleet presentation')
scene.collection.children.link(preview)
CURRENT=preview
names=['Scout','Hauler','Explorer','Courier','Salvager','Prospector']
labels=['01  PIONEIRA / RECON','02  ATLAS / CARGA','03  HORIZONTE / EXPLORACAO','04  VETOR / VELOCIDADE','05  IMA / SALVAMENTO','06  SONDA / MINERACAO']
for i,name in enumerate(names):
    px=(i%3-1)*29
    pz=(i//3)*38-15
    inst=bpy.data.objects.new(name+' collection display',None)
    inst.instance_type='COLLECTION';inst.instance_collection=ASSETS[name]
    preview.objects.link(inst)
    inst.location=cv((px,1.0,pz))
    # Hidden collections can still be instanced with their objects visible.
    ASSETS[name].hide_render=False
    ASSETS[name].hide_viewport=False
    scene.collection.children.unlink(ASSETS[name])
    box('Display plinth '+name,(px,-1,pz),(24,.35,31),'HullGraphite',.25)
    curve=bpy.data.curves.new('Label '+name,'FONT');curve.body=labels[i];curve.size=.77;curve.extrude=.008
    label=bpy.data.objects.new('Label '+name,curve);preview.objects.link(label)
    label.location=cv((px-10,-.79,pz+13.6));label.rotation_euler=(0,0,0)
    label.data.materials.append(M['EngineCyan'])

box('Presentation floor',(0,-1.7,0),(200,.35,180),'PanelSteel',0)
world=bpy.data.worlds.new('Studio atmosphere');world.use_nodes=True
world.node_tree.nodes['Background'].inputs[0].default_value=(.028,.04,.07,1)
world.node_tree.nodes['Background'].inputs[1].default_value=.38
scene.world=world
def area(name,pos,power,size,color):
    data=bpy.data.lights.new(name,'AREA');data.energy=power;data.shape='DISK';data.size=size;data.color=color
    obj=bpy.data.objects.new(name,data);preview.objects.link(obj);obj.location=cv(pos)
    obj.rotation_euler=(Vector((0,0,0))-obj.location).to_track_quat('-Z','Y').to_euler()
area('Key softbox',(-18,65,20),100000,65,(.78,.88,1))
area('Warm rim',(30,30,-42),75000,40,(1,.70,.40))
area('Cool fill',(-45,25,-15),60000,45,(.25,.70,1))
camera_data=bpy.data.cameras.new('Fleet camera');camera=bpy.data.objects.new('Fleet camera',camera_data);preview.objects.link(camera)
camera.location=cv((48,97,106));target=cv((0,0,4))
camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler()
camera_data.type='ORTHO';camera_data.ortho_scale=116
scene.camera=camera
scene.render.engine='CYCLES';scene.cycles.samples=48;scene.cycles.use_denoising=False
scene.render.resolution_x=1800;scene.render.resolution_y=1350;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.filepath=str(SOURCE/'fleet_preview.png')
scene.view_settings.view_transform='AgX'
bpy.ops.wm.save_as_mainfile(filepath=str(SOURCE/'orbita_assets.blend'))
bpy.ops.render.render(write_still=True)
print('ORBІTA ASSETS COMPLETE: '+str(len(ASSETS))+' FBX files at '+str(OUTPUT))

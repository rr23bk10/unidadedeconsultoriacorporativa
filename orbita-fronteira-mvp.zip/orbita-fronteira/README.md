# Órbita: Fronteira

Protótipo de um jogo 3D de exploração espacial para **Unity 6 LTS / Windows 64 bits**, com arte original produzida no **Blender 4.3.2**.

O código implementa o percurso Nova Terra → embarque físico → decolagem → Colônia Industrial → entrega → retorno e recompensa. Há um segundo percurso de pistas entre destroços e o planeta inexplorado, seis classes de nave, economia, tripulação e persistência local.

**Estado da entrega:** projeto-fonte e assets preparados. Os testes de regras e a validação dos modelos foram executados. A importação, a compilação e a execução no Unity ainda não foram verificadas: o ambiente de criação não dispõe do Unity Editor ativado. Não há um `.exe` validado neste pacote. O roteiro abaixo e o menu de build estão incluídos para concluir essa etapa no Windows.

## Abrir e jogar

1. Instale o **Unity Hub** e o Editor **6000.0.62f1** com suporte a build Windows. Ative sua licença **Unity Personal**, conforme as condições da Unity. Não coloque credenciais em arquivos do projeto.
2. No Hub, use **Add / Add project from disk** e selecione a pasta que contém este README, `Assets`, `Packages` e `ProjectSettings`.
3. Aguarde o Package Manager resolver **URP 17.0.3** e **AI Navigation 2.0.5** e o Editor importar os FBX. Os pacotes são obtidos dos serviços oficiais da Unity.
4. Use **Orbita → Preparar projeto e Play**. O preparo cria os materiais URP e 14 prefabs de modelos, preservando os assets que já existirem, abre `Assets/Orbita/Scenes/Bootstrap.unity` e inicia o jogo.
5. Vá ao terminal **CONTRATOS DA FRONTEIRA**, aceite a entrega e siga o [roteiro completo de playtest](Docs/PLAYTEST.md).

A primeira execução começa com 1.200 créditos e a nave Pioneira abastecida. O mundo é construído ao entrar em Play; a cena Bootstrap vazia no modo de edição é intencional.

## Controles

| Contexto | Teclas |
|---|---|
| A pé | WASD, Shift para correr, mouse para olhar, E para interagir |
| Nave | W/S avançar e recuar, A/D guinar, Q/E descer e subir |
| Câmera da nave | Mouse para orbitar |
| Operação | F navegação/decolagem, L pouso, X sair da cadeira |
| Exploração | R sensores, G recuperar alvos próximos durante o voo |
| Menus | Tab diário, Esc menu, F5 salvar |

O jogador permanece fisicamente no referencial da nave. Ao sair da cadeira em voo, o estabilizador reduz a velocidade e a porta externa permanece fechada. O interior tem piso, paredes, carga, beliches e rampa de embarque.

## Seis naves

| Classe | Nome | Função |
|---|---|---|
| Scout | Pioneira | Reconhecimento, nave inicial equilibrada |
| Hauler | Atlas | Transporte, porão de 48 unidades |
| Explorer | Horizonte | Sensores e autonomia |
| Courier | Vetor | A mais rápida, porão pequeno e maior consumo |
| Salvager | Ímã | Recuperação de sucata com rendimento dobrado |
| Prospector | Sonda | Sensores longos e extração de três unidades de minério por operação |

![Frota modelada e renderizada no Blender; não é captura do jogo](ArtSource/Blender/fleet_preview.png)

As seis classes têm cascos e equipamentos visuais distintos. O protótipo compartilha o módulo interno caminhável; interiores com plantas próprias e expansão física do porão ficam na próxima etapa.

## Gerar o executável Windows

No Editor ativado, use **Orbita → Build Windows64**. A saída é `Builds/Windows/OrbitaFronteira.exe`.

Também há um comando de build em lote, com o Editor fechado:

```powershell
.\Tools\Build-Windows.ps1
# Para outra instalação:
.\Tools\Build-Windows.ps1 -UnityEditor "D:\Unity\6000.0.62f1\Editor\Unity.exe"
```

Distribua **a pasta `Builds/Windows` inteira**, não apenas o executável. Os logs ficam em `Logs/build-windows.log`. Falhas de licença, importação, compilação ou build são reportadas; o script não as considera sucesso.

## Validação e documentação

- [Arquitetura e dez decisões iniciais](Docs/ARCHITECTURE.md)
- [Percurso de validação manual no Unity](Docs/PLAYTEST.md)
- [Estado dos testes e limitações](Docs/VALIDATION.md)
- [Próximas etapas e recursos ainda pendentes](Docs/ROADMAP.md)
- [Fonte Blender, exportação e orçamento dos modelos](Docs/ASSETS.md)

Para repetir os **23 testes do domínio** com .NET SDK 8:

```sh
dotnet run --project Tests/Domain/Orbita.Domain.Tests.csproj --configuration Release
```

Para verificar sintaxe C# e integridade das referências de assets, sem executar Unity:

```sh
python3 Tools/prepare_source_project.py
dotnet run --project Tools/SourceCheck/SourceCheck.csproj --configuration Release -- .
```

Para reproduzir os modelos e a prancha no Blender:

```sh
blender --background --python ArtSource/Blender/build_assets.py
blender --background --python ArtSource/Blender/validate_assets.py
```

## Limites do protótipo

Os planetas têm distritos ou áreas exploráveis de 500 m, com cenário orbital e transições de setor. O personagem é um modelo estático, sem esqueleto nem animação final; diálogos são textuais. Há um contrato de transporte e uma sequência de exploração, além de coleta, comércio e recrutamento. Não estão implementados todos os tipos de missão do escopo maior, interiores exclusivos para cada classe, pouso manual contínuo superfície–órbita, alimentação, combate ou multiplayer.

LOD e reciclagem do tráfego estão implementados. Lightmaps, dados de occlusion culling, pós-processamento final e desempenho em hardware intermediário precisam de trabalho e medição no Unity. Não há alegação de fotorealismo ou de FPS validado.

O save com checksum e backup fica em `Application.persistentDataPath` (`%USERPROFILE%\AppData\LocalLow\Orbita Studio\Orbita Fronteira` no Windows com os defaults do projeto). A retomada ocorre no porto ou na órbita do setor salvo; não restaura a posição centimétrica anterior.

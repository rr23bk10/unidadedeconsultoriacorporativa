using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using System.Text.Json;
using System.Text.RegularExpressions;

// Syntax and source-asset integrity only. This is not Unity compilation or a play test.
string root = args.Length > 0 ? Path.GetFullPath(args[0]) : Directory.GetCurrentDirectory();
int failures = 0, scripts = 0;
foreach (var path in Directory.GetFiles(Path.Combine(root, "Assets"), "*.cs", SearchOption.AllDirectories))
{
    scripts++;
    var tree = CSharpSyntaxTree.ParseText(File.ReadAllText(path), new CSharpParseOptions(LanguageVersion.CSharp9), path);
    foreach (var diagnostic in tree.GetDiagnostics().Where(d => d.Severity == DiagnosticSeverity.Error))
    {
        Console.WriteLine(diagnostic);
        failures++;
    }
}
var scriptMeta = File.ReadAllText(Path.Combine(root, "Assets/Orbita/Scripts/Runtime/OrbitaGame.cs.meta"));
string scriptGuid = Regex.Match(scriptMeta, @"guid: ([a-f0-9]{32})").Groups[1].Value;
var scene = File.ReadAllText(Path.Combine(root, "Assets/Orbita/Scenes/Bootstrap.unity"));
Require(scriptGuid.Length == 32 && scene.Contains(scriptGuid), "Bootstrap references OrbitaGame's persistent GUID");
using var packageDoc = JsonDocument.Parse(File.ReadAllText(Path.Combine(root, "Packages/manifest.json")));
Require(packageDoc.RootElement.GetProperty("dependencies").TryGetProperty("com.unity.render-pipelines.universal", out _), "URP declared");
using var assetDoc = JsonDocument.Parse(File.ReadAllText(Path.Combine(root, "ArtSource/Blender/validation_report.json")));
string[] models = { "Scout", "Hauler", "Explorer", "Courier", "Salvager", "Prospector", "Astronaut", "CityTower", "IndustrialRig", "RuinArch", "Station", "Crate", "Asteroid", "Beacon" };
foreach (string name in models)
{
    string path = Path.Combine(root, "Assets/Orbita/Art/Models", name + ".fbx");
    Require(File.Exists(path) && new FileInfo(path).Length > 1024, name + " FBX present");
}
var guids = new HashSet<string>();
foreach (string path in Directory.GetFiles(Path.Combine(root, "Assets"), "*.meta", SearchOption.AllDirectories))
{
    string value = Regex.Match(File.ReadAllText(path), @"guid: ([a-f0-9]{32})").Groups[1].Value;
    Require(value.Length == 32 && guids.Add(value), "Unique GUID: " + Path.GetRelativePath(root, path));
}
Console.WriteLine($"{scripts} C# source files parsed as C# 9; {models.Length} FBX files checked; {guids.Count} GUIDs checked; {failures} failures.");
Console.WriteLine("Unity API compilation, Editor import, rendered gameplay and Windows build remain separate checks.");
return failures == 0 ? 0 : 1;

void Require(bool condition, string name)
{
    if (condition) return;
    Console.WriteLine("FAIL: " + name);
    failures++;
}

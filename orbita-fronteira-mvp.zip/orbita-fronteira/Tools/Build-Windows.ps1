param(
    [string]$UnityEditor = "${env:ProgramFiles}\Unity\Hub\Editor\6000.0.62f1\Editor\Unity.exe"
)
$ErrorActionPreference = "Stop"
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$LogFolder = Join-Path $ProjectRoot "Logs"
$LogFile = Join-Path $LogFolder "build-windows.log"
if (-not (Test-Path -LiteralPath $UnityEditor -PathType Leaf)) {
    throw "Unity Editor nao encontrado. Instale Unity 6000.0.62f1 pelo Hub e ative sua licenca Personal; ou informe -UnityEditor com o caminho correto."
}
New-Item -ItemType Directory -Force -Path $LogFolder | Out-Null
Write-Host "Projeto: $ProjectRoot"
Write-Host "Feche este projeto no Unity antes de iniciar o build em lote."
& $UnityEditor -batchmode -quit -projectPath $ProjectRoot -buildTarget Win64 -executeMethod Orbita.Editor.ProjectSetup.BuildWindows -logFile $LogFile
if ($LASTEXITCODE -ne 0) {
    throw "Unity terminou com codigo $LASTEXITCODE. Consulte $LogFile."
}
$Executable = Join-Path $ProjectRoot "Builds\Windows\OrbitaFronteira.exe"
if (-not (Test-Path -LiteralPath $Executable -PathType Leaf)) {
    throw "Unity nao produziu o executavel esperado. Consulte $LogFile."
}
Write-Host "Build concluido: $Executable"
Write-Host "Distribua a pasta Builds\Windows inteira, incluindo UnityPlayer.dll e OrbitaFronteira_Data."

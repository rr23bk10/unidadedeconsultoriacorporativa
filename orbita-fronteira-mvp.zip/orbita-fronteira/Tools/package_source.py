#!/usr/bin/env python3
"""Package the source project and original art; exclude caches, credentials and builds."""
from pathlib import Path
import hashlib
import zipfile

root = Path(__file__).resolve().parents[1]
output = root.parent / "orbita-fronteira-mvp.zip"
allowed = {"Assets", "ArtSource", "Docs", "Packages", "ProjectSettings", "Tests", "Tools", "README.md", ".gitignore"}
excluded = {"bin", "obj", "__pycache__", "Library", "Temp", "Logs", "UserSettings", "Builds"}
paths = []
for path in sorted(root.rglob("*")):
    relative = path.relative_to(root)
    if not path.is_file() or path.is_symlink() or relative.parts[0] not in allowed:
        continue
    if excluded.intersection(relative.parts) or path.suffix in {".pyc", ".blend1"}:
        continue
    paths.append(path)
with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in paths:
        archive.write(path, Path(root.name) / path.relative_to(root))
with zipfile.ZipFile(output) as archive:
    bad = archive.testzip()
    if bad:
        raise RuntimeError("Archive integrity failure: " + bad)
    names = set(archive.namelist())
    for required in ("README.md", "Packages/manifest.json", "Assets/Orbita/Scenes/Bootstrap.unity", "Assets/Orbita/Scripts/Editor/ProjectSetup.cs", "ArtSource/Blender/orbita_assets.blend"):
        if root.name + "/" + required not in names:
            raise RuntimeError("Missing required project file: " + required)
digest = hashlib.sha256(output.read_bytes()).hexdigest()
output.with_suffix(".zip.sha256").write_text(digest + "  " + output.name + "\n")
print(f"{len(paths)} files packaged; ZIP integrity passed; {output.stat().st_size} bytes")
print(output)
print("SHA256 " + digest)

#!/usr/bin/env python3
"""Create stable Unity metadata and the bootstrap scene without requiring the Editor.

Existing metadata/scenes are preserved. Asset import and URP/prefab generation still
run inside Unity via Orbita/Preparar projeto.
"""
from pathlib import Path
import uuid

ROOT = Path(__file__).resolve().parents[1]
NAMESPACE = uuid.UUID("f47d2548-a6c1-4f29-a77d-3beabbd17ddf")


def guid(path):
    return uuid.uuid5(NAMESPACE, path.as_posix()).hex


def create(path, contents):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text(contents, encoding="utf-8")


def main():
    script = Path("Assets/Orbita/Scripts/Runtime/OrbitaGame.cs")
    scene = ROOT / "Assets/Orbita/Scenes/Bootstrap.unity"
    create(scene, """%YAML 1.1
%TAG !u! tag:unity3d.com,2011:
--- !u!1 &1000
GameObject:
  m_ObjectHideFlags: 0
  m_CorrespondingSourceObject: {fileID: 0}
  m_PrefabInstance: {fileID: 0}
  m_PrefabAsset: {fileID: 0}
  serializedVersion: 6
  m_Component:
  - component: {fileID: 1001}
  - component: {fileID: 1002}
  m_Layer: 0
  m_Name: Orbita Bootstrap
  m_TagString: Untagged
  m_IsActive: 1
--- !u!4 &1001
Transform:
  m_ObjectHideFlags: 0
  m_CorrespondingSourceObject: {fileID: 0}
  m_PrefabInstance: {fileID: 0}
  m_PrefabAsset: {fileID: 0}
  m_GameObject: {fileID: 1000}
  serializedVersion: 2
  m_LocalRotation: {x: 0, y: 0, z: 0, w: 1}
  m_LocalPosition: {x: 0, y: 0, z: 0}
  m_LocalScale: {x: 1, y: 1, z: 1}
  m_ConstrainProportionsScale: 0
  m_Children: []
  m_Father: {fileID: 0}
  m_LocalEulerAnglesHint: {x: 0, y: 0, z: 0}
--- !u!114 &1002
MonoBehaviour:
  m_ObjectHideFlags: 0
  m_CorrespondingSourceObject: {fileID: 0}
  m_PrefabInstance: {fileID: 0}
  m_PrefabAsset: {fileID: 0}
  m_GameObject: {fileID: 1000}
  m_Enabled: 1
  m_EditorHideFlags: 0
  m_Script: {fileID: 11500000, guid: SCRIPT_GUID, type: 3}
  m_Name:
  m_EditorClassIdentifier:
--- !u!1660057539 &9223372036854775807
SceneRoots:
  m_ObjectHideFlags: 0
  m_Roots:
  - {fileID: 1001}
""".replace("SCRIPT_GUID", guid(script)))
    create(ROOT / "ProjectSettings/EditorBuildSettings.asset", """%YAML 1.1
%TAG !u! tag:unity3d.com,2011:
--- !u!1045 &1
EditorBuildSettings:
  m_ObjectHideFlags: 0
  serializedVersion: 2
  m_Scenes:
  - enabled: 1
    path: Assets/Orbita/Scenes/Bootstrap.unity
    guid: SCENE_GUID
  m_configObjects: {}
""".replace("SCENE_GUID", guid(scene.relative_to(ROOT))))
    axes = []
    for name, negative, positive, alternate_negative, alternate_positive, axis_type, axis in (
        ("Horizontal", "left", "right", "a", "d", 0, 0),
        ("Vertical", "down", "up", "s", "w", 0, 0),
        ("Mouse X", "", "", "", "", 1, 0),
        ("Mouse Y", "", "", "", "", 1, 1),
    ):
        axes.append(f"""  - serializedVersion: 3
    m_Name: {name}
    descriptiveName:
    descriptiveNegativeName:
    negativeButton: {negative}
    positiveButton: {positive}
    altNegativeButton: {alternate_negative}
    altPositiveButton: {alternate_positive}
    gravity: {3 if axis_type == 0 else 0}
    dead: 0.001
    sensitivity: {3 if axis_type == 0 else 0.1}
    snap: {1 if axis_type == 0 else 0}
    invert: 0
    type: {axis_type}
    axis: {axis}
    joyNum: 0
""")
    create(ROOT / "ProjectSettings/InputManager.asset", "%YAML 1.1\n%TAG !u! tag:unity3d.com,2011:\n--- !u!13 &1\nInputManager:\n  m_ObjectHideFlags: 0\n  serializedVersion: 2\n  m_Axes:\n" + "".join(axes))
    layers = ["Default", "TransparentFX", "Ignore Raycast", "", "Water", "UI", "", "", "Player", "SpaceObstacle"] + [""] * 22
    create(ROOT / "ProjectSettings/TagManager.asset", "%YAML 1.1\n%TAG !u! tag:unity3d.com,2011:\n--- !u!78 &1\nTagManager:\n  serializedVersion: 2\n  tags: []\n  layers:\n" + "".join("  - " + name + "\n" for name in layers) + "  m_SortingLayers:\n  - name: Default\n    uniqueID: 0\n    locked: 0\n  m_RenderingLayers:\n  - Default\n")
    count = 0
    for path in sorted((ROOT / "Assets").rglob("*")):
        if path.suffix == ".meta":
            continue
        meta = path.with_name(path.name + ".meta")
        if not meta.exists():
            body = "fileFormatVersion: 2\nguid: " + guid(path.relative_to(ROOT)) + "\n"
            if path.is_dir():
                body += "folderAsset: yes\nDefaultImporter:\n  externalObjects: {}\n  userData:\n  assetBundleName:\n  assetBundleVariant:\n"
            elif path.suffix == ".cs":
                body += "MonoImporter:\n  externalObjects: {}\n  serializedVersion: 2\n  defaultReferences: []\n  executionOrder: 0\n  icon: {instanceID: 0}\n  userData:\n  assetBundleName:\n  assetBundleVariant:\n"
            elif path.suffix == ".asmdef":
                body += "AssemblyDefinitionImporter:\n  externalObjects: {}\n  userData:\n  assetBundleName:\n  assetBundleVariant:\n"
            meta.write_text(body, encoding="utf-8")
            count += 1
    print(f"Bootstrap and project settings present; {count} missing metadata files created.")


if __name__ == "__main__":
    main()

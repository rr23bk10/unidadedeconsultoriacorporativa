using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;
using Orbita.Domain;

internal static class Program
{
    private static int passed;
    private static readonly JsonSerializerOptions JsonOptions = new JsonSerializerOptions
    {
        IncludeFields = true,
        NumberHandling = JsonNumberHandling.AllowNamedFloatingPointLiterals
    };

    private static int Main()
    {
        var tests = new Action[]
        {
            FreshGameCompletesDelivery,
            DeliveryRejectsWrongOrderAndPlace,
            DeliveryReservesCargoAndCannotBeSold,
            TravelFailuresAreAtomic,
            CrewChangesHaveFunctionalEffects,
            AllSixShipsCanBePurchasedAndActivated,
            SmallShipCannotSwallowCargo,
            SwitchingNeverCreatesFuel,
            SalvagerHasDoubleYieldWithoutOverfilling,
            ProspectorHasDistinctExtractionAndSensors,
            SalesPayOnceAndAtPortsOnly,
            ExplorationRequiresAllCluesInOrder,
            FullCargoBlocksTreasureAtomically,
            UpgradesStopAtThree,
            RefuelAndRepairAreTransactional,
            SavesRoundTripWithoutReissuingRewards,
            CorruptedSaveNormalizesSafely,
            AcceptedSaveRestoresQuestCargoWithinCapacity,
            UnsupportedSaveIsUntouched,
            EmergencyRescueRestoresPlayableState,
            EmergencyPreservesBothQuestItems,
            NormalStateCannotUseRescueAsTeleport,
            CatalogCannotBeMutatedByCallers
        };

        foreach (var test in tests)
        {
            try
            {
                test();
                passed++;
                Console.WriteLine("PASS " + test.Method.Name);
            }
            catch (Exception error)
            {
                Console.Error.WriteLine("FAIL " + test.Method.Name + ": " + error.Message);
                return 1;
            }
        }
        Console.WriteLine(passed + "/" + tests.Length + " domain checks passed.");
        return 0;
    }

    private static void FreshGameCompletesDelivery()
    {
        GameState state = GameRules.CreateNew();
        int credits = state.credits;
        Yes(GameRules.TryAcceptDelivery(state, out string message), message);
        Equal(8, GameRules.CargoUsed(state), "contract cargo");
        Yes(GameRules.TryTravel(state, Destination.Industrial, out message), message);
        Yes(GameRules.TryDeliverCargo(state, out message), message);
        Equal(0, GameRules.CargoUsed(state), "delivered cargo removed");
        Yes(GameRules.TryTravel(state, Destination.NovaTerra, out message), message);
        Yes(GameRules.TryClaimReward(state, out message), message);
        Equal(credits + GameRules.DeliveryReward, state.credits, "reward paid once");
        Equal(MissionStage.Completed, state.deliveryStage, "contract complete");
        RejectUnchanged(state, () => GameRules.TryClaimReward(state, out _), "double reward");
        RejectUnchanged(state, () => GameRules.TryAcceptDelivery(state, out _), "repeat contract");
    }

    private static void DeliveryRejectsWrongOrderAndPlace()
    {
        var state = GameRules.CreateNew();
        RejectUnchanged(state, () => GameRules.TryClaimReward(state, out _), "premature payment");
        RejectUnchanged(state, () => GameRules.TryDeliverCargo(state, out _), "wrong delivery location");
        state.location = Destination.Industrial;
        RejectUnchanged(state, () => GameRules.TryAcceptDelivery(state, out _), "wrong acceptance location");
        RejectUnchanged(state, () => GameRules.TryDeliverCargo(state, out _), "unaccepted delivery");
        state.location = Destination.NovaTerra;
        Yes(GameRules.TryAcceptDelivery(state, out string message), message);
        state.location = Destination.Industrial;
        Yes(GameRules.TryDeliverCargo(state, out message), message);
        RejectUnchanged(state, () => GameRules.TryClaimReward(state, out _), "payment at industrial");
    }

    private static void DeliveryReservesCargoAndCannotBeSold()
    {
        var state = GameRules.CreateNew();
        state.cargo.Add(new CargoStack { id = GameRules.SalvageCargoId, quantity = 5 });
        RejectUnchanged(state, () => GameRules.TryAcceptDelivery(state, out _), "full hold acceptance");
        state.cargo.Clear();
        Yes(GameRules.TryAcceptDelivery(state, out string message), message);
        RejectUnchanged(state, () => GameRules.TrySellSalvage(state, out _), "selling quest as salvage");
        RejectUnchanged(state, () => GameRules.TrySellRare(state, out _), "selling quest as rare ore");
        Equal(8, GameRules.CargoUsed(state), "quest cargo remains");
    }

    private static void TravelFailuresAreAtomic()
    {
        var state = GameRules.CreateNew();
        Yes(GameRules.TryHire(state, "pilot", out string message), message);
        state.credits = GameRules.CrewWages(state) - 1;
        RejectUnchanged(state, () => GameRules.TryTravel(state, Destination.Industrial, out _), "unpaid salary");
        state.credits = 1000;
        state.fuel = GameRules.TravelFuelCost(state, Destination.Industrial) - 0.01f;
        RejectUnchanged(state, () => GameRules.TryTravel(state, Destination.Industrial, out _), "insufficient fuel");
        state.fuel = 100;
        state.hull = 0;
        RejectUnchanged(state, () => GameRules.TryTravel(state, Destination.Industrial, out _), "destroyed hull");
        state.hull = 100;
        RejectUnchanged(state, () => GameRules.TryTravel(state, state.location, out _), "same place");
        RejectUnchanged(state, () => GameRules.TryTravel(state, (Destination)999, out _), "invalid destination");
    }

    private static void CrewChangesHaveFunctionalEffects()
    {
        var state = GameRules.CreateNew();
        state.credits = 10000;
        float originalFuelCost = GameRules.TravelFuelCost(state, Destination.Industrial);
        float originalSensors = GameRules.SensorRange(state);
        int originalCapacity = GameRules.CargoCapacity(state);
        foreach (string role in new[] { "piloto", "mecânico", "operador de carga", "explorador" })
            Yes(GameRules.TryHire(state, role, out string message), message);
        Equal(4, state.crew.Count, "four roles");
        Equal(originalCapacity + 8, GameRules.CargoCapacity(state), "cargo operator bonus");
        Near(originalFuelCost * 0.8f, GameRules.TravelFuelCost(state, Destination.Industrial), "pilot bonus");
        Near(originalSensors * 1.35f, GameRules.SensorRange(state), "explorer bonus");
        RejectUnchanged(state, () => GameRules.TryHire(state, "scientist", out _), "alias duplicate");
        RejectUnchanged(state, () => GameRules.TryHire(state, "wizard", out _), "invalid role");
        int credits = state.credits;
        int wages = GameRules.CrewWages(state);
        float fuel = state.fuel;
        float journeyFuel = GameRules.TravelFuelCost(state, Destination.Industrial);
        Yes(GameRules.TryTravel(state, Destination.Industrial, out string travelMessage), travelMessage);
        Equal(credits - wages, state.credits, "all salaries paid once");
        Near(fuel - journeyFuel, state.fuel, "fuel discount applied");
        Near(99, state.hull, "engineer reduces wear");
        state.hull = 90;
        credits = state.credits;
        Yes(GameRules.TryRepair(state, out string repairMessage), repairMessage);
        Equal(credits - 28, state.credits, "engineer repair discount");
    }

    private static void AllSixShipsCanBePurchasedAndActivated()
    {
        var state = GameRules.CreateNew();
        state.credits = 100000;
        Equal(6, Enum.GetValues(typeof(ShipClass)).Length, "six available classes");
        foreach (ShipClass ship in Enum.GetValues(typeof(ShipClass)))
        {
            if (ship == ShipClass.Scout) continue;
            int previous = state.credits;
            var spec = ShipCatalog.Get(ship);
            Yes(GameRules.TryBuyShip(state, ship, out string message), message);
            Equal(previous - spec.price, state.credits, "purchase price for " + ship);
            RejectUnchanged(state, () => GameRules.TryBuyShip(state, ship, out _), "duplicate purchase " + ship);
            Yes(GameRules.TryActivateShip(state, ship, out message), message);
            Equal(ship, state.activeShip, "ship active");
            Equal(spec.capacity, GameRules.CargoCapacity(state), "ship capacity");
            Near(spec.travelFuelCost, GameRules.TravelFuelCost(state, Destination.Industrial), "ship consumption");
        }
        Equal(6, state.ownedShips.Count, "all six owned");
        Yes(ShipCatalog.Get(ShipClass.Courier).speed > ShipCatalog.Get(ShipClass.Scout).speed, "courier speed");
        Yes(ShipCatalog.Get(ShipClass.Courier).travelFuelCost > ShipCatalog.Get(ShipClass.Scout).travelFuelCost, "courier tradeoff");
    }

    private static void SmallShipCannotSwallowCargo()
    {
        var state = GameRules.CreateNew();
        RejectUnchanged(state, () => GameRules.TryActivateShip(state, ShipClass.Hauler, out _), "unowned ship");
        state.ownedShips.Add(ShipClass.Hauler);
        state.ownedShips.Add(ShipClass.Courier);
        Yes(GameRules.TryActivateShip(state, ShipClass.Hauler, out string message), message);
        state.cargo.Add(new CargoStack { id = GameRules.SalvageCargoId, quantity = 13 });
        RejectUnchanged(state, () => GameRules.TryActivateShip(state, ShipClass.Scout, out _), "small starter hold");
        RejectUnchanged(state, () => GameRules.TryActivateShip(state, ShipClass.Courier, out _), "small courier hold");
        state.cargo[0].quantity = 8;
        Yes(GameRules.TryActivateShip(state, ShipClass.Courier, out message), message);
        Equal(8, GameRules.CargoUsed(state), "exact capacity permitted");
    }

    private static void SwitchingNeverCreatesFuel()
    {
        var state = GameRules.CreateNew();
        state.ownedShips.Add(ShipClass.Hauler);
        state.fuel = 25;
        Yes(GameRules.TryActivateShip(state, ShipClass.Hauler, out string message), message);
        Near(25, state.fuel, "larger tank does not fill");
        state.fuel = 160;
        Yes(GameRules.TryActivateShip(state, ShipClass.Scout, out message), message);
        Near(100, state.fuel, "excess fuel clipped");
        Yes(GameRules.TryActivateShip(state, ShipClass.Hauler, out message), message);
        Near(100, state.fuel, "switching back does not restore clipped fuel");
    }

    private static void SalvagerHasDoubleYieldWithoutOverfilling()
    {
        var state = GameRules.CreateNew();
        state.activeShip = ShipClass.Salvager;
        state.ownedShips.Add(ShipClass.Salvager);
        state.location = Destination.Debris;
        Yes(GameRules.TryCollectSalvage(state, 4, out string message), message);
        Equal(8, GameRules.CargoUsed(state), "salvager double yield");
        Near(98, state.fuel, "drones consume base quantity fuel");
        state.cargo[0].quantity = 37;
        RejectUnchanged(state, () => GameRules.TryCollectSalvage(state, 2, out _), "multiplied yield exceeds capacity");
        RejectUnchanged(state, () => GameRules.TryCollectSalvage(state, int.MaxValue, out _), "integer overflow");
        RejectUnchanged(state, () => GameRules.TryCollectSalvage(state, -1, out _), "negative collection");
        state.cargo.Clear();
        state.fuel = 0;
        RejectUnchanged(state, () => GameRules.TryCollectSalvage(state, 1, out _), "unpowered collection");
    }

    private static void ProspectorHasDistinctExtractionAndSensors()
    {
        var normal = GameRules.CreateNew();
        normal.location = Destination.Debris;
        Yes(GameRules.TryExtractRare(normal, out string message), message);
        Equal(1, GameRules.CargoUsed(normal), "ordinary extraction");
        var prospector = GameRules.CreateNew();
        prospector.activeShip = ShipClass.Prospector;
        prospector.ownedShips.Add(ShipClass.Prospector);
        prospector.location = Destination.Uncharted;
        Yes(GameRules.TryExtractRare(prospector, out message), message);
        Equal(3, GameRules.CargoUsed(prospector), "prospector extraction");
        Near(normal.fuel, prospector.fuel, "higher yield at same fuel cost");
        Yes(GameRules.SensorRange(prospector) > GameRules.SensorRange(normal), "prospector sensor benefit");
        prospector.cargo[0].quantity = GameRules.CargoCapacity(prospector) - 2;
        RejectUnchanged(prospector, () => GameRules.TryExtractRare(prospector, out _), "rare ore overflow");
    }

    private static void SalesPayOnceAndAtPortsOnly()
    {
        var state = GameRules.CreateNew();
        state.location = Destination.Debris;
        Yes(GameRules.TryCollectSalvage(state, 4, out string message), message);
        Yes(GameRules.TryExtractRare(state, out message), message);
        RejectUnchanged(state, () => GameRules.TrySellSalvage(state, out _), "no market in debris");
        state.location = Destination.Station;
        int credits = state.credits;
        Yes(GameRules.TrySellSalvage(state, out message), message);
        Equal(credits + 4 * GameRules.SalvageUnitPrice, state.credits, "salvage payment");
        RejectUnchanged(state, () => GameRules.TrySellSalvage(state, out _), "selling same salvage twice");
        credits = state.credits;
        Yes(GameRules.TrySellRare(state, out message), message);
        Equal(credits + GameRules.RareUnitPrice, state.credits, "rare payment");
        RejectUnchanged(state, () => GameRules.TrySellRare(state, out _), "selling same ore twice");
    }

    private static void ExplorationRequiresAllCluesInOrder()
    {
        var state = GameRules.CreateNew();
        int credits = state.credits;
        RejectUnchanged(state, () => GameRules.Investigate(state, "treasure", out _), "skip directly to treasure");
        RejectUnchanged(state, () => GameRules.Investigate(state, "debris_signal", out _), "signal at wrong location");
        state.location = Destination.Debris;
        Yes(GameRules.Investigate(state, "debris_signal", out string message), message);
        RejectUnchanged(state, () => GameRules.Investigate(state, "debris_signal", out _), "repeat signal");
        RejectUnchanged(state, () => GameRules.Investigate(state, "coordinates", out _), "triangulate wrong sector");
        state.location = Destination.Uncharted;
        foreach (string clue in new[] { "coordinates", "ruin", "treasure" })
            Yes(GameRules.Investigate(state, clue, out message), message);
        Equal(4, state.explorationStage, "four stages complete");
        Equal(4, state.discoveries.Count, "four discoveries");
        Equal(credits + GameRules.ExplorationReward, state.credits, "exploration payment");
        Equal(1, GameRules.CargoUsed(state), "unique artifact");
        RejectUnchanged(state, () => GameRules.Investigate(state, "treasure", out _), "duplicate treasure");
    }

    private static void FullCargoBlocksTreasureAtomically()
    {
        var state = GameRules.CreateNew();
        state.location = Destination.Uncharted;
        state.explorationStage = 3;
        state.discoveries.AddRange(new[] { "debris_signal", "coordinates", "ruin" });
        state.cargo.Add(new CargoStack { id = GameRules.SalvageCargoId, quantity = 12 });
        RejectUnchanged(state, () => GameRules.Investigate(state, "treasure", out _), "full hold treasure");
        state.cargo[0].quantity--;
        Yes(GameRules.Investigate(state, "treasure", out string message), message);
        Equal(12, GameRules.CargoUsed(state), "treasure fits final slot");
    }

    private static void UpgradesStopAtThree()
    {
        var state = GameRules.CreateNew();
        state.credits = 10000;
        for (int i = 0; i < 3; i++) Yes(GameRules.TryUpgrade(state, out string message), message);
        Equal(3, state.upgrades, "upgrade ceiling");
        Equal(24, GameRules.CargoCapacity(state), "upgrade capacity");
        Equal(6400, state.credits, "upgrade prices");
        RejectUnchanged(state, () => GameRules.TryUpgrade(state, out _), "fourth upgrade");
    }

    private static void RefuelAndRepairAreTransactional()
    {
        var state = GameRules.CreateNew();
        RejectUnchanged(state, () => GameRules.TryRefuel(state, out _), "full tank");
        RejectUnchanged(state, () => GameRules.TryRepair(state, out _), "full hull");
        state.fuel = 50;
        state.hull = 80;
        state.credits = 0;
        RejectUnchanged(state, () => GameRules.TryRefuel(state, out _), "unfunded fuel");
        RejectUnchanged(state, () => GameRules.TryRepair(state, out _), "unfunded repair");
        state.credits = 1000;
        state.location = Destination.Uncharted;
        RejectUnchanged(state, () => GameRules.TryRefuel(state, out _), "no fueling port");
        RejectUnchanged(state, () => GameRules.TryRepair(state, out _), "no repair port");
        state.location = Destination.Industrial;
        Yes(GameRules.TryRefuel(state, out string message), message);
        Yes(GameRules.TryRepair(state, out message), message);
        Equal(820, state.credits, "fuel and repair prices");
        Near(100, state.fuel, "full fuel restored");
        Near(100, state.hull, "full hull restored");
    }

    private static void SavesRoundTripWithoutReissuingRewards()
    {
        var state = GameRules.CreateNew();
        state.deliveryStage = MissionStage.Completed;
        state.explorationStage = 4;
        state.cargo.Add(new CargoStack { id = GameRules.ArtifactCargoId, quantity = 1 });
        state.credits = 987;
        GameState loaded = JsonSerializer.Deserialize<GameState>(Snapshot(state), JsonOptions);
        Yes(GameRules.Validate(loaded), "save supported");
        Equal(987, loaded.credits, "load does not pay rewards");
        RejectUnchanged(loaded, () => GameRules.TryClaimReward(loaded, out _), "saved completed delivery");
        RejectUnchanged(loaded, () => GameRules.Investigate(loaded, "treasure", out _), "saved completed exploration");
        string normalized = Snapshot(loaded);
        Yes(GameRules.Validate(loaded), "second validation");
        Equal(normalized, Snapshot(loaded), "normalization idempotent");
    }

    private static void CorruptedSaveNormalizesSafely()
    {
        var state = new GameState
        {
            version = 0, credits = -10, fuel = float.NaN, hull = float.PositiveInfinity,
            location = (Destination)999, activeShip = (ShipClass)999, deliveryStage = (MissionStage)999,
            explorationStage = -1, upgrades = 999,
            ownedShips = new List<ShipClass> { ShipClass.Scout, ShipClass.Scout, (ShipClass)999 },
            crew = new List<CrewMember>
            {
                null, new CrewMember { role = "pilot", wage = -999, skill = float.NaN, level = -1 },
                new CrewMember { role = "piloto", wage = int.MaxValue }, new CrewMember { role = "wizard" }
            },
            cargo = new List<CargoStack>
            {
                null, new CargoStack { id = "unknown", quantity = int.MaxValue },
                new CargoStack { id = GameRules.SalvageCargoId, quantity = int.MaxValue },
                new CargoStack { id = GameRules.SalvageCargoId, quantity = int.MaxValue },
                new CargoStack { id = GameRules.RareCargoId, quantity = -1 },
                new CargoStack { id = GameRules.DeliveryCargoId, quantity = 8 }
            }
        };
        Yes(GameRules.Validate(state), "old save repaired");
        Equal(GameRules.CurrentVersion, state.version, "version migrated");
        Equal(0, state.credits, "no free credits");
        Equal(ShipClass.Scout, state.activeShip, "invalid ship reset");
        Equal(Destination.NovaTerra, state.location, "invalid destination reset");
        Equal(1, state.ownedShips.Count, "ownership deduplicated");
        Equal(1, state.crew.Count, "roles deduplicated");
        Equal(35, GameRules.CrewWages(state), "salary restored");
        Near(0, state.fuel, "NaN cleaned");
        Near(0, state.hull, "infinity cleaned");
        Yes(GameRules.CargoUsed(state) <= GameRules.CargoCapacity(state), "cargo bounded");
        Equal(1, state.cargo.Count, "unknown negative and stale cargo removed");
        var empty = new GameState();
        Yes(GameRules.Validate(empty), "missing lists repaired");
        Yes(empty.cargo != null && empty.crew != null && empty.discoveries != null && empty.ownedShips != null, "all lists present");
    }

    private static void AcceptedSaveRestoresQuestCargoWithinCapacity()
    {
        var state = GameRules.CreateNew();
        state.activeShip = ShipClass.Courier;
        state.deliveryStage = MissionStage.Accepted;
        state.cargo.Add(new CargoStack { id = GameRules.SalvageCargoId, quantity = 100 });
        Yes(GameRules.Validate(state), "accepted save repaired");
        Equal(8, GameRules.CargoUsed(state), "quest priority in smallest hold");
        Equal(GameRules.DeliveryCargoId, state.cargo[0].id, "quest cargo restored");
        state.location = Destination.Industrial;
        Yes(GameRules.TryDeliverCargo(state, out string message), message);
    }

    private static void UnsupportedSaveIsUntouched()
    {
        var state = GameRules.CreateNew();
        state.version = GameRules.CurrentVersion + 1;
        RejectUnchanged(state, () => GameRules.Validate(state), "future save");
        Yes(!GameRules.Validate(null), "null save rejected");
        Yes(!GameRules.TryClaimReward(null, out _), "null action rejected");
    }

    private static void EmergencyRescueRestoresPlayableState()
    {
        var state = GameRules.CreateNew();
        Yes(GameRules.TryHire(state, "cargo", out string message), message);
        Yes(GameRules.TryAcceptDelivery(state, out message), message);
        state.location = Destination.Uncharted;
        state.credits = 0;
        state.fuel = 0;
        state.hull = 0;
        state.cargo.Add(new CargoStack { id = GameRules.SalvageCargoId, quantity = 12 });
        Yes(GameRules.TryEmergencyRescue(state, out message), message);
        Equal(Destination.NovaTerra, state.location, "returned home");
        Equal(0, state.crew.Count, "unpayable salaries dismissed");
        Equal(0, state.credits, "rescue invents no credits");
        Equal(8, GameRules.CargoUsed(state), "quest cargo preserved, trade cargo lost");
        Yes(GameRules.TryTravel(state, Destination.Industrial, out message), message);
        Yes(GameRules.TryDeliverCargo(state, out message), message);
        Yes(GameRules.TryTravel(state, Destination.NovaTerra, out message), message);
        Yes(GameRules.TryClaimReward(state, out message), message);
        Equal(850, state.credits, "recovered economy");
    }

    private static void EmergencyPreservesBothQuestItems()
    {
        var state = GameRules.CreateNew();
        state.activeShip = ShipClass.Courier;
        state.ownedShips.Add(ShipClass.Courier);
        Yes(GameRules.TryHire(state, "cargo", out string message), message);
        Yes(GameRules.TryAcceptDelivery(state, out message), message);
        state.explorationStage = 4;
        state.cargo.Add(new CargoStack { id = GameRules.ArtifactCargoId, quantity = 1 });
        state.fuel = 0;
        Yes(GameRules.TryEmergencyRescue(state, out message), message);
        Equal(ShipClass.Scout, state.activeShip, "rescue falls back to sufficient starter hold");
        Equal(9, GameRules.CargoUsed(state), "both protected items preserved");
        Yes(GameRules.CargoUsed(state) <= GameRules.CargoCapacity(state), "rescued hold valid");
    }

    private static void NormalStateCannotUseRescueAsTeleport()
    {
        var state = GameRules.CreateNew();
        state.location = Destination.Uncharted;
        RejectUnchanged(state, () => GameRules.TryEmergencyRescue(state, out _), "gratuitous rescue");
    }

    private static void CatalogCannotBeMutatedByCallers()
    {
        var spec = ShipCatalog.Get(ShipClass.Scout);
        spec.price = -999;
        spec.capacity = 9999;
        Equal(12, ShipCatalog.Get(ShipClass.Scout).capacity, "catalog isolated");
        Equal(0, ShipCatalog.Get(ShipClass.Scout).price, "catalog price isolated");
    }

    private static void RejectUnchanged(GameState state, Func<bool> action, string reason)
    {
        string before = Snapshot(state);
        Yes(!action(), reason + " should fail");
        Equal(before, Snapshot(state), reason + " must not mutate state");
    }

    private static string Snapshot(GameState state) { return JsonSerializer.Serialize(state, JsonOptions); }
    private static void Yes(bool value, string description) { if (!value) throw new InvalidOperationException(description); }
    private static void Equal<T>(T expected, T actual, string description)
    {
        if (!EqualityComparer<T>.Default.Equals(expected, actual))
            throw new InvalidOperationException(description + ": expected " + expected + ", actual " + actual);
    }
    private static void Near(float expected, float actual, string description)
    {
        if (Math.Abs(expected - actual) > 0.001f)
            throw new InvalidOperationException(description + ": expected " + expected + ", actual " + actual);
    }
}

# Arquitetura — Órbita / Fronteira

Este documento registra o projeto do protótipo e a implementação entregue. O alvo é um percurso completo entre cidade, nave, órbita, outro planeta e pagamento do contrato. A validação física desse percurso no Unity ainda precisa ser executada; consulte [PLAYTEST.md](PLAYTEST.md).

## 1. Arquitetura técnica

- **Engine:** Unity Personal, Unity 6 `6000.0.62f1`, URP `17.0.3`; alvo inicial Windows desktop.
- **Arte:** Blender `4.3.2`, fonte `.blend` editável e 14 modelos FBX originais. A instalação do Blender não é necessária para importar os FBX no Unity.
- **Domínio:** `Orbita.Domain`, C# 9 sem `UnityEngine`, compatível com .NET Standard 2.1. `GameState`, `ShipCatalog` e `GameRules` concentram dados, custos, inventário e progressão.
- **Runtime:** `OrbitaGame` coordena ações e transições; controladores de personagem/nave, construção dos setores, tripulação, HUD e persistência usam as regras do domínio.
- **Editor:** o menu `Orbita/Preparar projeto` prepara os recursos de importação, configurações e a cena inicial. Ferramentas de Editor ficam em assembly separado.

Não há servidor, contas, multiplayer ou serviços externos durante o jogo. Ações econômicas conferem os requisitos antes de alterar o estado. As regras usam campos públicos e listas compatíveis com `JsonUtility`.

## 2. Estrutura das pastas

```text
Assets/Orbita/
  Art/Models/          FBX exportados pelo Blender
  Scripts/Domain/      Estado serializável, catálogo e regras puras
  Scripts/Runtime/     Personagem, nave, setores, NPCs, HUD e save
  Scripts/Editor/      Preparação e configuração do projeto Unity
  Scenes/              Bootstrap.unity, preparada pelo menu do Editor
  Resources/Models/    Recursos dos modelos preparados para o runtime
ArtSource/Blender/     Gerador, .blend, manifestos e validação dos FBX
Tests/Domain/          Executável .NET 8, sem pacotes de teste externos
Docs/                  Arquitetura, roteiro manual, arte e próximas etapas
Packages/              Dependências Unity com versões fixadas
ProjectSettings/       Versão e configurações do projeto
```

`Library`, caches do Unity e resultados de compilação são gerados localmente. Não precisam acompanhar o código-fonte.

## 3. Cenas

`Bootstrap.unity` inicia `OrbitaGame`. A nave permanece em uma hierarquia persistente; personagem e câmera acompanham o fluxo da sessão. `WorldBuilder` cria uma cena aditiva para o setor atual, constrói sua geometria e descarrega o setor anterior.

Há cinco destinos: Nova Terra, Colônia Industrial, Planeta Inexplorado, Estação Meridiano e Campo de Destroços. Planetas e estação têm representações separadas de porto/superfície e órbita. Destroços é um setor orbital. Decolagem, salto e pouso usam transições curtas; não existe voo contínuo por três planetas completos.

## 4. Prefabs e arte reutilizável

Os modelos importados são instanciados como recursos de `Resources/Models`. Personagem, casco, torre, ruína, estação, contêiner, asteroide, baliza e instalação industrial possuem modelos próprios. Consulte [ASSETS.md](ASSETS.md) para origem e reprodução.

O runtime constrói piso, paredes, mobiliário, rampa, terminais e colisões com peças simples. Esses conjuntos ainda não são uma biblioteca final de prefabs de gameplay editados individualmente. Os modelos visuais não substituem a geometria física do interior. O astronauta entregue é estático, sem rig ou animações de caminhada.

## 5. Sistemas de gameplay

| Componente | Responsabilidade |
| --- | --- |
| `PlayerController` | Terceira pessoa, caminhada/corrida, câmera e vínculo ao interior da nave |
| `ShipController` | Voo local, cadeira, rampa, decolagem/pouso e colisão orbital aproximada |
| `Interactable` + `OrbitaGame` | Proximidade, linha de visão, terminais, interação a pé e recuperação orbital |
| `FlightHud` | Estado da nave, objetivos, mercados, navegação, contratação e menus |
| `GameRules` | Transporte, exploração, coleta, vendas, serviços, salários, frota e resgate |
| `SaveStore` | JSON versionado, checksum SHA-256, escrita temporária e backup `.bak` |

O save preserva créditos, nave ativa/possuída, tripulação, carga, combustível, casco, setor e missões. Ao carregar, o jogador reaparece no porto do setor ou na órbita dos destroços; posição exata, velocidade e orientação não são persistidas. Nós coletados reaparecem ao reconstruir o setor. O checksum detecta corrupção; não é uma assinatura antitrapaça.

## 6. Sistema de nave: seis classes

O personagem começa com a Pioneira, 1.200 créditos, 100 de combustível e 100% de casco. Apenas uma nave fica ativa. Comprar adiciona à frota; ativar exige hangar e espaço suficiente para a carga atual. Trocar de nave transfere combustível, limitado ao novo tanque.

| Classe / nome | Preço CR | Porão | Velocidade m/s | Tanque | Consumo base por salto | Sensor m | Especialidade |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| Scout / Pioneira | Inicial | 12 | 24 | 100 | 18 | 900 | Equilíbrio inicial |
| Hauler / Atlas | 2.800 | 48 | 16 | 160 | 26 | 650 | Transporte de grande volume |
| Explorer / Horizonte | 4.200 | 24 | 22 | 140 | 17 | 2.200 | Autonomia e sensores |
| Courier / Vetor | 3.600 | 8 | 40 | 100 | 32 | 1.100 | Maior velocidade, pouco porão, alto consumo |
| Salvager / Ímã | 4.400 | 40 | 18 | 160 | 24 | 1.250 | Sucata ×2 por coleta |
| Prospector / Sonda | 5.200 | 22 | 20 | 140 | 22 | 2.800 | 3 minérios raros por extração; demais classes: 1 |

Rotas envolvendo o planeta inexplorado custam 35% mais combustível; piloto contratado reduz o custo em 20%. O voo local também consome combustível. Três melhorias de porão custam 600, 1.200 e 1.800 créditos e acrescentam quatro unidades cada, para toda a frota.

As seis classes têm cascos e atributos distintos, mas compartilham o layout físico de cockpit/interior nesta versão. A capacidade superior do Atlas é lógica; seu interior ampliado e módulos específicos por classe estão no roadmap. O controlador usa estabilização ao levantar e parenting para manter o humano no referencial da nave.

## 7. Sistema planetário e desempenho

Nova Terra reúne praça comercial e skyline; Colônia Industrial usa construções menores e equipamentos pesados; o planeta inexplorado contém terreno, abrigo, ruína, pistas e depósitos. São distritos compactos gerados proceduralmente, sobre zonas exploráveis limitadas, com planetas distantes como cenário. A estação oferece uma área de serviços sob estrutura orbital.

O código inclui carregamento por setor, LODs simplificados de torres/rochas, malha agrupada de estrelas e tráfego NPC com instâncias reutilizadas e ocultação por distância. A câmera habilita occlusion culling, mas não há bake de oclusão comprovado. Iluminação baked, impostors dedicados, distância de renderização adaptativa e medições de desempenho ainda são trabalho posterior. Materiais metálicos/emissivos e luzes formam uma base visual; não representam acabamento fotorrealista validado.

## 8. Sistema de NPCs

Quatro especialidades podem ser contratadas em Nova Terra ou na estação. Os NPCs aparecem na nave, circulam pelo corredor e abrem uma conversa básica com `E`. `CrewController` calcula caminhos em NavMesh estacionário e converte os pontos para o referencial local da nave em movimento.

| Especialidade | Contratação CR | Salário por viagem CR | Efeito |
| --- | ---: | ---: | --- |
| Piloto | 250 | 35 | −20% no combustível de viagem |
| Mecânico | 220 | 30 | −30% no reparo e menor desgaste em viagem |
| Operador de carga | 180 | 25 | +8 unidades de porão |
| Explorador | 280 | 40 | +35% no alcance dos sensores |

Nome, função, nível, habilidade e salário são persistidos. Há um tripulante por função; níveis e habilidades não possuem progressão por experiência nesta versão. Diálogos ramificados, rotinas de cidade e aparência individual aprofundada permanecem futuros.

## 9. Sistema de missões

**Transporte:** disponível em Nova Terra → aceitar 8 unidades → entregar na Colônia Industrial → voltar a Nova Terra → receber 850 créditos uma única vez. A carga ocupa porão e não pode ser vendida como sucata.

**Exploração:** caixa-preta nos destroços (`debris_signal`) → região aproximada no planeta inexplorado (`coordinates`) → inscrição da ruína (`ruin`) → tesouro (`treasure`). A ordem e o setor são conferidos. O final concede um artefato, ocupa uma unidade de porão e paga 2.200 créditos uma única vez. O scanner oferece rumo e faixa de distância, sem marcador exato do tesouro.

**Trabalho livre:** coletar sucata nos destroços, extrair minério nos destroços/planeta inexplorado e vender em portos. Sucata vale 45 CR/unidade; minério raro, 160 CR/unidade. Esses trabalhos são repetíveis entre visitas, enquanto o contrato inicial e a cadeia de pistas são únicos. Não há ainda gerador de contratos, passageiros, escolta ou eventos narrativos ramificados.

O resgate atende falta de combustível, casco inutilizado ou impossibilidade de pagar salários. Retorna a Nova Terra, cobra até 200 créditos, dispensa tripulação e perde carga comercial, preservando contrato/artefato. Isso permite recuperar uma partida sem inventar créditos.

## 10. Ordem de desenvolvimento e evidência

1. Domínio e regras transacionais: implementados; **23 testes passaram** em .NET 8.0.425. O domínio também compilou contra .NET Standard 2.1 com C# 9.
2. Modelagem procedural no Blender: **14 FBX reimportados e validados**, incluindo dimensões e corredor livre nas seis naves. Isso não substitui a inspeção de importação no Unity.
3. Runtime, fluxo de setores, personagem, nave, missão e interface: código implementado e revisado estaticamente.
4. Preparação/importação Unity e percurso manual: próxima validação no Editor, seguindo [PLAYTEST.md](PLAYTEST.md).
5. Arte final, expansão de conteúdo e otimização medida: [ROADMAP.md](ROADMAP.md).

O Unity Editor não estava disponível/licenciado no ambiente de desenvolvimento desta entrega. Não foram executados compilação do projeto Unity, Play Mode, build Windows ou profiling de GPU/CPU. Os testes de domínio e os FBX validados não comprovam esses resultados.

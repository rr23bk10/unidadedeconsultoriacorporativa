# Validação da entrega

Este relatório distingue verificações executadas de verificações que ainda exigem Unity. O pacote contém o código do vertical slice; não contém um executável Unity validado.

| Verificação | Resultado observado |
|---|---|
| Compilação e execução do domínio com .NET SDK 8.0.425 | **23/23 testes passaram** |
| Domínio C# 9 contra .NET Standard 2.1 | Compilação sem erros ou avisos na revisão do domínio |
| Sintaxe dos scripts Unity com Roslyn C# 9 | **15 arquivos; zero erros de sintaxe** |
| Referências estáveis de assets/cena | **44 GUIDs únicos; Bootstrap referencia OrbitaGame corretamente** |
| Modelos produzidos no Blender 4.3.2 | **14 FBX exportados e reimportados** |
| Escala na reimportação FBX | Erro máximo de dimensões **0,000049 m** |
| Corredor reservado no casco | **Livre nas seis naves**, verificado por volume de malha |
| Materiais e orçamento geométrico | 17 materiais no manifesto; 81.844 triângulos nos 14 assets |
| Prancha visual da frota | Render final conferido; seis modelos identificados |
| Importação dos FBX e geração dos prefabs no Unity | **Não executada** |
| Compilação dos assemblies Unity / compatibilidade completa de APIs | **Não executada** |
| Ciclo cidade–nave–planeta no Play Mode | **Não executado** |
| NavMesh da tripulação, física, câmera e HUD renderizados | **Não executados no Unity** |
| Build Windows64 | **Não executado; nenhum .exe fornecido** |
| Desempenho em PC intermediário / FPS | **Não medido** |

O teste de sintaxe verifica a gramática C#, sem simular nem substituir as bibliotecas Unity. Não comprova que a importação, os materiais ou a física funcionarão no Editor. Algumas APIs do preparo URP foram conferidas no código oficial, mas isso não equivale a compilação.

## Testes de regras executados

Contrato de ida e volta; ordem e local das operações; reserva da carga do contrato; pagamento único; atomicidade de viagens sem combustível ou salários; benefícios dos quatro tripulantes; compra e ativação das seis naves; recusa de troca para porão insuficiente; conservação do combustível ao trocar de nave; rendimento da Ímã e Sonda; vendas locais e pagamento único; ordem das quatro pistas; recusa de tesouro com porão cheio; limite de melhorias; reabastecimento e reparo; serialização sem repetir recompensas; normalização de save corrompido; preservação da carga de missão; rejeição de versão futura; resgate; preservação de itens essenciais; prevenção de resgate como teleporte gratuito; proteção do catálogo contra mutação.

Comandos e fontes dos testes estão no README. O relatório detalhado de geometria fica em `ArtSource/Blender/validation_report.json`.

## Revisão de integração realizada

- O tratamento de Tab/Esc foi centralizado para impedir abertura e fechamento no mesmo frame.
- Interações de salvamento ignoram os colisores da própria nave e exigem alvos à frente.
- Os obstáculos orbitais foram colocados na layer de colisão utilizada pelo controlador de voo.
- Recursos interativos respeitam os destinos permitidos pelas regras econômicas.
- A câmera da nave responde ao mouse; a interface inclui a tecla G de recuperação.
- Os modelos de asteroides foram ajustados às dimensões do setor para evitar bloqueios desproporcionais.
- A geração de assets no Editor preserva prefabs e materiais existentes e valida os requisitos antes do build.

Essas são correções de código e revisão estática. Precisam ser confirmadas no [playtest](PLAYTEST.md).

## Pré-requisito externo restante

O ambiente de produção destes arquivos não tem Unity Editor instalado e ativado. Os serviços oficiais de catálogo de pacotes e versões do Editor também responderam com bloqueio de proxy nas verificações disponíveis. O Blender e o .NET estavam funcionais.

Para concluir a validação, abra o projeto no **Unity 6000.0.62f1**, com licença Personal válida, acesso ao Package Manager e suporte de build Windows. Use `Orbita/Preparar projeto e Play`, execute `Docs/PLAYTEST.md` e depois `Orbita/Build Windows64`. Corrija quaisquer erros relatados pelo Editor antes de considerar o vertical slice pronto para distribuição.

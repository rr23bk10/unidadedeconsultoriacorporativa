# Arte 3D original — Órbita Fronteira

Os 14 modelos FBX foram modelados proceduralmente no **Blender 4.3.2**. Não há downloads de modelos, texturas externas ou dependência de plug-ins. A fonte editável é `ArtSource/Blender/orbita_assets.blend`; as coleções mantêm a geometria original e a cena contém instâncias da frota para apresentação.

## Reproduzir

Na raiz do projeto:

```sh
blender --background --python ArtSource/Blender/build_assets.py
blender --background --python ArtSource/Blender/validate_assets.py
```

O primeiro comando exporta os FBX para `Assets/Orbita/Art/Models`, grava o `.blend`, o manifesto com medidas e materiais e renderiza `ArtSource/Blender/fleet_preview.png`. O render usa Cycles CPU, 48 amostras, sem denoiser; funciona também em builds do Blender sem OpenImageDenoise. O segundo reimporta os arquivos realmente exportados, confere quantidade de malhas, escala e volume interno livre das seis naves. O resultado fica em `validation_report.json`.

## Frota

| Arquivo | Identidade visual | Utilidade prevista |
| --- | --- | --- |
| `Scout.fbx` | Turquesa, asas compactas, antena de reconhecimento | **Pioneira: nave inicial de reconhecimento** |
| `Hauler.fbx` | Laranja, seis módulos de carga laterais | **Atlas: transporte e armazenamento** |
| `Explorer.fbx` | Azul, outriggers, antenas e placas solares | **Horizonte: exploração e autonomia** |
| `Courier.fbx` | Vermelho, proa alongada, grandes motores e estabilizadores | **Vetor: deslocamento super-rápido** |
| `Salvager.fbx` | Amarelo, pinças frontais e guinchos laterais | **Ímã: recuperação e reboque** |
| `Prospector.fbx` | Roxo, brocas frontais e depósitos de minério | **Sonda: mineração** |

Os cascos têm detalhes separados, bordas arredondadas, materiais metálicos, vidros opacos estilizados e emissores. Cada nave reserva um corredor caminhável comum de `x=-3.5..3.5`, `y=1..4.5`, `z=-7..7` metros, com acesso livre pela popa; piso, colisão, mobiliário e mecanismos do interior são construídos pelo projeto Unity. O teto é parcial para manter boa leitura em terceira pessoa.

## Outros modelos

- `Astronaut.fbx`: astronauta de aproximadamente 1,9 m, com membros separados, capacete, visor dourado, botas magnéticas e suporte de vida. Modelo estático sem esqueleto ou animações incorporadas.
- `CityTower.fbx`: torre modular de cidade com faixas luminosas.
- `IndustrialRig.fbx`: plataforma, tanques e estrutura de perfuração.
- `RuinArch.fbx`: arco de ruína com inscrições luminosas.
- `Station.fbx`: estação orbital com anel habitável, docas e painéis solares.
- `Crate.fbx`, `Asteroid.fbx`, `Beacon.fbx`: carga recuperável, rocha com minério e baliza.

## Integração

Os helpers do gerador recebem metros e coordenadas da cena Unity: X lateral, Y vertical e +Z em direção à proa. O arquivo Blender representa essas posições como X, -Y e Z; FBX usa `axis_forward='-Z'`, `axis_up='Y'`, escala de unidade aplicada e transformações de espaço aplicadas. As medidas precisas por modelo estão em `asset_manifest.json`, e a verificação de reimportação consta de `validation_report.json`.

A validação executada usa o importador FBX do Blender. No Unity, confira a orientação após a importação: `Nose light` identifica a proa e `Aft boarding threshold` a popa. A proa deve apontar para +Z local; qualquer correção de orientação deve ocorrer somente no filho visual, preservando os eixos do controlador e do interior.

## Orçamento de geometria

| Modelo | Triângulos | Malhas |
| --- | ---: | ---: |
| Scout | 8.844 | 80 |
| Hauler | 11.360 | 102 |
| Explorer | 9.976 | 90 |
| Courier | 9.408 | 84 |
| Salvager | 11.448 | 96 |
| Prospector | 12.008 | 98 |
| Astronaut | 3.228 | 31 |

O conjunto completo soma **81.844 triângulos**, incluindo estação, cenário e objetos. As peças separadas preservam a edição e o compartilhamento de materiais; para muitas instâncias simultâneas, o projeto Unity pode combinar malhas por material ou utilizar batching. Esta versão não inclui LODs adicionais. O teste de corredor verifica os volumes de todas as malhas reimportadas, detectando também faces que atravessariam o interior mesmo com vértices fora dele.

Materiais PBR compartilham nomes estáveis, valores de cor, metalicidade, rugosidade e emissão registrados no manifesto. A conversão para URP utiliza esses nomes e dispensa texturas. Os modelos são entregues como FBX para que o Unity não precise invocar o Blender ao importar. Os arquivos `.blend` ficam fora de `Assets`.

Os arquivos deste conjunto são originais produzidos para este projeto. Nenhum material de terceiros foi incorporado.

# Teste manual — Órbita / Fronteira

Este roteiro define os resultados a verificar. **Não representa um playtest já executado.** O ambiente usado para produzir o projeto não dispõe de Unity Editor licenciado; compilação Unity, Play Mode e build Windows permanecem pendentes. Passaram 23 testes do domínio puro e a validação de reimportação dos 14 FBX no Blender.

## Abrir no Windows

1. Instale Unity Hub e o Editor **Unity 6 `6000.0.62f1`**, ativando uma licença Personal válida. Para gerar executável, inclua o suporte de build Windows necessário à sua instalação.
2. No Hub, escolha **Add / Adicionar projeto do disco** e selecione a pasta `orbita-fronteira`, que contém `Assets`, `Packages` e `ProjectSettings`.
3. Abra usando a versão indicada. Aguarde a resolução dos pacotes e importação. Use conexão de rede nesta primeira abertura para obter as dependências Unity.
4. Abra **Window → General → Console** e resolva qualquer erro de importação/compilação antes do teste. Execute **Orbita → Preparar projeto**.
5. Abra `Assets/Orbita/Scenes/Bootstrap.unity`, pressione **Play** e clique na aba **Game** para dar foco aos controles. `Esc` libera o cursor ao abrir o menu.
6. Se houver progresso anterior, use `Esc → NOVO JOGO… → CONFIRMAR NOVO JOGO`. Essa confirmação substitui o progresso atual. Para preservar uma sessão importante, copie antes o arquivo de save e seu backup.

## Controles implementados

| Contexto | Tecla | Ação |
| --- | --- | --- |
| A pé | WASD | Caminhar na direção da câmera |
| A pé | Shift esquerdo | Correr |
| A pé / cockpit | Mouse | Girar a câmera; no cockpit, orbitar a nave sem alterar sua direção |
| A pé | E | Interagir com terminal, cadeira, tripulante ou pista próxima |
| A pé / cockpit | R | Consultar scanner; em solo, leia também a mensagem de retorno |
| Cockpit em voo | W / S | Avançar / recuar |
| Cockpit em voo | A / D | Guinar para esquerda / direita |
| Cockpit em voo | Q / E | Descer / subir |
| Cockpit | F | Abrir navegação; decolar pelo botão quando pousado |
| Cockpit em voo | L | Iniciar pouso no setor atual, exceto destroços |
| Cockpit | X | Levantar e caminhar pelo interior |
| Cockpit em voo | G | Recuperar/investigar o alvo próximo indicado na proa |
| Geral | Tab | Abrir diário; fecha um painel já aberto |
| Geral | Esc | Abrir menu; fecha um painel já aberto |
| Sem painel aberto | F5 | Salvar progresso |

A câmera do cockpit acompanha a nave e permite olhar ao redor com o mouse; a direção da nave é controlada pelo teclado. Menus usam cliques e rolagem. Feche o painel para voltar aos controles de movimento. Tab/Esc têm tratamento centralizado para não abrir e fechar no mesmo evento.

## Percurso obrigatório: transporte e retorno

Execute primeiro sem contratar, comprar, reparar ou reabastecer, para conferir o saldo esperado.

1. **Nova partida:** confirme Pioneira, **1.200 CR**, porão **0/12**, combustível **100** e casco **100%**, em Nova Terra. Caminhe até a praça comercial e procure o terminal de contratos.
2. **Contrato:** aproxime-se até aparecer o aviso `[E]`, abra o terminal e escolha **ACEITAR ENTREGA**. Resultado esperado: porão **8/12**, contrato aceito, saldo ainda **1.200 CR**.
3. **Embarque físico:** feche o painel, volte ao porto e entre pela rampa traseira. Caminhe pelo interior até a cadeira/console da proa e pressione `E`. O humano deve permanecer dentro da nave, sentado; a câmera muda para acompanhamento de voo.
4. **Decolagem:** abra a navegação com `F`, caso ainda esteja fechada, e clique **DECOLAR PARA EXPLORAR O SETOR ATUAL**. Aguarde subida/transição. A rampa deve fechar e o estado deve indicar órbita.
5. **Viagem:** pressione `F` e escolha **VIAJAR** para **COMPLEXO INDUSTRIAL**. A viagem deve descontar combustível uma vez, carregar o setor de destino e manter 8 unidades do contrato.
6. **Pouso e desembarque:** em órbita industrial, com painel fechado, pressione `L`. Após o pouso, `X` levanta da cadeira. Caminhe até a popa, desça a rampa e vá ao terminal **BOLSA DE CARGAS**.
7. **Entrega:** `E → ENTREGAR MATERIAIS`. Resultado esperado: porão **0/12**, entrega registrada, pagamento ainda pendente e saldo **1.200 CR**. A recompensa deve exigir retorno a Nova Terra.
8. **Retorno:** entre novamente na nave, sente com `E`, decole, abra `F` e viaje a **NOVA TERRA**. Pouse com `L`, levante com `X` e caminhe ao terminal de contratos.
9. **Pagamento:** escolha **RECEBER PAGAMENTO**. Resultado esperado: **2.050 CR**, contrato concluído, porão vazio. O pagamento não deve poder ser repetido. Combustível/casco podem variar com o voo local e colisões; sem incidentes, os dois saltos gastam 36 de combustível e 4 pontos de casco.

Critério de aprovação: concluir todos os passos sem teleportar o personagem pelo Inspector, editar o save, atravessar paredes, cair da nave ou encontrar erros na Console.

## Verificações adicionais

- **Interior em voo:** em órbita, solte os controles e pressione `X`. Caminhe pelo corredor, aproxime-se da cadeira e sente com `E`. O personagem deve acompanhar a nave e a porta traseira deve permanecer fechada. Repita com tripulantes a bordo.
- **Colisões, câmera e menus:** aproxime-se lentamente de um asteroide; confira a resposta de colisão. No cockpit, mova o mouse e confirme que a câmera orbita sem guinar a nave. Abra/feche Tab e Esc repetidas vezes, a pé e sentado. Confirme que não há movimentação controlada enquanto um painel está aberto.
- **Coleta/venda:** viaje aos destroços; use `R`, alinhe um contêiner à frente e espere o aviso `[G]`. Cada coleta comum entrega 2 sucatas; Ímã entrega 4. Vá a um mercado e venda. Confira 45 CR por unidade e ausência de segunda venda da mesma carga.
- **Minério raro:** use `G` junto a depósito orbital em destroços/planeta inexplorado ou `E` em depósito de superfície no planeta inexplorado. A extração consome 4 de combustível; Sonda entrega 3 unidades, demais naves 1. Venda por 160 CR/unidade.
- **Exploração:** recupere a caixa-preta dos destroços com `G`; siga a indicação do scanner para o planeta inexplorado. Pouse, use `R` e observe os marcos do terreno. Investigue o registro, a inscrição da ruína e o relicário, nesta ordem, com `E`. O scanner deve fornecer região/faixa, sem marcador exato. Ao final, confira um artefato e +2.200 CR; uma nova interação não pode repetir a recompensa. Reserve uma unidade no porão antes do tesouro.
- **Tripulação:** contrate cada especialidade em Nova Terra ou na estação. Confira o NPC físico no interior, circulação, conversa e bônus no diário. Cada salto deve pagar todos os salários uma vez; falta de créditos deve impedir a viagem sem gastar combustível.
- **Frota:** acumule créditos por exploração/comércio. Compre e ative as seis classes no hangar; confira casco visual, velocidade, capacidade e rendimento. Uma troca para nave menor deve falhar se a carga não couber. Comprar não seleciona automaticamente a nave; trocar não abastece gratuitamente.
- **Serviços:** compre módulos de porão e confira +4 por nível, até três. Reabasteça/repare em porto e confira o saldo. Pedidos sem créditos devem preservar os recursos e a nave.

## Save, recuperação e resgate

O arquivo é `orbita-save.json` em `Application.persistentDataPath`, acompanhado por `.bak`. No Windows, esse diretório normalmente fica em `%USERPROFILE%\AppData\LocalLow\<empresa>\<produto>`. Confirme o nome da empresa/produto nas configurações Unity antes de localizar o arquivo.

1. Salve pelo menu ou `F5`; anote créditos, nave, tripulação, carga e estágio das missões.
2. Pare o Play Mode e inicie novamente. Confira esses dados. A retomada ocorre no porto do setor salvo, ou em órbita quando o setor é Destroços; não espere posição/velocidade exatas.
3. Para testar backup, faça uma cópia externa dos arquivos. Com o jogo parado e após dois salvamentos válidos, danifique apenas uma **cópia de teste** do arquivo principal e mantenha `.bak` íntegro. Ao iniciar, o backup deve ser recuperado. Restaure seus arquivos preservados após o teste.
4. Para testar resgate, use uma sessão descartável que fique sem combustível ou sem créditos para salários. `Esc → SOLICITAR RESGATE` deve retornar a Nova Terra, descontar até 200 CR, retirar carga comercial e dispensar a tripulação. Contrato e artefato devem sobreviver; combustível/casco devem permitir recuperar a sessão. Uma nave apta a viajar deve ter o resgate recusado.

## Registrar a execução

Registre versão do Unity, sistema operacional, CPU/GPU, resolução, importação dos modelos, resultado de cada percurso e erros da Console. Fotografe ou grave o embarque, voo com personagem no interior, entrega e recompensa. Só marque a validação do vertical slice como concluída após executar o percurso obrigatório no Editor ou no build Windows.

Para repetir a validação independente da engine, na raiz do projeto com .NET 8 instalado:

```sh
dotnet run --project Tests/Domain/Orbita.Domain.Tests.csproj --configuration Release
```

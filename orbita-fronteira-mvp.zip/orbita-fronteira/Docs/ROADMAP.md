# Próximas etapas — Órbita / Fronteira

O objetivo continua sendo um sistema estelar convincente com três planetas e um ciclo de trabalho completo. O protótipo prioriza esse percurso; a lista abaixo distingue o código disponível do trabalho ainda necessário.

## Etapa 1 — Protótipo implementado

- Domínio com inventário limitado, combustível, casco, créditos, salários, serviços, frota e resgate.
- Contrato Nova Terra → Colônia Industrial → Nova Terra, com recompensa única; cadeia de exploração destroços → coordenadas aproximadas → ruína → artefato.
- Runtime para personagem em terceira pessoa, embarque pela rampa, cadeira, voo local, interior caminhável e transições entre porto/órbita/setor.
- Cinco destinos: três planetas, estação e destroços; distritos comerciais compactos, indústria, ruínas, asteroides e tráfego decorativo reutilizado.
- Seis naves com cascos distintos e diferenças funcionais: Pioneira, Atlas, Horizonte, Vetor, Ímã e Sonda. Interior compartilhado; melhorias de porão aplicadas à frota.
- Quatro especialidades de tripulação, representação física e circulação por caminhos de NavMesh; conversa básica.
- Interface de terminais, navegação e diário; save JSON versionado com checksum, backup e retomada por setor.
- Fonte Blender e 14 FBX exportados; 23 testes de domínio passaram e os 14 FBX foram reimportados e validados no Blender.

**Limite desta etapa:** o Unity Editor não estava disponível/licenciado aqui. O projeto Unity não foi compilado ou executado; não há build Windows nem resultados comprovados de Play Mode ou profiling.

## Etapa 2 — Validar o percurso no Unity

1. Abrir Unity 6 `6000.0.62f1`, executar a preparação do projeto e resolver importação/compilação.
2. Executar [PLAYTEST.md](PLAYTEST.md), priorizando contrato completo, entrada/saída física, interior em voo e persistência.
3. Conferir eixos/escala dos FBX, folgas da rampa, colisões do personagem, visibilidade de terminais e legibilidade da câmera nas seis naves.
4. Validar salários sem saldo, porão cheio, troca para nave menor, interrupção de save e resgate.
5. Gerar um build Windows e repetir o percurso fora do Editor.

Saída esperada: evidência de execução do vertical slice, erros bloqueantes resolvidos e controles consistentes. Essa evidência ainda precisa ser produzida.

## Etapa 3 — Completar conteúdo e profissões

- Gerador de contratos repetíveis com origem/destino, prazos e recompensas variadas, incluindo estação e postos.
- Transporte de passageiros/busca de pessoa, escolta e contratos de mineração/coleta; eventos inesperados e objetivos opcionais.
- Ampliar a cadeia existente da nave desaparecida/caixa-preta com instalações abandonadas, diferentes mapas e escolhas. A cadeia linear atual serve como primeiro exemplo, sem simular um sistema narrativo completo.
- Acrescentar mapas como objetos consultáveis, cadernos de pistas persistentes e sinais com leituras que justifiquem sensores melhores; manter segredos sem marcadores exatos.
- Mercadores e trabalhadores com rotinas, conversas ramificadas e consequências; bar com atividades e contatos próprios.
- Economia de equipamentos, peças, comida e manutenção. Hoje há combustível, reparo, módulos de porão, contratação e compra de naves; os demais mercados ainda não existem.

## Etapa 4 — Personagens e diferenciação das naves

- Rig, skinning e animações de caminhada, corrida, sentar, trabalhar e conversar para o astronauta estático atual.
- Aparência e comportamento distintos por NPC; habilidades/níveis com progressão, experiência, contratos de trabalho e demissão controlada.
- Interiores específicos por classe, especialmente área de carga maior no Atlas, equipamento científico no Horizonte/Sonda e ferramentas de salvamento no Ímã.
- Upgrades físicos modulares e visíveis; instrumentos do cockpit, portas animadas, feedback de coleta e regras de ocupação dos assentos.
- Refino da câmera e do olhar livre no cockpit, acessibilidade, remapeamento de teclas e controle por gamepad.

## Etapa 5 — Direção visual e desempenho medido

- Expandir Nova Terra de distrito compacto para uma cidade cenográfica mais convincente; ampliar ambiente industrial, isolamento do planeta inexplorado, hologramas, poeira e ambientação sonora.
- Refinar materiais PBR, texturas/atlases comprimidos, iluminação cinematográfica, reflexos e efeitos. A base atual usa materiais metálicos/emissivos e modelos estilizados; não é acabamento fotorrealista final.
- Preparar cenários estáticos apropriados para iluminação baked e bake de occlusion culling. Habilitar a opção na câmera, sozinho, não produz dados de oclusão.
- Criar LODs artísticos específicos, combinar malhas por material, testar instancing, impostors distantes e limites dinâmicos de renderização.
- Medir CPU, GPU, memória, draw calls e pausas de carregamento em hardware intermediário identificado. Definir metas a partir dessas medições; não assumir FPS apenas pelo número de triângulos.
- Reduzir pausas de transição conforme o perfil real, preservando o carregamento por setores e o escopo de zonas exploráveis limitadas.

Saída esperada: comparação reproduzível de qualidade/desempenho antes e depois das mudanças, seguida por uma versão Windows testada. Multiplayer, galáxia procedural e planetas inteiros sem transição ficam fora deste roadmap inicial.

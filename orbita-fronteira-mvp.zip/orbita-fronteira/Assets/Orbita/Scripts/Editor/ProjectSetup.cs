using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Orbita.Runtime;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

namespace Orbita.Editor
{
    /// <summary>
    /// Creates missing project assets on the first import. Existing materials, prefabs,
    /// scenes and pipeline assets remain editable and are never regenerated in place.
    /// </summary>
    [InitializeOnLoad]
    public static class ProjectSetup
    {
        public const string BootstrapScenePath = "Assets/Orbita/Scenes/Bootstrap.unity";
        private const string SettingsFolder = "Assets/Orbita/Settings";
        private const string PipelinePath = SettingsFolder + "/OrbitaURP.asset";
        private const string RendererPath = SettingsFolder + "/OrbitaRenderer.asset";
        private const string ModelFolder = "Assets/Orbita/Art/Models";
        private const string MaterialFolder = "Assets/Orbita/Art/Materials";
        private const string PrefabFolder = "Assets/Orbita/Resources/Models";
        private const string RequiredUnity = "6000.0.62f1";
        private static readonly string[] ModelNames =
        {
            "Scout", "Hauler", "Explorer", "Courier", "Salvager", "Prospector",
            "Astronaut", "CityTower", "IndustrialRig", "RuinArch", "Station", "Crate", "Asteroid", "Beacon"
        };
        private static bool preparing;

        static ProjectSetup()
        {
            EditorApplication.delayCall += PrepareOnFirstImport;
        }

        private static void PrepareOnFirstImport()
        {
            // CLI entry points prepare explicitly, and no scene is opened while importing.
            if (Application.isBatchMode || EditorApplication.isPlayingOrWillChangePlaymode) return;
            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                EditorApplication.delayCall += PrepareOnFirstImport;
                return;
            }
            if (GeneratedAssetsExist()) return;
            try { PrepareProject(); }
            catch (Exception error)
            {
                Debug.LogError("Órbita: preparação incompleta. Corrija o erro e use Orbita/Preparar projeto.\n" + error);
            }
        }

        private static bool GeneratedAssetsExist()
        {
            return File.Exists(PipelinePath) && File.Exists(RendererPath) && File.Exists(BootstrapScenePath)
                && ModelNames.All(name => File.Exists(PrefabFolder + "/" + name + ".prefab"));
        }

        [MenuItem("Orbita/Preparar projeto", priority = 10)]
        public static void PrepareProject()
        {
            if (preparing) return;
            if (EditorApplication.isPlayingOrWillChangePlaymode)
                throw new InvalidOperationException("Pare o Play Mode antes de preparar o projeto.");
            preparing = true;
            try
            {
                ValidatePackages();
                EnsureFolder(SettingsFolder);
                EnsureFolder(MaterialFolder);
                EnsureFolder(PrefabFolder);
                EnsureFolder("Assets/Orbita/Scenes");
                bool firstSetup = !File.Exists(PipelinePath);
                UniversalRenderPipelineAsset pipeline = EnsurePipeline();
                ConfigureProjectDefaults(pipeline, firstSetup);
                Dictionary<string, MaterialRecipe> recipes = null;
                foreach (string name in ModelNames)
                {
                    string path = PrefabFolder + "/" + name + ".prefab";
                    if (File.Exists(path)) continue;
                    if (recipes == null) recipes = ReadMaterialManifest();
                    CreateModelPrefab(name, path, recipes);
                }
                EnsureBootstrapScene();
                EnsureBuildScene();
                AssetDatabase.SaveAssets();
                Debug.Log("Órbita preparada: URP, materiais, 14 modelos e Bootstrap. Assets existentes foram preservados.");
            }
            finally { preparing = false; }
        }

        [MenuItem("Orbita/Preparar projeto e Play", priority = 11)]
        public static void PrepareAndPlay()
        {
            PrepareProject();
            ValidatePreparedProject();
            // This is an explicit menu action: only here may setup replace the open scene.
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            EditorSceneManager.OpenScene(BootstrapScenePath, OpenSceneMode.Single);
            EditorApplication.EnterPlaymode();
        }

        [MenuItem("Orbita/Build Windows64", priority = 30)]
        public static void BuildWindows()
        {
            PrepareProject();
            ValidatePreparedProject();
            if (!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Standalone, BuildTarget.StandaloneWindows64))
                throw new BuildFailedException("Instale Windows Build Support para Unity " + RequiredUnity + " pelo Unity Hub.");
            string output = Path.Combine(ProjectRoot, "Builds", "Windows", "OrbitaFronteira.exe");
            Directory.CreateDirectory(Path.GetDirectoryName(output));
            BuildReport report = BuildPipeline.BuildPlayer(new BuildPlayerOptions
            {
                scenes = new[] { BootstrapScenePath },
                locationPathName = output,
                target = BuildTarget.StandaloneWindows64,
                options = BuildOptions.CompressWithLz4 | BuildOptions.StrictMode
            });
            if (report == null || report.summary.result != BuildResult.Succeeded)
                throw new BuildFailedException("Build Windows64 falhou: " +
                    (report == null ? "nenhum relatório retornado" : report.summary.result + " / " + report.summary.totalErrors + " erro(s)"));
            Debug.Log("Build Windows64 concluído: " + output + " (" + report.summary.totalSize + " bytes).");
        }

        private static UniversalRenderPipelineAsset EnsurePipeline()
        {
            var renderer = AssetDatabase.LoadAssetAtPath<UniversalRendererData>(RendererPath);
            if (!renderer)
            {
                RefuseExistingUnknownAsset(RendererPath);
                renderer = ScriptableObject.CreateInstance<UniversalRendererData>();
                renderer.name = "Orbita Renderer";
                renderer.postProcessData = AssetDatabase.LoadAssetAtPath<PostProcessData>(
                    "Packages/com.unity.render-pipelines.universal/Runtime/Data/PostProcessData.asset");
                AssetDatabase.CreateAsset(renderer, RendererPath);
                // Same resource initialization used by URP's official renderer-asset factory.
                ResourceReloader.ReloadAllNullIn(renderer, "Packages/com.unity.render-pipelines.universal");
                EditorUtility.SetDirty(renderer);
            }
            var pipeline = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(PipelinePath);
            if (pipeline) return pipeline;
            RefuseExistingUnknownAsset(PipelinePath);
            pipeline = UniversalRenderPipelineAsset.Create(renderer);
            pipeline.name = "Orbita URP";
            pipeline.renderScale = 1f;
            pipeline.msaaSampleCount = 2;
            pipeline.supportsHDR = false;
            pipeline.mainLightShadowmapResolution = 2048;
            pipeline.shadowDistance = 90f;
            pipeline.shadowCascadeCount = 2;
            pipeline.maxAdditionalLightsCount = 4;
            AssetDatabase.CreateAsset(pipeline, PipelinePath);
            return pipeline;
        }

        private static void ConfigureProjectDefaults(UniversalRenderPipelineAsset pipeline, bool firstSetup)
        {
            // Keep a user's custom rendering pipeline and quality overrides intact.
            if (!GraphicsSettings.defaultRenderPipeline) GraphicsSettings.defaultRenderPipeline = pipeline;
            if (!QualitySettings.renderPipeline && GraphicsSettings.defaultRenderPipeline == pipeline)
                QualitySettings.renderPipeline = pipeline;
            if (!firstSetup) return;
            PlayerSettings.companyName = "Orbita Studio";
            PlayerSettings.productName = "Orbita Fronteira";
            PlayerSettings.colorSpace = ColorSpace.Linear;
            PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Standalone, "com.orbitastudio.orbitafronteira");
            PlayerSettings.defaultScreenWidth = 1280;
            PlayerSettings.defaultScreenHeight = 720;
            PlayerSettings.fullScreenMode = FullScreenMode.FullScreenWindow;
            PlayerSettings.runInBackground = false;
            var settings = new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/ProjectSettings.asset"));
            SerializedProperty input = settings.FindProperty("activeInputHandler");
            if (input == null) throw new InvalidOperationException("A versão do Editor não expõe activeInputHandler. Use Unity " + RequiredUnity + ".");
            input.intValue = 0; // Input Manager, required by the dependency-free runtime controls.
            settings.ApplyModifiedPropertiesWithoutUndo();
            QualitySettings.vSyncCount = 1;
            QualitySettings.antiAliasing = 0; // URP controls MSAA in its own asset.
            QualitySettings.pixelLightCount = 4;
            QualitySettings.shadowResolution = ShadowResolution.Medium;
            QualitySettings.shadowDistance = 90f;
            QualitySettings.lodBias = 1f;
            QualitySettings.realtimeReflectionProbes = false;
            QualitySettings.anisotropicFiltering = AnisotropicFiltering.Enable;
        }

        private static void CreateModelPrefab(string name, string path, Dictionary<string, MaterialRecipe> recipes)
        {
            string modelPath = ModelFolder + "/" + name + ".fbx";
            var source = AssetDatabase.LoadAssetAtPath<GameObject>(modelPath);
            if (!source)
            {
                AssetDatabase.ImportAsset(modelPath, ImportAssetOptions.ForceSynchronousImport);
                source = AssetDatabase.LoadAssetAtPath<GameObject>(modelPath);
            }
            if (!source) throw new InvalidOperationException("FBX ausente ou importação inválida: " + modelPath);
            Scene preview = EditorSceneManager.NewPreviewScene();
            try
            {
                var root = new GameObject(name);
                SceneManager.MoveGameObjectToScene(root, preview);
                var visual = (GameObject)PrefabUtility.InstantiatePrefab(source, preview);
                visual.name = name + " Visual";
                visual.transform.SetParent(root.transform, false);
                visual.transform.localPosition = Vector3.zero;
                foreach (Renderer target in visual.GetComponentsInChildren<Renderer>(true))
                {
                    Material[] materials = target.sharedMaterials;
                    for (int i = 0; i < materials.Length; i++)
                    {
                        if (!materials[i]) throw new InvalidOperationException(name + ": slot de material vazio em " + target.name);
                        string materialName = FindMaterialName(materials[i].name, recipes);
                        materials[i] = EnsureMaterial(materialName, recipes[materialName]);
                    }
                    target.sharedMaterials = materials;
                    PrefabUtility.RecordPrefabInstancePropertyModifications(target);
                }
                if (Array.IndexOf(ModelNames, name) < 6) OrientShip(root.transform, visual.transform);
                if (name == "Astronaut") GroundAstronaut(visual.transform);
                PrefabUtility.RecordPrefabInstancePropertyModifications(visual.transform);
                PrefabUtility.SaveAsPrefabAsset(root, path, out bool success);
                if (!success) throw new InvalidOperationException("Não foi possível salvar o prefab " + path);
            }
            finally { EditorSceneManager.ClosePreviewScene(preview); }
        }

        private static void OrientShip(Transform root, Transform visual)
        {
            Transform nose = FindMarker(visual, "Nose light");
            Transform rear = FindMarker(visual, "Aft boarding threshold");
            if (!nose || !rear) throw new InvalidOperationException("O FBX da nave não contém os marcadores Nose light / Aft boarding threshold.");
            float forward = root.InverseTransformPoint(nose.position).z;
            float aft = root.InverseTransformPoint(rear.position).z;
            if (forward < aft) visual.localRotation = Quaternion.Euler(0f, 180f, 0f) * visual.localRotation;
            if (root.InverseTransformPoint(nose.position).z <= root.InverseTransformPoint(rear.position).z)
                throw new InvalidOperationException("Não foi possível alinhar a proa da nave com +Z.");
        }

        private static Transform FindMarker(Transform root, string marker)
        {
            string normalized = marker.Replace(" ", "").ToLowerInvariant();
            return root.GetComponentsInChildren<Transform>(true).FirstOrDefault(t =>
                t.name.Replace(" ", "").Replace("_", "").ToLowerInvariant().StartsWith(normalized, StringComparison.Ordinal));
        }

        private static void GroundAstronaut(Transform visual)
        {
            Bounds bounds = VisualBounds(visual);
            if (bounds.size.y < 0.0001f) throw new InvalidOperationException("O astronauta não tem altura válida.");
            // Manifest contract: 1.91 m, feet at Y=0. Keep the resource root at identity.
            if (Mathf.Abs(bounds.size.y - 1.91f) > 0.03f)
            {
                visual.localScale *= 1.91f / bounds.size.y;
                bounds = VisualBounds(visual);
            }
            visual.position -= Vector3.up * bounds.min.y;
        }

        private static Bounds VisualBounds(Transform visual)
        {
            Renderer[] renderers = visual.GetComponentsInChildren<Renderer>(true);
            if (renderers.Length == 0) throw new InvalidOperationException("Modelo sem malhas: " + visual.name);
            Bounds bounds = renderers[0].bounds;
            for (int i = 1; i < renderers.Length; i++) bounds.Encapsulate(renderers[i].bounds);
            return bounds;
        }

        private static Material EnsureMaterial(string name, MaterialRecipe recipe)
        {
            string path = MaterialFolder + "/" + name + ".mat";
            Material existing = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (existing) return existing;
            RefuseExistingUnknownAsset(path);
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            if (!shader) throw new InvalidOperationException("Shader URP/Lit indisponível. Aguarde a importação do pacote URP.");
            if (recipe == null || recipe.base_color == null || recipe.base_color.Length != 4)
                throw new InvalidOperationException("Material inválido no asset_manifest.json: " + name);
            var color = new Color(recipe.base_color[0], recipe.base_color[1], recipe.base_color[2], recipe.base_color[3]);
            var material = new Material(shader) { name = name };
            material.SetColor("_BaseColor", color);
            material.SetFloat("_Metallic", recipe.metallic);
            material.SetFloat("_Smoothness", 1f - recipe.roughness);
            if (recipe.emission > 0f)
            {
                material.EnableKeyword("_EMISSION");
                material.SetColor("_EmissionColor", color * recipe.emission);
                material.globalIlluminationFlags = MaterialGlobalIlluminationFlags.BakedEmissive;
            }
            AssetDatabase.CreateAsset(material, path);
            return material;
        }

        private static string FindMaterialName(string importedName, Dictionary<string, MaterialRecipe> recipes)
        {
            if (recipes.ContainsKey(importedName)) return importedName;
            foreach (string name in recipes.Keys)
                if (importedName.StartsWith(name + ".", StringComparison.Ordinal)
                    || importedName.StartsWith(name + " (", StringComparison.Ordinal)) return name;
            throw new InvalidOperationException("Material do FBX não consta no manifesto: " + importedName);
        }

        private static void EnsureBootstrapScene()
        {
            if (File.Exists(BootstrapScenePath)) return;
            Scene previous = SceneManager.GetActiveScene();
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            try
            {
                SceneManager.SetActiveScene(scene);
                var bootstrap = new GameObject("OrbitaGame");
                bootstrap.AddComponent<OrbitaGame>();
                if (!EditorSceneManager.SaveScene(scene, BootstrapScenePath))
                    throw new InvalidOperationException("Não foi possível salvar " + BootstrapScenePath);
            }
            finally
            {
                if (previous.IsValid() && previous.isLoaded) SceneManager.SetActiveScene(previous);
                EditorSceneManager.CloseScene(scene, true);
            }
        }

        private static void EnsureBuildScene()
        {
            var scenes = new List<EditorBuildSettingsScene>(EditorBuildSettings.scenes);
            if (scenes.Any(scene => scene.path == BootstrapScenePath)) return;
            scenes.Insert(0, new EditorBuildSettingsScene(BootstrapScenePath, true));
            EditorBuildSettings.scenes = scenes.ToArray();
        }

        private static void ValidatePreparedProject()
        {
            ValidatePackages();
            if (!(GraphicsSettings.defaultRenderPipeline is UniversalRenderPipelineAsset)
                || (QualitySettings.renderPipeline && !(QualitySettings.renderPipeline is UniversalRenderPipelineAsset)))
                throw new BuildFailedException("Selecione um asset Universal Render Pipeline nas configurações Graphics e Quality.");
            RenderPipelineAsset activePipeline = QualitySettings.renderPipeline
                ? QualitySettings.renderPipeline : GraphicsSettings.defaultRenderPipeline;
            var pipelineSettings = new SerializedObject(activePipeline);
            SerializedProperty rendererList = pipelineSettings.FindProperty("m_RendererDataList");
            SerializedProperty defaultRenderer = pipelineSettings.FindProperty("m_DefaultRendererIndex");
            if (rendererList == null || defaultRenderer == null || defaultRenderer.intValue < 0
                || defaultRenderer.intValue >= rendererList.arraySize
                || !rendererList.GetArrayElementAtIndex(defaultRenderer.intValue).objectReferenceValue)
                throw new BuildFailedException("O asset URP ativo precisa de um renderer padrão válido.");
            var settings = new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/ProjectSettings.asset"));
            SerializedProperty input = settings.FindProperty("activeInputHandler");
            if (input == null || input.intValue == 1)
                throw new BuildFailedException("Os controles precisam de Active Input Handling = Input Manager (Old) ou Both.");
            foreach (string name in ModelNames)
            {
                var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(PrefabFolder + "/" + name + ".prefab");
                if (!prefab || prefab.GetComponentsInChildren<Renderer>(true).Length == 0)
                    throw new BuildFailedException("Prefab ausente ou sem malhas: " + name);
                foreach (Renderer renderer in prefab.GetComponentsInChildren<Renderer>(true))
                    foreach (Material material in renderer.sharedMaterials)
                        if (!material || !material.shader || material.shader.name == "Hidden/InternalErrorShader")
                            throw new BuildFailedException("Material inválido em " + name + "/" + renderer.name);
            }
            if (!AssetDatabase.LoadAssetAtPath<SceneAsset>(BootstrapScenePath))
                throw new BuildFailedException("Cena Bootstrap ausente: " + BootstrapScenePath);
            Scene preview = EditorSceneManager.OpenPreviewScene(BootstrapScenePath);
            try
            {
                if (!preview.GetRootGameObjects().Any(root => root.GetComponentInChildren<OrbitaGame>(true)))
                    throw new BuildFailedException("Bootstrap precisa de um componente OrbitaGame.");
            }
            finally { EditorSceneManager.ClosePreviewScene(preview); }
        }

        private static void ValidatePackages()
        {
            if (Application.unityVersion != RequiredUnity)
                Debug.LogWarning("Projeto preparado para Unity " + RequiredUnity + "; Editor atual: " + Application.unityVersion + ".");
            UnityEditor.PackageManager.PackageInfo[] packages = UnityEditor.PackageManager.PackageInfo.GetAllRegisteredPackages();
            RequirePackage(packages, "com.unity.render-pipelines.universal", "17.0.3");
            RequirePackage(packages, "com.unity.ai.navigation", "2.0.5");
        }

        private static void RequirePackage(UnityEditor.PackageManager.PackageInfo[] packages, string name, string version)
        {
            var found = packages.FirstOrDefault(package => package.name == name);
            if (found == null || found.version != version)
                throw new BuildFailedException("Pacote necessário: " + name + " " + version + ". Confira Packages/manifest.json e conclua a resolução pelo Package Manager.");
        }

        private static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path)) return;
            string parent = Path.GetDirectoryName(path).Replace('\\', '/');
            EnsureFolder(parent);
            AssetDatabase.CreateFolder(parent, Path.GetFileName(path));
        }

        private static void RefuseExistingUnknownAsset(string path)
        {
            if (File.Exists(path)) throw new InvalidOperationException("Asset existente inválido ou de outro tipo; preservado sem sobrescrever: " + path);
        }

        private static string ProjectRoot => Path.GetFullPath(Path.Combine(Application.dataPath, ".."));

        // JsonUtility handles this fixed-schema object without relying on dictionary support.
        [Serializable] private sealed class Manifest { public MaterialTable materials; }
        [Serializable] private sealed class MaterialRecipe
        {
            public float[] base_color;
            public float metallic;
            public float roughness;
            public float emission;
        }
        [Serializable] private sealed class MaterialTable
        {
            public MaterialRecipe HullIvory, HullGraphite, PanelSteel, GlassTeal;
            public MaterialRecipe EngineCyan, SignalAmber, SignalRed;
            public MaterialRecipe ScoutTeal, HaulerAmber, ExplorerBlue, CourierRed, SalvagerYellow, ProspectorPurple;
            public MaterialRecipe AstronautFabric, VisorGold, DustStone, CityConcrete;
        }

        private static Dictionary<string, MaterialRecipe> ReadMaterialManifest()
        {
            string path = Path.Combine(ProjectRoot, "ArtSource", "Blender", "asset_manifest.json");
            if (!File.Exists(path)) throw new FileNotFoundException("O manifesto original de materiais é necessário para gerar os prefabs.", path);
            MaterialTable table = JsonUtility.FromJson<Manifest>(File.ReadAllText(path))?.materials;
            if (table == null) throw new InvalidOperationException("O asset_manifest.json não contém a tabela materials.");
            return new Dictionary<string, MaterialRecipe>
            {
                { "HullIvory", table.HullIvory }, { "HullGraphite", table.HullGraphite },
                { "PanelSteel", table.PanelSteel }, { "GlassTeal", table.GlassTeal },
                { "EngineCyan", table.EngineCyan }, { "SignalAmber", table.SignalAmber }, { "SignalRed", table.SignalRed },
                { "ScoutTeal", table.ScoutTeal }, { "HaulerAmber", table.HaulerAmber }, { "ExplorerBlue", table.ExplorerBlue },
                { "CourierRed", table.CourierRed }, { "SalvagerYellow", table.SalvagerYellow }, { "ProspectorPurple", table.ProspectorPurple },
                { "AstronautFabric", table.AstronautFabric }, { "VisorGold", table.VisorGold },
                { "DustStone", table.DustStone }, { "CityConcrete", table.CityConcrete }
            };
        }
    }
}

using UnityEngine;

namespace Orbita.Runtime
{
    [RequireComponent(typeof(CharacterController))]
    public sealed class PlayerController : MonoBehaviour
    {
        OrbitaGame game;
        CharacterController motor;
        Transform visual;
        Camera view;
        float yaw, pitch = 16, vertical, pilotYaw, pilotPitch;
        bool seated;
        public Camera View => view;

        public void Initialize(OrbitaGame owner)
        {
            game = owner;
            motor = GetComponent<CharacterController>();
            motor.height = 1.85f;
            motor.radius = .3f;
            motor.center = new Vector3(0, .95f, 0);
            motor.stepOffset = .32f;
            motor.slopeLimit = 48;
            gameObject.layer = 8;
            var model = GameAssets.Model("Astronaut", transform, Vector3.zero);
            if (!model)
                model = GameAssets.Primitive("Astronaut placeholder", PrimitiveType.Capsule, transform,
                    new Vector3(0, .9f, 0), new Vector3(.65f, .9f, .65f),
                    GameAssets.Material("Suit", new Color(.75f, .82f, .85f)), false);
            visual = model.transform;
            foreach (var t in visual.GetComponentsInChildren<Transform>()) t.gameObject.layer = 8;
            view = new GameObject("Third person camera").AddComponent<Camera>();
            view.tag = "MainCamera";
            view.fieldOfView = 65;
            view.nearClipPlane = .08f;
            view.farClipPlane = 5000;
            view.allowHDR = true;
            view.useOcclusionCulling = true;
            view.gameObject.AddComponent<AudioListener>();
        }

        public void Teleport(Vector3 point, Transform parent = null)
        {
            motor.enabled = false;
            transform.SetParent(parent, true);
            transform.position = point;
            motor.enabled = !seated;
            vertical = 0;
        }

        public void Sit(Transform ship)
        {
            seated = true;
            pilotYaw = 0;
            pilotPitch = 0;
            motor.enabled = false;
            transform.SetParent(ship, false);
            transform.localPosition = new Vector3(0, 1.25f, 5.5f);
            transform.localRotation = Quaternion.identity;
            visual.localRotation = Quaternion.Euler(-12, 0, 0);
            visual.localScale = Vector3.one * .83f;
        }

        public void Stand(Transform ship)
        {
            seated = false;
            visual.localRotation = Quaternion.identity;
            visual.localScale = Vector3.one;
            Teleport(ship.TransformPoint(new Vector3(1.4f, 1.15f, 4)), ship);
            yaw = ship.eulerAngles.y;
        }

        void Update()
        {
            if (!game || game.State == null || game.IsTransitioning) return;
            bool input = game.Panel.Length == 0;
            Cursor.lockState = input ? CursorLockMode.Locked : CursorLockMode.None;
            Cursor.visible = !input;
            if (!input) return;
            if (Input.GetKeyDown(KeyCode.F5)) game.Execute("save");
            if (seated)
            {
                pilotYaw = Mathf.Clamp(pilotYaw + Input.GetAxisRaw("Mouse X") * 1.6f, -115, 115);
                pilotPitch = Mathf.Clamp(pilotPitch - Input.GetAxisRaw("Mouse Y") * 1.4f, -15, 50);
                return;
            }
            yaw += Input.GetAxisRaw("Mouse X") * 2.3f;
            pitch = Mathf.Clamp(pitch - Input.GetAxisRaw("Mouse Y") * 1.8f, -25, 65);
            float h = Input.GetAxisRaw("Horizontal"), v = Input.GetAxisRaw("Vertical");
            Vector3 inputDirection = Vector3.ClampMagnitude(new Vector3(h, 0, v), 1);
            Vector3 move = Quaternion.Euler(0, yaw, 0) * inputDirection;
            Vector3 up = transform.parent ? transform.parent.up : Vector3.up;
            move = Vector3.ProjectOnPlane(move, up).normalized * inputDirection.magnitude;
            if (move.sqrMagnitude > .001f)
                visual.rotation = Quaternion.Slerp(visual.rotation, Quaternion.LookRotation(move, up), Time.deltaTime * 12);
            if (motor.isGrounded && vertical < 0) vertical = -2;
            vertical -= 18 * Time.deltaTime;
            motor.Move((move * (Input.GetKey(KeyCode.LeftShift) ? 6 : 3.3f) + up * vertical) * Time.deltaTime);
            UpdateReferenceFrame();
            if (transform.position.y < -35 && game.IsDocked)
                Teleport(new Vector3(0, .2f, -22));
        }

        void UpdateReferenceFrame()
        {
            var ship = game.Ship.transform;
            Vector3 local = ship.InverseTransformPoint(transform.position);
            bool inside = Mathf.Abs(local.x) < 4.2f && local.z > -10 && local.z < 10 && local.y > .3f && local.y < 6;
            if (inside && transform.parent != ship) transform.SetParent(ship, true);
            else if (!inside && game.IsDocked && transform.parent == ship) transform.SetParent(null, true);
        }

        void LateUpdate()
        {
            if (!game || !view) return;
            if (seated)
            {
                var t = game.Ship.transform;
                Vector3 target = t.TransformPoint(Quaternion.Euler(pilotPitch, pilotYaw, 0) * new Vector3(0, 7.5f, -21));
                view.transform.position = Vector3.Lerp(view.transform.position, target, 1 - Mathf.Exp(-8 * Time.deltaTime));
                view.transform.rotation = Quaternion.LookRotation(t.TransformPoint(new Vector3(0, 3, 7)) - view.transform.position, t.up);
                view.fieldOfView = Mathf.Lerp(view.fieldOfView, 65 + Mathf.Min(13, game.Speed * .16f), Time.deltaTime * 2);
                return;
            }
            Vector3 focus = transform.position + (transform.parent ? transform.parent.up : Vector3.up) * 1.5f;
            Vector3 desired = focus + Quaternion.Euler(pitch, yaw, 0) * new Vector3(0, .3f, -3.2f);
            Vector3 diff = desired - focus;
            if (Physics.SphereCast(focus, .16f, diff.normalized, out var hit, diff.magnitude, ~(1 << 8), QueryTriggerInteraction.Ignore))
                desired = focus + diff.normalized * Mathf.Max(.35f, hit.distance - .1f);
            view.transform.position = desired;
            view.transform.LookAt(focus);
            view.fieldOfView = 65;
        }
    }
}

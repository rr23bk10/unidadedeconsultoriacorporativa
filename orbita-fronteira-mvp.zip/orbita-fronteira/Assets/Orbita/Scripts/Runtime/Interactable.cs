using UnityEngine;

namespace Orbita.Runtime
{
    public sealed class Interactable : MonoBehaviour
    {
        public string prompt;
        public string action;
        public string argument;
        public float range = 3.5f;

        public void Use(OrbitaGame game)
        {
            if (!game.IsTransitioning) game.Execute(action, argument);
        }
    }
}

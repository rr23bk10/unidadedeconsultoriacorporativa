using System.Collections.Generic;
using Orbita.Domain;
using UnityEngine;
using UnityEngine.AI;

namespace Orbita.Runtime
{
    public sealed class CrewController : MonoBehaviour
    {
        sealed class Walker { public Transform body; public NavMeshPath path; public int corner; public float pause; public Vector3 target; }
        readonly List<Walker> walkers = new List<Walker>();
        // Navigation is baked once in a stationary coordinate frame; corners are transformed into
        // the moving ship's local frame. This avoids rebaking a NavMesh every frame of flight.
        static readonly Vector3 NavOrigin = new Vector3(0, -10000, 0);
        NavMeshData data;
        NavMeshDataInstance instance;
        OrbitaGame game;

        public void Initialize(OrbitaGame owner)
        {
            game = owner;
            var settings = NavMesh.GetSettingsByIndex(0);
            if (settings.agentTypeID < 0) settings = NavMesh.CreateSettings();
            settings.agentRadius = .25f;
            settings.agentHeight = 1.7f;
            settings.agentClimb = .3f;
            settings.overrideVoxelSize = true;
            settings.voxelSize = .1f;
            var source = new NavMeshBuildSource
            {
                shape = NavMeshBuildSourceShape.Box,
                transform = Matrix4x4.TRS(new Vector3(0, .9f, 0), Quaternion.identity, Vector3.one),
                size = new Vector3(3.6f, .2f, 12), area = 0
            };
            data = NavMeshBuilder.BuildNavMeshData(settings, new List<NavMeshBuildSource> { source },
                new Bounds(new Vector3(0, 2, 0), new Vector3(8, 6, 20)), Vector3.zero, Quaternion.identity);
            if (data) instance = NavMesh.AddNavMeshData(data, NavOrigin, Quaternion.identity);
            Rebuild();
        }

        public void Rebuild()
        {
            foreach (var w in walkers) if (w.body) Destroy(w.body.gameObject);
            walkers.Clear();
            for (int i = 0; i < game.State.crew.Count; i++)
            {
                CrewMember crew = game.State.crew[i];
                var root = new GameObject(crew.name);
                root.transform.SetParent(game.Ship.transform, false);
                root.transform.localPosition = new Vector3(i % 2 == 0 ? -1.1f : 1.1f, 1.04f, -3 + i * 1.8f);
                var body = GameAssets.Model("Astronaut", root.transform, Vector3.zero, .94f);
                if (!body) GameAssets.Primitive("Crew body", PrimitiveType.Capsule, root.transform, new Vector3(0, .9f, 0), new Vector3(.6f, .9f, .6f), GameAssets.Material("Crew uniform", new Color(.22f, .38f, .5f)), false);
                var collider = root.AddComponent<CapsuleCollider>();
                collider.height = 1.75f; collider.center = Vector3.up * .9f; collider.radius = .27f;
                GameAssets.Interaction(root, "Conversar com " + crew.name + " / " + crew.role, "talk", crew.name + ": Estou a bordo como " + crew.role + ". Minha habilidade é " + crew.skill + ", nível " + crew.level + ". O salário por viagem é " + crew.wage + " créditos. Podemos conversar sobre rotas e oportunidades.");
                walkers.Add(new Walker { body = root.transform, path = new NavMeshPath(), pause = 1 + i });
            }
        }

        void Update()
        {
            if (!game || game.IsTransitioning || !instance.valid) return;
            foreach (var w in walkers)
            {
                if (w.pause > 0)
                {
                    w.pause -= Time.deltaTime;
                    if (w.pause > 0) continue;
                    w.target = new Vector3(Random.Range(-1.3f, 1.3f), 1.05f, Random.Range(-4.5f, 4.5f));
                    var start = w.body.localPosition + NavOrigin;
                    var end = w.target + NavOrigin;
                    if (NavMesh.SamplePosition(start, out var from, 2, NavMesh.AllAreas) &&
                        NavMesh.SamplePosition(end, out var to, 2, NavMesh.AllAreas) &&
                        NavMesh.CalculatePath(from.position, to.position, NavMesh.AllAreas, w.path) &&
                        w.path.status == NavMeshPathStatus.PathComplete) w.corner = 1;
                    else { w.pause = 2; continue; }
                }
                if (w.corner >= w.path.corners.Length) { w.pause = Random.Range(2, 6); continue; }
                Vector3 target = w.path.corners[w.corner] - NavOrigin;
                target.y = 1.04f;
                Vector3 direction = target - w.body.localPosition;
                if (direction.magnitude < .1f) { w.corner++; continue; }
                // Keep a little space around the human player in the central aisle.
                if (Vector3.Distance(w.body.position, game.Player.transform.position) < .9f) continue;
                w.body.localPosition = Vector3.MoveTowards(w.body.localPosition, target, Time.deltaTime * .7f);
                w.body.localRotation = Quaternion.Slerp(w.body.localRotation, Quaternion.LookRotation(direction, Vector3.up), Time.deltaTime * 3);
            }
        }

        void OnDestroy() { if (instance.valid) instance.Remove(); if (data) Destroy(data); }
    }
}

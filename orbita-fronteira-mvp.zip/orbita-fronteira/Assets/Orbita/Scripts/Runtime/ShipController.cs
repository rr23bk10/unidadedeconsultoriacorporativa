using System.Collections;
using Orbita.Domain;
using UnityEngine;

namespace Orbita.Runtime
{
    public sealed class ShipController : MonoBehaviour
    {
        OrbitaGame game;
        Transform shell;
        GameObject ramp, rearDoor;
        Vector3 velocity;
        public bool Piloting { get; private set; }
        public bool Docked { get; private set; } = true;
        public float Speed => velocity.magnitude;

        public void Initialize(OrbitaGame owner)
        {
            game = owner;
            var floor = GameAssets.Material("Deck", new Color(.075f, .1f, .13f), .65f);
            var wall = GameAssets.Material("Interior walls", new Color(.22f, .3f, .36f), .6f);
            var cyan = GameAssets.Material("Guide lights", GameAssets.Cyan, .2f, true);
            GameAssets.Box("Walkable deck", transform, new Vector3(0, .7f, 0), new Vector3(8, .6f, 20), floor);
            GameAssets.Box("Port wall", transform, new Vector3(-4.1f, 2.2f, 0), new Vector3(.25f, 2.5f, 20), wall);
            GameAssets.Box("Starboard wall", transform, new Vector3(4.1f, 2.2f, 0), new Vector3(.25f, 2.5f, 20), wall);
            GameAssets.Box("Cockpit sill", transform, new Vector3(0, 1.55f, 9.6f), new Vector3(8, 1.1f, .3f), wall);
            rearDoor = GameAssets.Box("Pressure door", transform, new Vector3(0, 2.25f, -9.8f), new Vector3(8, 2.6f, .3f), wall);
            rearDoor.SetActive(false);
            ramp = GameAssets.Box("Boarding ramp", transform, new Vector3(0, .45f, -12.4f), new Vector3(4, .2f, 5.4f), wall);
            ramp.transform.localRotation = Quaternion.Euler(-11, 0, 0);
            var seat = GameAssets.Box("Pilot chair", transform, new Vector3(0, 1.45f, 5.5f), new Vector3(.85f, .8f, .85f), wall);
            GameAssets.Box("Seat back", transform, new Vector3(0, 2.1f, 5.1f), new Vector3(.9f, 1.3f, .2f), floor);
            GameAssets.Interaction(seat, "Sentar e pilotar", "pilot");
            var console = GameAssets.Box("Flight console", transform, new Vector3(0, 1.75f, 7.2f), new Vector3(3.4f, 1.45f, .8f), floor);
            GameAssets.Interaction(console, "Sentar e acessar navegação", "pilot");
            GameAssets.Box("Flight screen", transform, new Vector3(0, 2.55f, 7.15f), new Vector3(2.7f, .08f, .65f), cyan, false);
            for (int side = -1; side <= 1; side += 2)
            {
                GameAssets.Box("Guide strip", transform, new Vector3(side * 3.7f, 1.025f, 0), new Vector3(.07f, .04f, 17), cyan, false);
                GameAssets.Box("Cargo storage", transform, new Vector3(side * 3.1f, 1.7f, -5.7f), new Vector3(1.35f, 1.4f, 2.8f), wall);
                GameAssets.Box("Crew bunk", transform, new Vector3(side * 3, 1.4f, -.7f), new Vector3(1.4f, .7f, 2.5f), floor);
                GameAssets.Box("Mattress", transform, new Vector3(side * 3, 1.8f, -.7f), new Vector3(1.3f, .15f, 2.4f), wall, false);
            }
            GameAssets.Label(transform, "ORBITA  /  FLIGHT DECK", new Vector3(0, 3.4f, 8.9f), .14f);
            GameAssets.Light(transform, new Vector3(0, 4, 3), GameAssets.Cyan, 2, 13);
            GameAssets.Light(transform, new Vector3(0, 4, -5), GameAssets.Amber, 1.2f, 10);
            RebuildShell();
        }

        public void RebuildShell()
        {
            if (shell) Destroy(shell.gameObject);
            var model = GameAssets.Model(game.State.activeShip.ToString(), transform, Vector3.zero);
            if (!model)
            {
                model = new GameObject("Ship exterior fallback");
                model.transform.SetParent(transform, false);
                for (int side = -1; side <= 1; side += 2)
                {
                    GameAssets.Box("Engine pod", model.transform, new Vector3(side * 5.1f, 1.5f, -3), new Vector3(1.7f, 2.1f, 13), GameAssets.Material("Exterior", GameAssets.Hull), false);
                    GameAssets.Box("Thruster", model.transform, new Vector3(side * 5.1f, 1.5f, -9.6f), new Vector3(1.2f, 1.2f, .2f), GameAssets.Material("Exhaust", GameAssets.Cyan, 0, true), false);
                }
            }
            shell = model.transform;
        }

        public void SetPiloting(bool value)
        {
            Piloting = value;
            if (value) game.Player.Sit(transform);
            else game.Player.Stand(transform);
        }

        public void SetDocked(bool value)
        {
            Docked = value;
            ramp.SetActive(value);
            rearDoor.SetActive(!value);
            velocity = Vector3.zero;
        }

        public IEnumerator VerticalMove(float height, float seconds)
        {
            Vector3 start = transform.position;
            Vector3 end = new Vector3(start.x, height, start.z);
            for (float t = 0; t < seconds; t += Time.deltaTime)
            {
                transform.position = Vector3.Lerp(start, end, Mathf.SmoothStep(0, 1, t / seconds));
                yield return null;
            }
            transform.position = end;
        }

        void Update()
        {
            if (!game || game.IsTransitioning || Docked) return;
            bool control = Piloting && game.Panel.Length == 0;
            if (control)
            {
                if (Input.GetKeyDown(KeyCode.F)) game.OpenPanel("navigation");
                if (Input.GetKeyDown(KeyCode.X)) game.Execute("stand");
                if (Input.GetKeyDown(KeyCode.R)) game.Execute("scan");
                if (Input.GetKeyDown(KeyCode.L)) game.Execute("land");
                float yaw = Input.GetAxisRaw("Horizontal") * 42 * Time.deltaTime;
                transform.Rotate(0, yaw, 0, Space.World);
                float lift = (Input.GetKey(KeyCode.E) ? 1 : 0) - (Input.GetKey(KeyCode.Q) ? 1 : 0);
                float speed = ShipCatalog.Get(game.State.activeShip).speed;
                Vector3 desired = transform.forward * Input.GetAxisRaw("Vertical") * speed + Vector3.up * lift * speed * .35f;
                if (game.State.fuel <= 0) desired = Vector3.zero;
                velocity = Vector3.MoveTowards(velocity, desired, speed * .5f * Time.deltaTime);
                if (velocity.sqrMagnitude > 1)
                    game.State.fuel = Mathf.Max(0, game.State.fuel - Time.deltaTime * .014f * (1 + speed / 100f));
            }
            else velocity = Vector3.MoveTowards(velocity, Vector3.zero, Time.deltaTime * 12);
            // Hull collision approximation keeps flight robust without dynamic rigidbodies on walkable interiors.
            float distance = velocity.magnitude * Time.deltaTime;
            if (distance > 0 && Physics.SphereCast(transform.position + Vector3.up * 2, 3.5f,
                velocity.normalized, out var hit, distance + 1, 1 << 9, QueryTriggerInteraction.Ignore))
            {
                game.State.hull = Mathf.Max(5, game.State.hull - velocity.magnitude * .12f);
                velocity *= -.15f;
            }
            transform.position += velocity * Time.deltaTime;
            if (transform.position.sqrMagnitude > 2500000)
            {
                transform.position = transform.position.normalized * 1450;
                velocity = Vector3.zero;
                game.Notify("Limite do setor. Use F para selecionar uma rota orbital.");
            }
        }
    }
}

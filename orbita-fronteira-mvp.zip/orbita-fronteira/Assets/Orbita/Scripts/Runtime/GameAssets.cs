using System.Collections.Generic;
using UnityEngine;

namespace Orbita.Runtime
{
    public static class GameAssets
    {
        static readonly Dictionary<string, Material> Materials = new Dictionary<string, Material>();

        public static Material Material(string name, Color color, float metal = .45f, bool glow = false)
        {
            if (Materials.TryGetValue(name, out var found)) return found;
            var shader = Shader.Find("Universal Render Pipeline/Lit");
            if (!shader) shader = Shader.Find("Standard");
            var m = new Material(shader) { name = name };
            m.color = color;
            if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor", color);
            if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", metal);
            if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", .45f);
            if (glow)
            {
                m.EnableKeyword("_EMISSION");
                m.SetColor("_EmissionColor", color * 2.5f);
                m.globalIlluminationFlags = MaterialGlobalIlluminationFlags.BakedEmissive;
            }
            Materials[name] = m;
            return m;
        }

        public static readonly Color Cyan = new Color(.05f, .8f, .95f);
        public static readonly Color Amber = new Color(1f, .48f, .1f);
        public static readonly Color Hull = new Color(.1f, .16f, .21f);

        public static GameObject Box(string name, Transform parent, Vector3 pos, Vector3 size, Material mat, bool collider = true)
            => Primitive(name, PrimitiveType.Cube, parent, pos, size, mat, collider);

        public static GameObject Primitive(string name, PrimitiveType type, Transform parent, Vector3 pos, Vector3 size, Material mat, bool collider = true)
        {
            var go = GameObject.CreatePrimitive(type);
            go.name = name;
            go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            go.transform.localScale = size;
            go.GetComponent<Renderer>().sharedMaterial = mat;
            if (!collider) Object.Destroy(go.GetComponent<Collider>());
            return go;
        }

        public static GameObject Model(string name, Transform parent, Vector3 pos, float scale = 1)
        {
            // Models are copied into Resources by the editor setup, never downloaded at runtime.
            var prefab = Resources.Load<GameObject>("Models/" + name);
            if (!prefab) return null;
            var go = Object.Instantiate(prefab, parent);
            go.name = name;
            go.transform.localPosition = pos;
            go.transform.localRotation = Quaternion.identity;
            go.transform.localScale = Vector3.one * scale;
            foreach (var c in go.GetComponentsInChildren<Collider>()) Object.Destroy(c);
            return go;
        }

        public static TextMesh Label(Transform parent, string text, Vector3 pos, float size = .25f, Color? color = null)
        {
            var go = new GameObject("Sign " + text);
            go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            // TextMesh faces -Z; city visitors approach along -Z.
            var tm = go.AddComponent<TextMesh>();
            var font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            tm.font = font;
            go.GetComponent<MeshRenderer>().sharedMaterial = font.material;
            tm.text = text;
            tm.characterSize = size;
            tm.fontSize = 48;
            tm.anchor = TextAnchor.MiddleCenter;
            tm.alignment = TextAlignment.Center;
            tm.color = color ?? Cyan;
            return tm;
        }

        public static Interactable Interaction(GameObject go, string prompt, string action, string argument = "")
        {
            var i = go.AddComponent<Interactable>();
            i.prompt = prompt;
            i.action = action;
            i.argument = argument;
            return i;
        }

        public static void Light(Transform parent, Vector3 pos, Color color, float intensity = 3, float range = 9)
        {
            var go = new GameObject("Practical light");
            go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            var light = go.AddComponent<Light>();
            light.type = LightType.Point;
            light.color = color;
            light.intensity = intensity;
            light.range = range;
            light.shadows = LightShadows.None;
        }
    }
}

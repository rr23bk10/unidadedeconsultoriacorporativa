using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Orbita.Domain;
using UnityEngine;

namespace Orbita.Runtime
{
    public static class SaveStore
    {
        [Serializable] sealed class Envelope { public int format = 1; public string payload; public string checksum; }
        public static string PathName => Path.Combine(Application.persistentDataPath, "orbita-save.json");
        public static bool Exists => File.Exists(PathName) || File.Exists(PathName + ".bak");
        static string Hash(string data)
        {
            using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(data))).Replace("-", "");
        }
        public static bool Write(GameState state, out string message)
        {
            try
            {
                if (!GameRules.Validate(state)) throw new InvalidDataException("Estado de jogo inválido.");
                Directory.CreateDirectory(Application.persistentDataPath);
                string payload = JsonUtility.ToJson(state);
                string json = JsonUtility.ToJson(new Envelope { payload = payload, checksum = Hash(payload) }, true);
                string temp = PathName + ".tmp";
                using (var fs = new FileStream(temp, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    byte[] bytes = Encoding.UTF8.GetBytes(json);
                    fs.Write(bytes, 0, bytes.Length);
                    fs.Flush(true);
                }
                if (File.Exists(PathName)) File.Replace(temp, PathName, PathName + ".bak");
                else File.Move(temp, PathName);
                message = "Progresso salvo. Retomada no porto ou na órbita do setor atual.";
                return true;
            }
            catch (Exception e) when (e is IOException || e is UnauthorizedAccessException || e is ArgumentException)
            { message = "Não foi possível salvar: " + e.Message; return false; }
        }
        public static bool Read(out GameState state, out string message)
        {
            state = null;
            foreach (string file in new[] { PathName, PathName + ".bak" })
            {
                if (!File.Exists(file)) continue;
                try
                {
                    string text = File.ReadAllText(file);
                    if (text.Length > 1000000) continue;
                    var envelope = JsonUtility.FromJson<Envelope>(text);
                    if (envelope == null || envelope.format != 1 || envelope.payload == null || Hash(envelope.payload) != envelope.checksum) continue;
                    var loaded = JsonUtility.FromJson<GameState>(envelope.payload);
                    if (!GameRules.Validate(loaded)) continue;
                    state = loaded;
                    message = file.EndsWith(".bak") ? "Backup do progresso recuperado." : "Progresso carregado.";
                    return true;
                }
                catch (Exception e) when (e is IOException || e is UnauthorizedAccessException || e is ArgumentException) { }
            }
            message = "Nenhum progresso íntegro e compatível foi encontrado.";
            return false;
        }
    }
}

using System;
using UnityEngine;

namespace Orbita.Runtime
{
    /// <summary>Fixed-capacity traffic pool. Recycles ships at the route endpoints without allocating in Update.</summary>
    public sealed class SectorTraffic : MonoBehaviour
    {
        struct Vessel
        {
            public Transform transform;
            public Renderer[] renderers;
            public Vector3 origin;
            public Vector3 direction;
            public float progress;
            public float length;
            public float speed;
            public bool visible;
        }

        Vessel[] vessels;
        Camera observer;
        float cullTimer;
        bool surface;

        public void Initialize(Transform sector, bool onSurface, int seed)
        {
            surface=onSurface;
            var random=new System.Random(seed);
            int count=onSurface ? 9 : 14;
            vessels=new Vessel[count];
            var hull=GameAssets.Material("Traffic hull", new Color(.17f,.24f,.30f), .7f);
            var thrust=GameAssets.Material("Traffic engine", GameAssets.Cyan, .3f, true);
            for(int i=0;i<count;i++)
            {
                var go=new GameObject("Pooled civilian transport "+i);
                go.transform.SetParent(transform, false);
                float span=onSurface ? 2.1f : 3.6f;
                GameAssets.Box("Fuselage",go.transform,Vector3.zero,new Vector3(span,span*.42f,span*2.6f),hull,false);
                GameAssets.Box("Wing",go.transform,new Vector3(0,0,-span*.25f),new Vector3(span*3.2f,span*.1f,span*.72f),hull,false);
                GameAssets.Box("Thruster",go.transform,new Vector3(0,0,-span*1.31f),new Vector3(span*.65f,span*.26f,span*.1f),thrust,false);
                float side=i%2==0 ? 1 : -1;
                var direction=new Vector3(side,0,.2f).normalized;
                float lane=(float)random.NextDouble();
                var origin=new Vector3(-side*410,onSurface ? 48+lane*65 : -100+lane*205,-150+i*44);
                vessels[i]=new Vessel
                {
                    transform=go.transform, renderers=go.GetComponentsInChildren<Renderer>(),
                    origin=origin,direction=direction,length=840,progress=(float)random.NextDouble()*840,
                    speed=onSurface ? 11+lane*17 : 20+lane*30, visible=true
                };
                go.transform.localRotation=Quaternion.LookRotation(direction);
                go.transform.localPosition=origin+direction*vessels[i].progress;
            }
        }

        void Update()
        {
            if(vessels==null) return;
            if(!observer) observer=Camera.main;
            cullTimer-=Time.deltaTime;
            bool cull=cullTimer<=0;
            if(cull) cullTimer=.4f;
            float distance=surface ? 520 : 1050;
            for(int i=0;i<vessels.Length;i++)
            {
                vessels[i].progress=Mathf.Repeat(vessels[i].progress+vessels[i].speed*Time.deltaTime,vessels[i].length);
                vessels[i].transform.localPosition=vessels[i].origin+vessels[i].direction*vessels[i].progress;
                if(!cull || !observer) continue;
                bool visible=(vessels[i].transform.position-observer.transform.position).sqrMagnitude<distance*distance;
                if(visible==vessels[i].visible) continue;
                vessels[i].visible=visible;
                foreach(var renderer in vessels[i].renderers) if(renderer) renderer.enabled=visible;
            }
        }
    }
}

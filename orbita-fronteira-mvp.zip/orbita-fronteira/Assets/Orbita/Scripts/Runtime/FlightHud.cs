using System;
using System.Collections.Generic;
using Orbita.Domain;
using UnityEngine;

namespace Orbita.Runtime
{
    /// <summary>Dependency-free cockpit and terminal UI. Every action goes through OrbitaGame.</summary>
    public sealed class FlightHud : MonoBehaviour
    {
        private OrbitaGame game;
        private readonly List<Texture2D> textures = new List<Texture2D>();
        private GUIStyle title, heading, body, muted, small, label, value, button, quietButton, dangerButton, card, badge;
        private Vector2 scroll;
        private string previousPanel = "";
        private bool confirmNewGame;
        private static readonly Color Navy = new Color(0.022f, 0.043f, 0.070f, 0.97f);
        private static readonly Color Surface = new Color(0.042f, 0.076f, 0.110f, 0.96f);
        private static readonly Color Cyan = new Color(0.27f, 0.91f, 0.92f);
        private static readonly Color Amber = new Color(1f, 0.72f, 0.32f);
        private static readonly Color Dim = new Color(0.54f, 0.65f, 0.73f);
        private static readonly ShipClass[] ShipClasses =
        {
            ShipClass.Scout, ShipClass.Hauler, ShipClass.Explorer,
            ShipClass.Courier, ShipClass.Salvager, ShipClass.Prospector
        };
        private static readonly Destination[] Destinations =
        {
            Destination.NovaTerra, Destination.Industrial, Destination.Uncharted,
            Destination.Station, Destination.Debris
        };

        public void Initialize(OrbitaGame owner)
        {
            game = owner;
        }

        private void OnGUI()
        {
            if (game == null || game.State == null) return;
            if (title == null) BuildStyles();
            Matrix4x4 oldMatrix = GUI.matrix;
            Color oldColor = GUI.color;
            Color oldContent = GUI.contentColor;
            bool oldEnabled = GUI.enabled;
            float scale = Mathf.Min(Screen.width / 1280f, Screen.height / 720f);
            Vector3 offset = new Vector3((Screen.width - 1280f * scale) * 0.5f, (Screen.height - 720f * scale) * 0.5f, 0f);
            GUI.matrix = Matrix4x4.TRS(offset, Quaternion.identity, new Vector3(scale, scale, 1f));
            GUI.color = Color.white;
            GUI.contentColor = Color.white;
            GUI.enabled = !game.IsTransitioning;

            DrawHeader();
            string panel = game.Panel ?? "";
            if (panel != previousPanel)
            {
                scroll = Vector2.zero;
                confirmNewGame = false;
                previousPanel = panel;
            }
            if (panel.Length == 0) DrawWorldHud();
            else DrawPanel(panel);
            DrawFooter(panel.Length > 0);
            if (!string.IsNullOrEmpty(game.LastMessage)) DrawToast();
            if (game.IsTransitioning) DrawTransition();

            GUI.matrix = oldMatrix;
            GUI.color = oldColor;
            GUI.contentColor = oldContent;
            GUI.enabled = oldEnabled;
        }

        private void DrawHeader()
        {
            Fill(new Rect(0, 0, 1280, 83), Navy);
            Fill(new Rect(0, 81, 1280, 2), new Color(Cyan.r, Cyan.g, Cyan.b, 0.32f));
            GUI.Label(new Rect(24, 13, 300, 27), "ÓRBITA / FRONTEIRA", title);
            GUI.Label(new Rect(25, 46, 320, 20), "EXPLORAÇÃO ESPACIAL  ·  SETOR AURORA", small);
            GUI.Label(new Rect(390, 15, 380, 24), game.PlaceName, heading);
            GUI.Label(new Rect(390, 43, 380, 21), ShipCatalog.Get(game.State.activeShip).displayName +
                (game.IsPiloting ? "  /  NO COMANDO" : "  /  A PÉ"), muted);
            GUI.Label(new Rect(897, 12, 175, 18), "CRÉDITOS DISPONÍVEIS", small);
            GUI.Label(new Rect(897, 33, 175, 30), game.State.credits.ToString("N0") + " CR", value);
            GUI.Label(new Rect(1101, 12, 150, 18), "PORÃO DE CARGA", small);
            GUI.Label(new Rect(1101, 35, 155, 27), GameRules.CargoUsed(game.State) + " / " +
                GameRules.CargoCapacity(game.State), heading);
        }

        private void DrawWorldHud()
        {
            Fill(new Rect(24, 107, 307, 157), Surface);
            Fill(new Rect(24, 107, 3, 157), Cyan);
            GUI.Label(new Rect(42, 120, 270, 20), "PRÓXIMO PASSO", small);
            GUI.Label(new Rect(42, 147, 267, 98), game.ObjectiveText(), body);

            var spec = ShipCatalog.Get(game.State.activeShip);
            Fill(new Rect(24, 466, 285, 169), Surface);
            GUI.Label(new Rect(42, 480, 245, 21), "SISTEMAS DA NAVE", small);
            Gauge(new Rect(42, 514, 248, 39), "COMBUSTÍVEL", game.State.fuel.ToString("0") + " / " +
                spec.fuelCapacity.ToString("0"), (float)game.State.fuel / Mathf.Max(1f, (float)spec.fuelCapacity), Cyan);
            Gauge(new Rect(42, 567, 248, 39), "INTEGRIDADE", game.State.hull.ToString("0") + "%",
                (float)game.State.hull / 100f, (float)game.State.hull < 30f ? Amber : Cyan);

            if (game.IsPiloting)
            {
                Fill(new Rect(976, 107, 280, 174), Surface);
                GUI.Label(new Rect(994, 120, 242, 21), "TELEMETRIA", small);
                GUI.Label(new Rect(994, 150, 242, 43), game.Speed.ToString("0") + " m/s", value);
                GUI.Label(new Rect(994, 200, 242, 50), game.IsDocked
                    ? "Pousada. Abra a navegação para escolher a próxima rota."
                    : "Voo livre. Explore o setor e aproxime-se dos sinais detectados.", muted);
                if (!string.IsNullOrEmpty(game.ScanHint))
                {
                    Fill(new Rect(949, 307, 307, 131), Surface);
                    GUI.Label(new Rect(967, 321, 270, 20), "SCANNER / SINAIS", small);
                    GUI.Label(new Rect(967, 350, 267, 69), game.ScanHint, body);
                }
                Fill(new Rect(626, 359, 9, 1), Cyan);
                Fill(new Rect(645, 359, 9, 1), Cyan);
                Fill(new Rect(639, 346, 1, 9), Cyan);
                Fill(new Rect(639, 365, 1, 9), Cyan);
            }
            else
            {
                Fill(new Rect(638, 358, 4, 4), new Color(0.8f, 1f, 1f, 0.75f));
            }

            if (!string.IsNullOrEmpty(game.InteractionPrompt))
            {
                Fill(new Rect(363, 520, 553, 71), Navy);
                GUI.Label(new Rect(380, 534, 518, 45), game.InteractionPrompt, body);
            }
        }

        private void DrawPanel(string panel)
        {
            Fill(new Rect(0, 83, 1280, 579), new Color(0.005f, 0.015f, 0.025f, 0.56f));
            Fill(new Rect(119, 103, 1042, 516), Navy);
            Fill(new Rect(119, 103, 1042, 3), Cyan);
            GUI.Label(new Rect(145, 120, 850, 34), PanelTitle(panel), title);
            GUI.Label(new Rect(146, 160, 850, 24), PanelSubtitle(panel), muted);
            if (GUI.Button(new Rect(1060, 121, 77, 33), "FECHAR", quietButton)) game.ClosePanel();
            Fill(new Rect(144, 195, 993, 1), new Color(0.16f, 0.25f, 0.31f));

            GUILayout.BeginArea(new Rect(144, 210, 993, 385));
            scroll = GUILayout.BeginScrollView(scroll, false, false);
            switch (panel)
            {
                case "jobs": DrawJobs(); break;
                case "market": DrawMarket(); break;
                case "workshop": DrawWorkshop(); break;
                case "dealership": DrawDealership(); break;
                case "crew": DrawCrew(true); break;
                case "navigation": DrawNavigation(); break;
                case "signals": DrawSignals(); break;
                case "journal": DrawJournal(); break;
                case "pause": DrawPause(); break;
                case "dialogue": DrawDialogue(); break;
                default: GUILayout.Label("Terminal conectado. Selecione uma operação disponível.", body); break;
            }
            GUILayout.EndScrollView();
            GUILayout.EndArea();
        }

        private void DrawJobs()
        {
            BeginCard();
            Eyebrow("LOGÍSTICA / CONTRATO LOCAL");
            GUILayout.Label("Uma entrega abre a fronteira", heading);
            GUILayout.Label("Aceite a carga em Nova Terra, leve-a ao complexo industrial e volte ao contratante para receber. A mercadoria ocupa espaço no porão até a entrega.", body);
            GUILayout.Label("Carga: " + GameRules.DeliveryQuantity + " unidades   ·   Recompensa: " + GameRules.DeliveryReward + " CR", label);
            GUILayout.Space(12);
            GUILayout.Label("01  NOVA TERRA     →     02  COMPLEXO INDUSTRIAL     →     03  NOVA TERRA", label);
            GUILayout.Space(14);
            var state = game.State;
            switch (state.deliveryStage)
            {
                case MissionStage.Available:
                    GUILayout.Label("Contrato disponível. O terminal verifica sua capacidade de carga ao aceitar.", muted);
                    ActionButton("ACEITAR ENTREGA", "accept-delivery", "", state.location == Destination.NovaTerra);
                    break;
                case MissionStage.Accepted:
                    GUILayout.Label("Carga a bordo. Entregue os materiais ao terminal do complexo industrial.", body);
                    ActionButton("ENTREGAR MATERIAIS", "deliver", "", state.location == Destination.Industrial);
                    break;
                case MissionStage.Delivered:
                    GUILayout.Label("Entrega confirmada. Volte a Nova Terra para concluir o contrato e receber.", body);
                    ActionButton("RECEBER PAGAMENTO", "claim", "", state.location == Destination.NovaTerra);
                    break;
                case MissionStage.Completed:
                    GUILayout.Label("CONTRATO CONCLUÍDO", badge);
                    GUILayout.Label("A rota está estabelecida. Comércio, salvamento e exploração continuam disponíveis.", muted);
                    break;
            }
            EndCard();
            BeginCard();
            Eyebrow("OPORTUNIDADES INDEPENDENTES");
            GUILayout.Label("Recupere sucata no campo de destroços, venda recursos nos mercados e use o scanner em setores desconhecidos. Nem toda descoberta aparece no diário antes de ser encontrada.", body);
            EndCard();
        }

        private void DrawMarket()
        {
            GUILayout.BeginHorizontal();
            GUILayout.BeginVertical(GUILayout.Width(550));
            BeginCard();
            Eyebrow("MANIFESTO DE CARGA");
            DrawCargo();
            EndCard();
            GUILayout.EndVertical();
            GUILayout.Space(16);
            GUILayout.BeginVertical();
            BeginCard();
            Eyebrow("BALCÃO DE COMPRA");
            GUILayout.Label("Transforme exploração em recursos", heading);
            GUILayout.Label("Venda a sucata recuperada e os minerais raros extraídos. A carga do contrato é entregue no terminal de empregos.", body);
            GUILayout.Label("Sucata: " + GameRules.SalvageUnitPrice + " CR / un.\nMinério raro: " + GameRules.RareUnitPrice + " CR / un.", label);
            ActionButton("VENDER SUCATA", "sell");
            ActionButton("VENDER MINERAIS RAROS", "sell-rare");
            EndCard();
            GUILayout.EndVertical();
            GUILayout.EndHorizontal();
        }

        private void DrawWorkshop()
        {
            BeginCard();
            Eyebrow("OFICINA / SERVIÇOS LOCAIS");
            GUILayout.Label(ShipCatalog.Get(game.State.activeShip).displayName, heading);
            GUILayout.Label("Abasteça antes de viajar, restaure o casco e invista em melhorias para ampliar a capacidade operacional da nave.", body);
            GUILayout.Space(12);
            GUILayout.Label("Combustível: " + game.State.fuel.ToString("0") + "   ·   Integridade: " + game.State.hull.ToString("0") + "%   ·   Porão: " +
                GameRules.CargoUsed(game.State) + " / " + GameRules.CargoCapacity(game.State), label);
            GUILayout.Space(13);
            GUILayout.BeginHorizontal();
            ActionButton("REABASTECER", "refuel");
            GUILayout.Space(10);
            ActionButton("REPARAR CASCO", "repair");
            GUILayout.Space(10);
            ActionButton("MELHORAR NAVE", "upgrade");
            GUILayout.EndHorizontal();
            GUILayout.Label("Cada serviço usa seus créditos. Consulte o retorno do terminal para o resultado da operação.", muted);
            EndCard();
        }

        private void DrawDealership()
        {
            GUILayout.Label("SEIS NAVES. SEIS MANEIRAS DE CRUZAR A FRONTEIRA.", label);
            GUILayout.Label("Comprar acrescenta uma nave à frota. Ative uma nave possuída para usá-la; sua carga precisa caber no novo porão.", muted);
            GUILayout.Space(12);
            for (int i = 0; i < ShipClasses.Length; i += 2)
            {
                GUILayout.BeginHorizontal();
                DrawShip(ShipClasses[i]);
                GUILayout.Space(14);
                DrawShip(ShipClasses[i + 1]);
                GUILayout.EndHorizontal();
                GUILayout.Space(10);
            }
        }

        private void DrawShip(ShipClass shipClass)
        {
            var spec = ShipCatalog.Get(shipClass);
            bool owned = game.State.ownedShips.Contains(shipClass);
            bool active = game.State.activeShip == shipClass;
            GUILayout.BeginVertical(card, GUILayout.Width(475));
            Eyebrow(ShipRole(shipClass));
            GUILayout.Label(spec.displayName, heading);
            GUILayout.Label(ShipDescription(shipClass), body, GUILayout.MinHeight(48));
            GUILayout.Space(10);
            GUILayout.Label("VELOCIDADE  " + spec.speed.ToString("0") + " m/s     PORÃO  " + spec.capacity, label);
            GUILayout.Label("TANQUE  " + spec.fuelCapacity.ToString("0") + "     SCANNER  " + spec.sensorRange.ToString("0") + " m", muted);
            GUILayout.Label("Combustível / salto: " + spec.travelFuelCost.ToString("0") + "   ·   Salvamento: ×" + spec.salvageMultiplier.ToString("0.##"), muted);
            GUILayout.Label("Extração de minério: " + spec.rareExtractionYield + " un. / operação", muted);
            GUILayout.Space(10);
            if (active) GUILayout.Label("NAVE ATIVA", badge);
            else if (owned) ActionButton("ATIVAR NAVE", "activate", shipClass.ToString());
            else ActionButton("COMPRAR  ·  " + spec.price.ToString("N0") + " CR", "buy", shipClass.ToString(), game.State.credits >= spec.price);
            GUILayout.EndVertical();
        }

        private void DrawCrew(bool canHire)
        {
            BeginCard();
            Eyebrow("EQUIPE EMBARCADA");
            if (game.State.crew.Count == 0) GUILayout.Label("Você está voando sozinho. Especialistas ampliam as possibilidades da sua nave.", body);
            foreach (var member in game.State.crew)
            {
                GUILayout.Label(member.name + "  ·  " + CrewRole(member.role.ToString()) + "  ·  Nível " + member.level, heading);
                GUILayout.Label("Habilidade: " + member.skill + "   /   Salário por viagem: " + member.wage + " CR", muted);
                GUILayout.Space(8);
            }
            EndCard();
            if (!canHire) return;
            GUILayout.Label("RECRUTAMENTO LOCAL", label);
            GUILayout.Space(8);
            CrewOffer("PILOTO", "Eficiência de navegação e consumo de combustível.", "pilot");
            CrewOffer("ENGENHEIRO", "Manutenção e proteção da integridade da nave.", "engineer");
            CrewOffer("ESPECIALISTA DE CARGA", "Organização do porão e capacidade logística.", "cargo");
            CrewOffer("EXPLORADOR", "Apoio ao scanner e às operações de descoberta.", "explorer");
            GUILayout.Label("Contratações e salários usam os créditos disponíveis; o terminal informa quando uma operação não pode ser concluída.", muted);
        }

        private void CrewOffer(string name, string description, string role)
        {
            BeginCard();
            GUILayout.BeginHorizontal();
            GUILayout.BeginVertical();
            GUILayout.Label(name, heading);
            GUILayout.Label(description, body);
            GUILayout.EndVertical();
            GUILayout.Space(18);
            if (GUILayout.Button("CONTRATAR", button, GUILayout.Width(155), GUILayout.Height(43))) game.Execute("hire", role);
            GUILayout.EndHorizontal();
            EndCard();
        }

        private void DrawNavigation()
        {
            var spec = ShipCatalog.Get(game.State.activeShip);
            BeginCard();
            Eyebrow("COMPUTADOR DE VOO");
            GUILayout.Label("Consumo base: " + spec.travelFuelCost.ToString("0") + " unidades. O custo final depende da distância e do piloto.", body);
            GUILayout.Label("Escolher um destino inicia a viagem. O computador verifica combustível, integridade e salários da tripulação.", muted);
            if (game.IsDocked) ActionButton("DECOLAR PARA EXPLORAR O SETOR ATUAL", "launch", "", game.IsPiloting);
            else ActionButton("TENTAR POUSO LOCAL", "land", "", game.IsPiloting);
            EndCard();
            foreach (Destination destination in Destinations)
            {
                bool current = game.State.location == destination;
                BeginCard();
                GUILayout.BeginHorizontal();
                GUILayout.BeginVertical();
                GUILayout.Label(DestinationName(destination) + (current ? "  /  SETOR ATUAL" : ""), heading);
                GUILayout.Label(DestinationDescription(destination), muted);
                if (!current) GUILayout.Label("Combustível: " + GameRules.TravelFuelCost(game.State, destination).ToString("0.##") +
                    "   ·   Salários: " + GameRules.CrewWages(game.State) + " CR", label);
                GUILayout.EndVertical();
                GUILayout.Space(18);
                bool enabled = GUI.enabled;
                GUI.enabled = enabled && !current && game.IsPiloting && !game.IsDocked;
                if (GUILayout.Button("VIAJAR", button, GUILayout.Width(145), GUILayout.Height(42))) game.Execute("travel", destination.ToString());
                GUI.enabled = enabled;
                GUILayout.EndHorizontal();
                EndCard();
            }
        }

        private void DrawSignals()
        {
            BeginCard();
            Eyebrow("SENSOR DE PROXIMIDADE");
            GUILayout.Label("Leia o setor ao seu redor", heading);
            GUILayout.Label(string.IsNullOrEmpty(game.ScanHint) ? "Use o scanner para localizar sinais próximos. Aproxime-se de um sinal no mundo para interagir." : game.ScanHint, body);
            GUILayout.Label("Alcance com tripulação: " + GameRules.SensorRange(game.State).ToString("0") + " m", muted);
            ActionButton("EXECUTAR VARREDURA", "scan", "", game.IsPiloting);
            EndCard();
        }

        private void DrawJournal()
        {
            BeginCard();
            Eyebrow("REGISTRO DA EXPEDIÇÃO");
            GUILayout.Label(game.ObjectiveText(), heading);
            GUILayout.Label("Contrato de entrega: " + DeliveryStatus(game.State.deliveryStage), body);
            GUILayout.Label("Descobertas registradas: " + game.State.explorationStage, muted);
            GUILayout.Label("Terminais de empregos, mercados, oficina, concessionária e recrutamento estão nos assentamentos. A navegação fica no cockpit.", muted);
            EndCard();
            BeginCard();
            Eyebrow("PORÃO / INVENTÁRIO");
            DrawCargo();
            EndCard();
            DrawCrew(false);
            BeginCard();
            Eyebrow("GUIA DE CAMPO");
            GUILayout.Label("A pé: WASD para caminhar, Shift para correr, mouse para olhar, R para scanner e E para interagir.\nNo cockpit: W/S avançam/recuam, A/D giram, Q/E controlam altitude, mouse orbita a câmera, F navegação, R scanner, G recuperação, L pouso e X levantar.\nTab abre o diário. Esc abre o menu. F5 salva o progresso.", body);
            EndCard();
        }

        private void DrawPause()
        {
            BeginCard();
            Eyebrow("SESSÃO LOCAL");
            GUILayout.Label("Sua próxima fronteira pode esperar", heading);
            GUILayout.Label("Salve a expedição para retomar depois. O arquivo fica no armazenamento local deste dispositivo.", body);
            GUILayout.Space(10);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("CONTINUAR", button, GUILayout.Height(42))) game.ClosePanel();
            GUILayout.Space(10);
            ActionButton("SALVAR PROGRESSO", "save");
            GUILayout.Space(10);
            ActionButton("CARREGAR SAVE", "load", "", game.HasSave);
            GUILayout.EndHorizontal();
            EndCard();
            BeginCard();
            Eyebrow("ASSISTÊNCIA DE VOO");
            GUILayout.Label("Resgate apenas quando a nave não puder viajar: retorne a Nova Terra, pague até 200 CR, perca a carga comercial e dispense a tripulação. A carga do contrato e o artefato são preservados.", body);
            ActionButton("SOLICITAR RESGATE", "rescue");
            EndCard();
            BeginCard();
            Eyebrow("RECOMEÇAR");
            if (!confirmNewGame)
            {
                GUILayout.Label("Inicie outra expedição do zero. Será necessário confirmar antes de apagar seu progresso atual.", muted);
                if (GUILayout.Button("NOVO JOGO…", quietButton, GUILayout.Height(37))) confirmNewGame = true;
            }
            else
            {
                GUILayout.Label("Confirmar novo jogo? O progresso atual será substituído.", body);
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("CONFIRMAR NOVO JOGO", dangerButton, GUILayout.Height(42)))
                {
                    confirmNewGame = false;
                    game.Execute("new");
                }
                GUILayout.Space(10);
                if (GUILayout.Button("CANCELAR", quietButton, GUILayout.Height(42))) confirmNewGame = false;
                GUILayout.EndHorizontal();
            }
            EndCard();
        }

        private void DrawDialogue()
        {
            BeginCard();
            Eyebrow("CONVERSA LOCAL");
            GUILayout.Label("Vozes da fronteira", heading);
            GUILayout.Label(game.DialogueText, body);
            ActionButton("OUVIU ALGUM RUMOR?", "rumor");
            ActionButton("COMO GANHAR A VIDA AQUI?", "trade-tip");
            EndCard();
            DrawCrew(false);
        }

        private void DrawCargo()
        {
            GUILayout.Label(GameRules.CargoUsed(game.State) + " / " + GameRules.CargoCapacity(game.State) + " unidades ocupadas", heading);
            if (game.State.cargo.Count == 0) GUILayout.Label("Porão vazio. Há espaço para o próximo trabalho.", muted);
            foreach (var stack in game.State.cargo)
            {
                GUILayout.BeginHorizontal();
                GUILayout.Label(CargoName(stack.id), body);
                GUILayout.FlexibleSpace();
                GUILayout.Label("× " + stack.quantity, label, GUILayout.Width(80));
                GUILayout.EndHorizontal();
            }
        }

        private void DrawFooter(bool panelOpen)
        {
            Fill(new Rect(0, 662, 1280, 58), Navy);
            GUI.Label(new Rect(24, 677, 1232, 28), panelOpen
                ? "ESC  fechar menu     ·     Role para ver todas as opções     ·     As ações são confirmadas no terminal"
                : game.IsPiloting
                    ? "WASD  voo     Q/E  altitude     MOUSE  olhar     F  rotas     R  scanner     G  recuperar     L  pousar     X  levantar     TAB  diário     ESC  menu"
                    : "WASD  caminhar     SHIFT  correr     MOUSE  olhar     E  interagir     TAB  diário     ESC  menu", small);
        }

        private void DrawToast()
        {
            Fill(new Rect(328, 622, 820, 35), Surface);
            Fill(new Rect(328, 622, 3, 35), Amber);
            GUI.Label(new Rect(341, 627, 794, 27), game.LastMessage, small);
        }

        private void DrawTransition()
        {
            float alpha = Mathf.Clamp01(game.TransitionAlpha);
            Fill(new Rect(-1280, -720, 3840, 2160), new Color(0.015f, 0.031f, 0.052f, alpha));
            if (alpha > 0.45f)
            {
                GUI.Label(new Rect(425, 320, 430, 40), "TRAVESSIA EM ANDAMENTO", title);
                GUI.Label(new Rect(459, 371, 370, 30), "Sincronizando a próxima fronteira…", muted);
            }
        }

        private void Gauge(Rect rect, string name, string amount, float fraction, Color color)
        {
            GUI.Label(new Rect(rect.x, rect.y, rect.width * 0.63f, 18), name, small);
            GUI.Label(new Rect(rect.x + rect.width * 0.65f, rect.y, rect.width * 0.35f, 18), amount, small);
            Fill(new Rect(rect.x, rect.y + 27, rect.width, 4), new Color(0.16f, 0.23f, 0.29f));
            Fill(new Rect(rect.x, rect.y + 27, rect.width * Mathf.Clamp01(fraction), 4), color);
        }

        private void ActionButton(string caption, string action, string argument = "", bool available = true)
        {
            bool enabled = GUI.enabled;
            GUI.enabled = enabled && available;
            if (GUILayout.Button(caption, button, GUILayout.MinHeight(41))) game.Execute(action, argument);
            GUI.enabled = enabled;
        }

        private void BeginCard() { GUILayout.BeginVertical(card); }
        private void EndCard() { GUILayout.EndVertical(); GUILayout.Space(12); }
        private void Eyebrow(string text) { GUILayout.Label(text, small); GUILayout.Space(7); }

        private static string PanelTitle(string panel)
        {
            switch (panel)
            {
                case "jobs": return "CENTRAL DE CONTRATOS";
                case "market": return "MERCADO DE RECURSOS";
                case "workshop": return "OFICINA ORBITAL";
                case "dealership": return "FROTA / CONCESSIONÁRIA";
                case "crew": return "RECRUTAMENTO";
                case "navigation": return "CARTA DE NAVEGAÇÃO";
                case "signals": return "SCANNER DE SETOR";
                case "journal": return "DIÁRIO DE BORDO";
                case "pause": return "EXPEDIÇÃO EM PAUSA";
                case "dialogue": return "CONVERSA A BORDO";
                default: return "TERMINAL";
            }
        }

        private string PanelSubtitle(string panel)
        {
            if (panel == "navigation") return "Cinco destinos conectados por uma fronteira em descoberta.";
            if (panel == "journal") return "Objetivos, carga e tripulação da sua expedição.";
            if (panel == "pause") return "Salvar, retomar ou reorganizar sua próxima partida.";
            return game.PlaceName + "  /  CONEXÃO LOCAL ESTABELECIDA";
        }

        private static string ShipRole(ShipClass ship)
        {
            switch (ship)
            {
                case ShipClass.Scout: return "01 / RECONHECIMENTO EQUILIBRADO";
                case ShipClass.Hauler: return "02 / TRANSPORTE DE CARGA";
                case ShipClass.Explorer: return "03 / EXPLORAÇÃO DE LONGO ALCANCE";
                case ShipClass.Courier: return "04 / INTERCEPTAÇÃO E ALTA VELOCIDADE";
                case ShipClass.Salvager: return "05 / SALVAMENTO DE DESTROÇOS";
                case ShipClass.Prospector: return "06 / PROSPECÇÃO DE MINERAIS";
                default: return "NAVE MULTIFUNÇÃO";
            }
        }

        private static string ShipDescription(ShipClass ship)
        {
            switch (ship)
            {
                case ShipClass.Scout: return "Leve e versátil. Um ponto de partida para contratos e os primeiros voos pela fronteira.";
                case ShipClass.Hauler: return "Porão amplo para operações comerciais. Troca agilidade por capacidade de transporte.";
                case ShipClass.Explorer: return "Tanque e sensores preparados para viagens longas e busca de sinais distantes.";
                case ShipClass.Courier: return "A super-rápida da frota. Percorra o setor em alta velocidade com uma nave compacta.";
                case ShipClass.Salvager: return "Especialista em recuperação. Aproveita melhor os destroços e leva mais sucata para vender.";
                case ShipClass.Prospector: return "Plataforma de mineração. Equipada para extrair minerais raros e financiar novas expedições.";
                default: return "Escolha sua próxima nave.";
            }
        }

        private static string DestinationName(Destination destination)
        {
            switch (destination)
            {
                case Destination.NovaTerra: return "NOVA TERRA";
                case Destination.Industrial: return "COMPLEXO INDUSTRIAL";
                case Destination.Uncharted: return "MUNDO NÃO CATALOGADO";
                case Destination.Station: return "ESTAÇÃO ORBITAL";
                case Destination.Debris: return "CAMPO DE DESTROÇOS";
                default: return destination.ToString();
            }
        }

        private static string DestinationDescription(Destination destination)
        {
            switch (destination)
            {
                case Destination.NovaTerra: return "Colônia de origem, contratos e serviços para preparar a nave.";
                case Destination.Industrial: return "Cadeia de suprimentos, entrega de materiais e atividade industrial.";
                case Destination.Uncharted: return "Território de exploração. Leia os sinais e investigue o desconhecido.";
                case Destination.Station: return "Um ponto de apoio orbital para tripulantes e viajantes.";
                case Destination.Debris: return "Salvamento e prospecção. Aproxime-se dos recursos para interagir.";
                default: return "Destino disponível.";
            }
        }

        private static string CargoName(string id)
        {
            switch (id)
            {
                case "salvage": case "scrap": return "Sucata recuperada";
                case "rare": case "rare-ore": case "rare_ore": return "Minerais raros";
                case "delivery_goods": case "delivery": case "supplies": case "mission-cargo": case "mission_cargo": return "Materiais do contrato";
                case "artifact": return "Artefato antigo";
                default: return id;
            }
        }

        private static string CrewRole(string role)
        {
            switch (role.ToLowerInvariant())
            {
                case "pilot": return "Piloto";
                case "engineer": return "Engenheiro";
                case "cargo": return "Especialista de carga";
                case "explorer": return "Explorador";
                default: return role;
            }
        }

        private static string DeliveryStatus(MissionStage stage)
        {
            switch (stage)
            {
                case MissionStage.Available: return "Disponível em Nova Terra";
                case MissionStage.Accepted: return "Em trânsito para o complexo industrial";
                case MissionStage.Delivered: return "Entregue; pagamento em Nova Terra";
                case MissionStage.Completed: return "Concluído";
                default: return stage.ToString();
            }
        }

        private void BuildStyles()
        {
            title = TextStyle(23, Color.white, FontStyle.Bold);
            heading = TextStyle(19, Color.white, FontStyle.Bold);
            body = TextStyle(16, new Color(0.84f, 0.9f, 0.94f));
            muted = TextStyle(14, Dim);
            small = TextStyle(12, Dim, FontStyle.Bold);
            label = TextStyle(14, Cyan, FontStyle.Bold);
            value = TextStyle(28, Cyan, FontStyle.Bold);
            badge = TextStyle(14, Amber, FontStyle.Bold);
            badge.padding = new RectOffset(0, 0, 8, 8);
            card = new GUIStyle(GUI.skin.box)
            {
                normal = { background = Solid(Surface) },
                padding = new RectOffset(17, 17, 15, 15),
                margin = new RectOffset(0, 0, 0, 0)
            };
            button = ButtonStyle(new Color(0.08f, 0.25f, 0.28f), Cyan);
            quietButton = ButtonStyle(new Color(0.07f, 0.12f, 0.17f), new Color(0.78f, 0.86f, 0.9f));
            dangerButton = ButtonStyle(new Color(0.30f, 0.13f, 0.09f), Amber);
        }

        private static GUIStyle TextStyle(int size, Color color, FontStyle fontStyle = FontStyle.Normal)
        {
            var style = new GUIStyle(GUI.skin.label)
            {
                fontSize = size,
                fontStyle = fontStyle,
                wordWrap = true,
                richText = false,
                padding = new RectOffset(0, 0, 0, 0),
                margin = new RectOffset(0, 0, 1, 5)
            };
            style.normal.textColor = color;
            return style;
        }

        private GUIStyle ButtonStyle(Color background, Color foreground)
        {
            var style = new GUIStyle(GUI.skin.button)
            {
                fontSize = 13,
                fontStyle = FontStyle.Bold,
                wordWrap = true,
                padding = new RectOffset(14, 14, 8, 8),
                margin = new RectOffset(0, 0, 8, 5),
                border = new RectOffset(0, 0, 0, 0)
            };
            style.normal.background = Solid(background);
            style.normal.textColor = foreground;
            style.hover.background = Solid(Color.Lerp(background, Cyan, 0.18f));
            style.hover.textColor = Color.white;
            style.active.background = Solid(Color.Lerp(background, Cyan, 0.35f));
            style.active.textColor = Color.white;
            style.focused.background = style.hover.background;
            style.focused.textColor = Color.white;
            return style;
        }

        private Texture2D Solid(Color color)
        {
            var texture = new Texture2D(1, 1) { hideFlags = HideFlags.HideAndDontSave };
            texture.SetPixel(0, 0, color);
            texture.Apply();
            textures.Add(texture);
            return texture;
        }

        private static void Fill(Rect rect, Color color)
        {
            Color previous = GUI.color;
            GUI.color = color;
            GUI.DrawTexture(rect, Texture2D.whiteTexture);
            GUI.color = previous;
        }

        private void OnDestroy()
        {
            foreach (Texture2D texture in textures)
                if (texture != null) Destroy(texture);
            textures.Clear();
        }
    }
}

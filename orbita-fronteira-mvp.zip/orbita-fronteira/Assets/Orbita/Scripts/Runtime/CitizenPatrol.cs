using UnityEngine;

namespace Orbita.Runtime
{
    /// <summary>Short, obstacle-free plaza routes. Crew use their separate ship-local NavMesh.</summary>
    public sealed class CitizenPatrol : MonoBehaviour
    {
        Vector3 origin;
        float phase, clock;
        public void Initialize(float offset) { origin = transform.localPosition; phase = offset; }
        void Update()
        {
            var player = Camera.main;
            if (player && Vector3.Distance(player.transform.position, transform.position) < 5) return;
            clock += Time.deltaTime * .18f;
            float progress = Mathf.Sin(clock + phase);
            transform.localPosition = origin + Vector3.forward * progress * 3;
            Quaternion facing = Quaternion.Euler(0, Mathf.Cos(clock + phase) >= 0 ? 0 : 180, 0);
            transform.localRotation = Quaternion.Slerp(transform.localRotation, facing, Time.deltaTime * 2);
        }
    }
}

using System;
using System.Collections;
using System.Collections.Generic;
using Orbita.Domain;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Orbita.Runtime
{
    /// <summary>Builds only the active destination. The ship, player and camera belong to the persistent bootstrap.</summary>
    public sealed class WorldBuilder : MonoBehaviour
    {
        public Transform SectorRoot { get; private set; }
        public bool Surface { get; private set; }
        public Destination Current { get; private set; }
        Scene sectorScene;
        Mesh starMesh;
        int generation;
        System.Random random;
        Material stone, steel, dark, cyan, amber;

        public static Vector3 CluePosition(int stage)
        {
            switch (stage)
            {
                case 1: return new Vector3(-38, 0, 68);
                case 2: return new Vector3(95, 0, 130);
                case 3: return new Vector3(135, 0, 184);
                default: return new Vector3(0, 1, 55);
            }
        }

        public IEnumerator Load(Destination destination, bool surface)
        {
            var oldScene = sectorScene;
            var oldRoot = SectorRoot;
            var oldStars = starMesh;
            Current = destination;
            Surface = surface;
            random = new System.Random(4171 + (int)destination * 913 + (surface ? 7 : 0));
            sectorScene = SceneManager.CreateScene("Sector_" + destination + "_" + (surface ? "Ground_" : "Orbit_") + (++generation));
            var root = new GameObject("Sector · " + destination);
            SceneManager.MoveGameObjectToScene(root, sectorScene);
            SectorRoot = root.transform;
            stone = GameAssets.Material("Basalt", new Color(.18f, .20f, .23f), .12f);
            steel = GameAssets.Material("Sector steel", new Color(.23f, .29f, .34f), .72f);
            dark = GameAssets.Material("Sector dark", new Color(.035f, .065f, .09f), .45f);
            cyan = GameAssets.Material("Wayfinding cyan", GameAssets.Cyan, .25f, true);
            amber = GameAssets.Material("Wayfinding amber", GameAssets.Amber, .25f, true);
            ConfigureLight(destination, surface);
            BuildSky(destination, surface);
            if (surface) BuildSurface(destination);
            else BuildOrbit(destination);
            if (oldRoot) oldRoot.gameObject.SetActive(false);
            if (oldScene.IsValid() && oldScene.isLoaded)
            {
                var unload = SceneManager.UnloadSceneAsync(oldScene);
                if (unload != null) yield return unload;
            }
            if (oldStars) Destroy(oldStars);
            yield return null;
        }

        void ConfigureLight(Destination destination, bool surface)
        {
            var sun = Child("Sector sun", SectorRoot);
            sun.transform.rotation = Quaternion.Euler(35, -35, 0);
            var light = sun.AddComponent<Light>();
            light.type = LightType.Directional;
            light.intensity = surface && destination != Destination.Station ? 1.65f : .85f;
            light.color = destination == Destination.Uncharted ? new Color(1f, .73f, .52f) : new Color(.74f, .84f, 1f);
            light.shadows = LightShadows.Soft;
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = surface ? new Color(.27f, .31f, .37f) : new Color(.12f, .17f, .24f);
            RenderSettings.fog = surface && destination != Destination.Station;
            RenderSettings.fogMode = FogMode.ExponentialSquared;
            RenderSettings.fogColor = destination == Destination.Uncharted ? new Color(.18f, .115f, .105f) : new Color(.055f, .115f, .16f);
            RenderSettings.fogDensity = .0018f;
        }

        void BuildSky(Destination destination, bool surface)
        {
            // A single mesh batches the starfield; reversed triangles keep stars visible from inside.
            var vertices = new List<Vector3>();
            var triangles = new List<int>();
            for (int i = 0; i < 380; i++)
            {
                float a = Next(0, Mathf.PI * 2), h = Next(-.95f, .95f);
                var center = new Vector3(Mathf.Cos(a) * Mathf.Sqrt(1-h*h), h, Mathf.Sin(a) * Mathf.Sqrt(1-h*h)) * 1600;
                var tangent = Vector3.Cross(center.normalized, Vector3.up).normalized * Next(.6f, 2.6f);
                var up = Vector3.Cross(center.normalized, tangent).normalized * tangent.magnitude;
                int start = vertices.Count;
                vertices.Add(center - tangent - up); vertices.Add(center + tangent - up); vertices.Add(center + up * 1.5f);
                triangles.Add(start); triangles.Add(start + 1); triangles.Add(start + 2);
                triangles.Add(start + 2); triangles.Add(start + 1); triangles.Add(start);
            }
            var mesh = new Mesh { name = "Batched deterministic starfield" };
            starMesh = mesh;
            mesh.SetVertices(vertices); mesh.SetTriangles(triangles, 0); mesh.RecalculateNormals(); mesh.RecalculateBounds();
            var stars = Child("Distant stars", SectorRoot);
            stars.AddComponent<MeshFilter>().sharedMesh = mesh;
            stars.AddComponent<MeshRenderer>().sharedMaterial = GameAssets.Material("Starlight", new Color(.55f, .7f, 1f), 0, true);
            var planetColor = destination == Destination.Uncharted ? new Color(.39f, .18f, .13f) : new Color(.05f, .28f, .39f);
            GameAssets.Primitive("Distant planet", PrimitiveType.Sphere, SectorRoot, new Vector3(650, surface ? 500 : -160, 1300), Vector3.one * 530, GameAssets.Material("Planet " + destination, planetColor, .1f), false);
            GameAssets.Primitive("Companion moon", PrimitiveType.Sphere, SectorRoot, new Vector3(-600, 440, 1300), Vector3.one * 120, stone, false);
            GameAssets.Primitive("White dwarf", PrimitiveType.Sphere, SectorRoot, new Vector3(950, 750, -950), Vector3.one * 35, GameAssets.Material("Dwarf emission", new Color(.65f, .8f, 1f), 0, true), false);
        }

        void BuildSurface(Destination destination)
        {
            bool wild = destination == Destination.Uncharted || destination == Destination.Debris;
            var soil = GameAssets.Material("Soil " + destination, wild ? new Color(.29f, .23f, .20f) : new Color(.10f, .14f, .17f), .12f);
            GameAssets.Box("Walkable terrain · 500 m", SectorRoot, new Vector3(0, -.6f, 0), new Vector3(500, 1.2f, 500), soil);
            LandingPad(wild);
            if (wild) BuildWilderness();
            else
            {
                BuildPlaza(destination);
                if (destination == Destination.Industrial) BuildIndustry();
                if (destination == Destination.Station) BuildStationDome();
                else BuildCitySilhouette(destination);
            }
            var traffic = Child("Recycled approach traffic", SectorRoot).AddComponent<SectorTraffic>();
            traffic.Initialize(SectorRoot, true, 4171 + (int)destination);
        }

        void LandingPad(bool wild)
        {
            var pad = GameAssets.Material("Landing concrete", new Color(.17f, .2f, .23f), .25f);
            GameAssets.Box("Dock apron", SectorRoot, new Vector3(0, .012f, 0), new Vector3(32, .024f, 40), pad, false);
            for (int side = -1; side <= 1; side += 2)
            {
                GameAssets.Box("Landing edge", SectorRoot, new Vector3(side * 15.5f, .034f, 0), new Vector3(.16f, .025f, 36), wild ? amber : cyan, false);
                for (int z = -16; z <= 16; z += 8)
                    GameAssets.Box("Dock guide", SectorRoot, new Vector3(side * 12, .04f, z), new Vector3(2.8f, .03f, .25f), amber, false);
                var beacon = GameAssets.Primitive("Dock beacon", PrimitiveType.Cylinder, SectorRoot, new Vector3(side * 18, .55f, -20), new Vector3(.45f, .55f, .45f), dark);
                GameAssets.Primitive("Beacon light", PrimitiveType.Sphere, beacon.transform, new Vector3(0, 1.05f, 0), Vector3.one * .6f, cyan, false);
            }
            // The exit lane at x = 0, z = -10..-30 stays clear for the ramp and player spawn.
            GameAssets.Box("Exit lane", SectorRoot, new Vector3(0, .028f, -28), new Vector3(.12f, .025f, 12), cyan, false);
        }

        void BuildPlaza(Destination destination)
        {
            GameAssets.Box("Public plaza", SectorRoot, new Vector3(0, .015f, -66), new Vector3(76, .025f, 83), steel, false);
            for (int i = 0; i < 7; i++)
                GameAssets.Box("Plaza paving seam", SectorRoot, new Vector3(0, .035f, -32-i*11), new Vector3(74, .018f, .06f), dark, false);
            var entries = new List<string[]>();
            if (destination == Destination.Industrial)
            {
                entries.Add(new[] { "BOLSA DE CARGAS", "jobs" });
                entries.Add(new[] { "MERCADO INDUSTRIAL", "market" });
                entries.Add(new[] { "OFICINA ORBITAL", "workshop" });
                entries.Add(new[] { "FERRO-VELHO", "market" });
                entries.Add(new[] { "PONTO DE RECRUTAMENTO", "crew" });
                entries.Add(new[] { "CANTINA DOS MINEIROS", "dialogue" });
            }
            else
            {
                entries.Add(new[] { "CONTRATOS DA FRONTEIRA", "jobs" });
                entries.Add(new[] { "MERCADO ESTELAR", "market" });
                entries.Add(new[] { "OFICINA ORBITAL", "workshop" });
                entries.Add(new[] { "HANGAR / NAVES", "dealership" });
                entries.Add(new[] { "AGENCIA DE TRIPULACAO", "crew" });
                entries.Add(new[] { "BAR ULTIMA ESTRELA", "dialogue" });
            }
            for (int i = 0; i < entries.Count; i++)
                Shop(new Vector3(i % 2 == 0 ? -25 : 25, 0, -43 - (i/2)*24), entries[i][0], entries[i][1], i);
            // Public kiosks leave both a wide central lane and access around each storefront.
            Terminal(new Vector3(-8, 0, -95), "PAINEL DE SERVICOS", "jobs", amber);
            Terminal(new Vector3(8, 0, -95), "BALCAO COMERCIAL", "market", cyan);
            BuildResidents(destination);
            for (int side = -1; side <= 1; side += 2)
                for (int i = 0; i < 4; i++)
                {
                    Vector3 p = new Vector3(side*11, 0, -36-i*19);
                    GameAssets.Box("Plaza lamp mast", SectorRoot, p+Vector3.up*2.6f, new Vector3(.18f, 5.2f, .18f), steel);
                    GameAssets.Box("Plaza lamp", SectorRoot, p+Vector3.up*5.2f, new Vector3(1.6f, .12f, .35f), cyan, false);
                    if (i%2 == 0) GameAssets.Light(SectorRoot, p+Vector3.up*4.5f, GameAssets.Cyan, 2, 13);
                }
        }

        void BuildResidents(Destination destination)
        {
            string[] names = { "Lia / despachante", "Ravi / mercador", "Nara / mecânica", "Ivo / trabalhador", "Mara / recrutadora", "Noa / explorador" };
            string[] lines = {
                "Lia: O balcão de contratos precisa de uma entrega na Colônia Industrial. Volte aqui depois para receber.",
                "Ravi: Compro material recuperado. Meu terminal fica no mercado; sucata e minério têm preços diferentes.",
                "Nara: Verifique o combustível antes de sair. Uma rota barata vira um prejuízo quando alguém precisa rebocar sua nave.",
                "Ivo: Os turnos da refinaria são longos. Há quem prefira arriscar os campos de destroços para ganhar por conta própria.",
                "Mara: Um bom piloto economiza combustível. Um operador de carga encontra espaço onde você só vê caixas.",
                "Noa: Nem todo mapa é uma cruz vermelha. Às vezes tudo o que você tem é uma direção, uma rocha e um sinal fraco."
            };
            for (int i = 0; i < names.Length; i++)
            {
                var root = Child(names[i], SectorRoot);
                root.transform.localPosition = new Vector3(i % 2 == 0 ? -15 : 15, .02f, -43 - (i / 2) * 22);
                var model = GameAssets.Model("Astronaut", root.transform, Vector3.zero, .98f);
                if (!model) GameAssets.Primitive("Resident", PrimitiveType.Capsule, root.transform, Vector3.up * .9f, new Vector3(.6f, .9f, .6f), steel, false);
                var collider = root.AddComponent<CapsuleCollider>();
                collider.center = Vector3.up * .95f; collider.height = 1.9f; collider.radius = .28f;
                GameAssets.Interaction(root, "Conversar com " + names[i], "talk", lines[i]);
                root.AddComponent<CitizenPatrol>().Initialize(i * .9f);
            }
        }

        void Shop(Vector3 center, string title, string panel, int variant)
        {
            var shop = Child(title, SectorRoot);
            shop.transform.localPosition = center;
            var paint = GameAssets.Material("Shop paint " + variant, Color.Lerp(new Color(.075f, .14f, .19f), new Color(.18f, .24f, .27f), variant / 6f), .55f);
            GameAssets.Box("Shop building", shop.transform, new Vector3(0, 3.1f, 0), new Vector3(13, 6.2f, 12), paint);
            GameAssets.Box("Canopy", shop.transform, new Vector3(0, 4.5f, 7), new Vector3(14, .32f, 3.1f), steel);
            GameAssets.Box("Window", shop.transform, new Vector3(-2.5f, 2.5f, 6.03f), new Vector3(5, 2.2f, .04f), dark, false);
            GameAssets.Box("Store lighting", shop.transform, new Vector3(0, 4.18f, 8.5f), new Vector3(13.5f, .13f, .1f), variant % 2 == 0 ? cyan : amber, false);
            var label = GameAssets.Label(shop.transform, title, new Vector3(0, 5.1f, 6.15f), .17f, variant % 2 == 0 ? GameAssets.Cyan : GameAssets.Amber);
            label.transform.localRotation = Quaternion.Euler(0, 180, 0);
            Terminal(center + new Vector3(2.6f, 0, 8), "Acessar " + title.ToLowerInvariant(), panel, variant % 2 == 0 ? cyan : amber);
            for (int i = 0; i < 2; i++)
                GameAssets.Box("Roof ventilation", shop.transform, new Vector3(-3+i*5, 6.65f, -1), new Vector3(2.2f, .9f, 2), dark);
        }

        void Terminal(Vector3 position, string prompt, string panel, Material emission)
        {
            var kiosk = GameAssets.Box("Terminal · " + panel, SectorRoot, position + Vector3.up*.82f, new Vector3(1.15f, 1.64f, .65f), dark);
            GameAssets.Box("Terminal display", kiosk.transform, new Vector3(0, .15f, .515f), new Vector3(.86f, .46f, .05f), emission, false);
            GameAssets.Interaction(kiosk, prompt, "panel", panel).range = 3.5f;
        }

        void BuildCitySilhouette(Destination destination)
        {
            bool industrial = destination == Destination.Industrial;
            for (int i = 0; i < 32; i++)
            {
                int side = i % 2 == 0 ? -1 : 1;
                float x = side * Next(65, 170), z = Next(-175, 150);
                if (industrial && x < 0 && z > 30) z = -130;
                float height = Next(18, industrial ? 46 : 95);
                Tower(new Vector3(x, 0, z), new Vector3(Next(11, 19), height, Next(12, 21)), i, industrial);
            }
            for (int i = 0; i < 8; i++)
                Rock(new Vector3(Next(-230, 230), 0, Next(190, 240)), Next(18, 38), i, true);
        }

        void Tower(Vector3 position, Vector3 size, int index, bool industrial)
        {
            var root = Child("Modular skyline tower " + index, SectorRoot);
            root.transform.localPosition = position;
            var high = Child("Tower detailed LOD", root.transform);
            var model = GameAssets.Model("CityTower", high.transform, Vector3.zero, size.y/28f);
            if (!model) GameAssets.Box("Tower body", high.transform, new Vector3(0, size.y/2, 0), size, steel, false);
            else FitVisual(model, size, true);
            for (int level = 1; level < 5; level++)
                GameAssets.Box("Window ribbon", high.transform, new Vector3(0, size.y*level/5f, -size.z*.505f), new Vector3(size.x*.8f, .3f, .12f), industrial ? amber : cyan, false);
            GameAssets.Box("Roof crown", high.transform, new Vector3(0, size.y+.4f, 0), new Vector3(size.x*.8f, .8f, size.z*.8f), dark, false);
            var low = GameAssets.Box("Tower distant LOD", root.transform, new Vector3(0, size.y/2, 0), size, steel, false);
            var collider = root.AddComponent<BoxCollider>(); collider.center = new Vector3(0, size.y/2, 0); collider.size = size;
            var lod = root.AddComponent<LODGroup>();
            lod.SetLODs(new[] {new LOD(.11f, high.GetComponentsInChildren<Renderer>()), new LOD(.018f, new[] {low.GetComponent<Renderer>()})});
            lod.RecalculateBounds();
        }

        void BuildIndustry()
        {
            var machinery = GameAssets.Model("IndustrialRig", SectorRoot, new Vector3(87, 0, 40), 2f);
            if (!machinery)
            {
                GameAssets.Box("Ore processing plant", SectorRoot, new Vector3(87, 9, 40), new Vector3(25, 18, 20), steel);
                for (int i = 0; i < 4; i++) GameAssets.Primitive("Refinery chimney", PrimitiveType.Cylinder, SectorRoot, new Vector3(78+i*6, 23, 40), new Vector3(3, 15, 3), dark);
            }
            else AddBoundsCollider(machinery);
            for (int i = 0; i < 10; i++) Rock(new Vector3(-78+Next(-20, 20), 0, 62+Next(-24, 24)), Next(2.4f, 6), i, true);
            var ore = GameAssets.Primitive("Exposed copper seam", PrimitiveType.Sphere, SectorRoot, new Vector3(-71, 1.25f, 52), new Vector3(4, 2.5f, 3), GameAssets.Material("Copper ore", new Color(.35f, .72f, .61f), .6f));
            // Industrial ore and freight are property of the refinery, not resource nodes.
            var freight = GameAssets.Model("Crate", SectorRoot, new Vector3(45, 0, -15), 1.2f);
            if (freight) AddBoundsCollider(freight);
            else GameAssets.Box("Refinery freight", SectorRoot, new Vector3(45, .7f, -15), new Vector3(1.5f, 1.4f, 1.5f), steel);
            var directions = GameAssets.Label(SectorRoot, "RECURSOS LIVRES\nDestrocos / planeta desconhecido", new Vector3(-70, 3.2f, 45), .18f, GameAssets.Amber);
            directions.transform.localRotation = Quaternion.Euler(0, 180, 0);
        }

        void BuildStationDome()
        {
            // Open structural ribs describe a dome without placing a collision shell around the player.
            for (int meridian = 0; meridian < 8; meridian++)
            {
                float yaw = meridian*Mathf.PI/4;
                for (int arc = 0; arc < 10; arc++)
                {
                    float a = arc*Mathf.PI/20, b = (arc+1)*Mathf.PI/20;
                    Vector3 p = new Vector3(Mathf.Cos(a)*150*Mathf.Cos(yaw), Mathf.Sin(a)*95, Mathf.Cos(a)*150*Mathf.Sin(yaw));
                    Vector3 q = new Vector3(Mathf.Cos(b)*150*Mathf.Cos(yaw), Mathf.Sin(b)*95, Mathf.Cos(b)*150*Mathf.Sin(yaw));
                    Beam("Station dome rib", p, q, .7f, steel);
                }
            }
            for (int i = 0; i < 32; i++)
            {
                float a=i*Mathf.PI/16, b=(i+1)*Mathf.PI/16;
                Beam("Orbital observation ring", new Vector3(Mathf.Cos(a)*150, 7, Mathf.Sin(a)*150), new Vector3(Mathf.Cos(b)*150, 7, Mathf.Sin(b)*150), .45f, cyan);
            }
        }

        void BuildWilderness()
        {
            for (int i = 0; i < 60; i++)
            {
                var p = new Vector3(Next(-230, 230), 0, Next(-190, 230));
                if (Mathf.Abs(p.x)<25 && Mathf.Abs(p.z)<33) continue;
                if (NearClue(p, 13)) continue;
                Rock(p, Next(1.5f, 8), i, true);
            }
            // Natural landmarks can be seen in the landscape; clue items have no labels or HUD markers.
            var cave = Child("Basalt shelter", SectorRoot); cave.transform.localPosition = new Vector3(-44, 0, 78);
            GameAssets.Box("Cave wall west", cave.transform, new Vector3(-6, 4, 0), new Vector3(4, 8, 14), stone);
            GameAssets.Box("Cave wall east", cave.transform, new Vector3(6, 4, 0), new Vector3(4, 8, 14), stone);
            GameAssets.Box("Cave canopy", cave.transform, new Vector3(0, 8.1f, 0), new Vector3(16, 2.5f, 14), stone);
            Cargo(CluePosition(1)+Vector3.up*.55f, "Examinar registro antigo", "investigate", "coordinates", false);
            var arch = GameAssets.Model("RuinArch", SectorRoot, CluePosition(2)+Vector3.forward*6, 1.3f);
            if (!arch)
            {
                GameAssets.Box("Ruin pillar west", SectorRoot, CluePosition(2)+new Vector3(-5, 5, 6), new Vector3(2.5f, 10, 3), stone);
                GameAssets.Box("Ruin pillar east", SectorRoot, CluePosition(2)+new Vector3(5, 5, 6), new Vector3(2.5f, 10, 3), stone);
                GameAssets.Box("Ruin lintel", SectorRoot, CluePosition(2)+new Vector3(0, 10, 6), new Vector3(13, 2, 3), stone);
            }
            else
            {
                // Separate pillars preserve a walkable opening even when the visual model is imported.
                var west = Child("Ruin pillar collider west", SectorRoot); west.transform.localPosition = CluePosition(2)+new Vector3(-5, 5, 6);
                west.AddComponent<BoxCollider>().size = new Vector3(2.5f, 10, 3);
                var east = Child("Ruin pillar collider east", SectorRoot); east.transform.localPosition = CluePosition(2)+new Vector3(5, 5, 6);
                east.AddComponent<BoxCollider>().size = new Vector3(2.5f, 10, 3);
            }
            var tablet = GameAssets.Box("Weathered inscription", SectorRoot, CluePosition(2)+Vector3.up*.8f, new Vector3(1.8f, 1.6f, .6f), stone);
            GameAssets.Interaction(tablet, "Decifrar inscricao", "investigate", "ruin");
            Cargo(CluePosition(3)+Vector3.up*.6f, "Abrir relicario soterrado", "investigate", "treasure", false);
            for (int i = 0; i < 3; i++)
            {
                var deposit = GameAssets.Primitive("Mineral deposit", PrimitiveType.Sphere, SectorRoot, new Vector3(-58+i*56, 1, 36+i*18), new Vector3(2.8f, 2, 2.2f), GameAssets.Material("Wild minerals", new Color(.34f, .55f, .49f), .75f));
                GameAssets.Interaction(deposit, "Extrair minerio", "extract", "ore");
            }
        }

        void BuildOrbit(Destination destination)
        {
            for (int i = 0; i < 74; i++)
            {
                float angle = Next(0, Mathf.PI*2), radius = Next(155, 660);
                Vector3 p = new Vector3(Mathf.Cos(angle)*radius, Next(-95, 95), Mathf.Sin(angle)*radius+125);
                if (p.magnitude < 100) p.x += 150;
                Rock(p, Next(3, 15), i, false);
            }
            if (destination == Destination.Station)
            {
                var station = GameAssets.Model("Station", SectorRoot, new Vector3(-190, 25, 320), 7);
                if (!station)
                {
                    station = GameAssets.Primitive("Orbital station", PrimitiveType.Cylinder, SectorRoot, new Vector3(-190, 25, 320), new Vector3(110, 8, 110), steel);
                    GameAssets.Box("Station spine", station.transform, new Vector3(0, 1.4f, 0), new Vector3(.17f, 2.4f, .17f), dark);
                }
                else AddBoundsCollider(station);
            }
            if (destination == Destination.Debris)
            {
                var wreck = GameAssets.Box("Black-box carrier wreck", SectorRoot, new Vector3(0, 1, 55), new Vector3(8, 3.2f, 13), dark);
                GameAssets.Box("Broken cargo frame", wreck.transform, new Vector3(.43f, .2f, -.15f), new Vector3(.3f, 1.6f, 1.1f), steel);
                GameAssets.Box("Emergency signal light", wreck.transform, new Vector3(0, .52f, -.3f), new Vector3(.24f, .1f, .1f), amber, false);
                GameAssets.Interaction(wreck, "Recuperar caixa-preta", "investigate", "debris_signal").range=100;
            }
            if (destination == Destination.Debris)
            {
                Cargo(new Vector3(-17, 3, 36), "Recuperar carga a deriva", "salvage", "scrap", true);
                Cargo(new Vector3(22, -5, 48), "Recuperar conteiner", "salvage", "scrap", true);
                Cargo(new Vector3(-39, 8, 74), "Coletar suprimentos", "salvage", "scrap", true);
            }
            if (destination == Destination.Debris || destination == Destination.Uncharted)
            {
                var mineral = GameAssets.Primitive("Rare orbital deposit", PrimitiveType.Sphere, SectorRoot, new Vector3(41, 4, 69), new Vector3(6, 4, 5), GameAssets.Material("Orbital minerals", new Color(.34f, .55f, .49f), .75f));
                GameAssets.Interaction(mineral, "Extrair minerio raro", "extract", "ore").range = 90;
            }
            // Route buoys are visual landmarks only. They do not reveal the hidden exploration chain.
            for (int i = 0; i < 8; i++)
            {
                Vector3 p = new Vector3(65+i*32, 12+i*6, 180+i*50);
                var beacon = GameAssets.Model("Beacon", SectorRoot, p, 2);
                if (!beacon) GameAssets.Primitive("Navigation buoy", PrimitiveType.Sphere, SectorRoot, p, Vector3.one*1.6f, cyan, false);
            }
            Child("Recycled orbital traffic", SectorRoot).AddComponent<SectorTraffic>().Initialize(SectorRoot, false, 8317+(int)destination);
            // Layer 9 is the flight collision mask. Surface geometry remains on the default layer.
            foreach (var obstacle in SectorRoot.GetComponentsInChildren<Collider>()) obstacle.gameObject.layer = 9;
        }

        void Cargo(Vector3 position, string prompt, string action, string argument, bool orbital)
        {
            var cargo = GameAssets.Model("Crate", SectorRoot, position, orbital ? 2.2f : .7f);
            if (!cargo) cargo = GameAssets.Box("Abandoned container", SectorRoot, position, orbital ? new Vector3(3.8f, 3.1f, 4.2f) : new Vector3(1.2f, 1.1f, 1.3f), steel);
            else
            {
                FitVisual(cargo, orbital ? new Vector3(3.8f, 3.1f, 4.2f) : new Vector3(1.2f, 1.1f, 1.3f), false);
                AddBoundsCollider(cargo);
            }
            var interaction = GameAssets.Interaction(cargo, prompt, action, argument);
            interaction.range = orbital ? 90 : 3.5f;
        }

        void Rock(Vector3 position, float size, int index, bool ground)
        {
            var root=Child((ground ? "Basalt outcrop " : "Asteroid ")+index, SectorRoot);
            root.transform.localPosition=position+(ground ? Vector3.up*size*.35f : Vector3.zero);
            var high=GameAssets.Model("Asteroid", root.transform, Vector3.zero, size*.6f);
            if (!high) high=GameAssets.Primitive("Rock detailed LOD", PrimitiveType.Sphere, root.transform, Vector3.zero, new Vector3(size, size*.8f, size*1.18f), stone, false);
            else FitVisual(high, new Vector3(size, size*.8f, size*1.18f), false);
            var low=GameAssets.Primitive("Rock distant LOD", PrimitiveType.Cube, root.transform, Vector3.zero, new Vector3(size*.84f, size*.66f, size*.9f), stone, false);
            var col=root.AddComponent<SphereCollider>(); col.radius=size*.48f;
            var lod=root.AddComponent<LODGroup>();
            lod.SetLODs(new[] {new LOD(.045f, high.GetComponentsInChildren<Renderer>()), new LOD(.008f, new[] {low.GetComponent<Renderer>()})});
            lod.RecalculateBounds();
            root.transform.localRotation=Quaternion.Euler(Next(-12, 12), Next(0, 360), Next(-12, 12));
        }

        static void FitVisual(GameObject model, Vector3 dimensions, bool grounded)
        {
            var renderers = model.GetComponentsInChildren<Renderer>();
            if (renderers.Length == 0) return;
            Vector3 anchor = model.transform.localPosition;
            var bounds = renderers[0].bounds;
            for (int i = 1; i < renderers.Length; i++) bounds.Encapsulate(renderers[i].bounds);
            Vector3 size = bounds.size;
            model.transform.localScale = Vector3.Scale(model.transform.localScale,
                new Vector3(dimensions.x/Mathf.Max(.001f,size.x), dimensions.y/Mathf.Max(.001f,size.y), dimensions.z/Mathf.Max(.001f,size.z)));
            bounds = renderers[0].bounds;
            for (int i = 1; i < renderers.Length; i++) bounds.Encapsulate(renderers[i].bounds);
            Vector3 desired = anchor + (grounded ? Vector3.up * dimensions.y * .5f : Vector3.zero);
            model.transform.localPosition += desired - model.transform.parent.InverseTransformPoint(bounds.center);
        }

        void Beam(string name, Vector3 start, Vector3 end, float width, Material material)
        {
            var beam=GameAssets.Box(name, SectorRoot, (start+end)*.5f, new Vector3(width, width, Vector3.Distance(start,end)), material, false);
            beam.transform.localRotation=Quaternion.LookRotation(end-start);
        }

        static void AddBoundsCollider(GameObject model)
        {
            var renderers=model.GetComponentsInChildren<Renderer>();
            if (renderers.Length==0) return;
            var bounds=renderers[0].bounds;
            for(int i=1;i<renderers.Length;i++) bounds.Encapsulate(renderers[i].bounds);
            var col=model.AddComponent<BoxCollider>();
            col.center=model.transform.InverseTransformPoint(bounds.center);
            var scale=model.transform.lossyScale;
            col.size=new Vector3(bounds.size.x/Mathf.Max(.001f,scale.x), bounds.size.y/Mathf.Max(.001f,scale.y), bounds.size.z/Mathf.Max(.001f,scale.z));
        }

        static GameObject Child(string name, Transform parent)
        {
            var go=new GameObject(name); go.transform.SetParent(parent, false); return go;
        }

        bool NearClue(Vector3 position, float distance)
        {
            for(int i=1;i<=3;i++) if((position-CluePosition(i)).sqrMagnitude<distance*distance) return true;
            return false;
        }

        float Next(float min, float max) => min+(float)random.NextDouble()*(max-min);
    }
}

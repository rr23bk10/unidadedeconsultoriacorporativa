using System;
using System.Collections;
using Orbita.Domain;
using UnityEngine;

namespace Orbita.Runtime
{
    public sealed class OrbitaGame : MonoBehaviour
    {
        static OrbitaGame instance;
        public GameState State { get; private set; }
        public ShipController Ship { get; private set; }
        public PlayerController Player { get; private set; }
        public WorldBuilder World { get; private set; }
        public string Panel { get; private set; } = "";
        public string LastMessage { get; private set; } = "";
        public string InteractionPrompt { get; private set; } = "";
        public bool IsTransitioning { get; private set; }
        public float TransitionAlpha { get; private set; }
        public bool IsPiloting => Ship && Ship.Piloting;
        public bool IsDocked => Ship && Ship.Docked;
        public float Speed => Ship ? Ship.Speed : 0;
        public bool HasSave => SaveStore.Exists;
        public string ScanHint { get; private set; } = "Sensores em espera. R no cockpit para emitir um pulso.";
        public string DialogueText { get; private set; } = "A fronteira precisa de transportadores, mecânicos e exploradores. O trabalho começa nos terminais da praça.";
        public string PlaceName => State == null ? "Carregando" : Place(State.location) + (IsDocked ? " / superfície" : " / órbita");
        CrewController crew;
        Interactable focused;
        Interactable[] interactions = new Interactable[0];
        float refresh;
        delegate bool Rule(GameState state, out string message);

        void Awake()
        {
            if (instance && instance != this) { Destroy(gameObject); return; }
            instance = this;
            DontDestroyOnLoad(gameObject);
            Application.targetFrameRate = 60;
            QualitySettings.vSyncCount = 1;
        }

        IEnumerator Start()
        {
            IsTransitioning = true; TransitionAlpha = 1;
            if (SaveStore.Read(out var saved, out var msg)) State = saved;
            else State = GameRules.CreateNew();
            World = gameObject.AddComponent<WorldBuilder>();
            var shipObject = new GameObject("Active ship / persistent frame");
            shipObject.transform.SetParent(transform);
            Ship = shipObject.AddComponent<ShipController>();
            Ship.Initialize(this);
            var playerObject = new GameObject("Human player");
            Player = playerObject.AddComponent<PlayerController>();
            Player.Initialize(this);
            crew = gameObject.AddComponent<CrewController>();
            crew.Initialize(this);
            gameObject.AddComponent<FlightHud>().Initialize(this);
            bool surface = State.location != Destination.Debris;
            yield return World.Load(State.location, surface);
            Ship.SetDocked(surface);
            if (surface) Player.Teleport(new Vector3(0, .2f, -22));
            else Ship.SetPiloting(true);
            RefreshInteractions();
            IsTransitioning = false; TransitionAlpha = 0;
            Notify("Bem-vindo a Órbita. E interage; Tab abre o diário. Procure CONTRATOS na praça.");
        }

        void Update()
        {
            if (State == null || IsTransitioning || !Player) return;
            if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.Tab))
            {
                if (Panel.Length > 0) ClosePanel();
                else OpenPanel(Input.GetKeyDown(KeyCode.Tab) ? "journal" : "pause");
                return;
            }
            if (Panel.Length > 0)
            {
                InteractionPrompt = "";
                return;
            }
            refresh -= Time.deltaTime;
            if (refresh <= 0) { RefreshInteractions(); refresh = 1; }
            FindInteraction();
            if (focused && Input.GetKeyDown(IsPiloting ? KeyCode.G : KeyCode.E)) focused.Use(this);
            if (IsPiloting && IsDocked)
            {
                if (Input.GetKeyDown(KeyCode.F)) OpenPanel("navigation");
                if (Input.GetKeyDown(KeyCode.X)) Execute("stand");
            }
            if (!IsPiloting && Input.GetKeyDown(KeyCode.R)) Scan();
        }

        void RefreshInteractions() => interactions = FindObjectsByType<Interactable>(FindObjectsSortMode.None);
        void FindInteraction()
        {
            focused = null;
            float best = float.MaxValue;
            Vector3 origin = IsPiloting ? Ship.transform.TransformPoint(new Vector3(0, 3, 9)) : Player.transform.position + Vector3.up;
            foreach (var target in interactions)
            {
                if (!target || !target.gameObject.activeInHierarchy) continue;
                if (IsPiloting && target.transform.IsChildOf(Ship.transform)) continue;
                if (!IsPiloting && target.range > 10) continue;
                float distance = Vector3.Distance(origin, target.transform.position);
                if (distance > target.range || distance >= best) continue;
                Vector3 direction = target.transform.position - origin;
                if (IsPiloting && Vector3.Dot(direction.normalized, Ship.transform.forward) < .25f) continue;
                // Interactions respect doors/walls; looking at a hidden terminal is insufficient.
                bool blocked = false;
                foreach (var hit in Physics.RaycastAll(origin, direction.normalized, distance, ~(1 << 8), QueryTriggerInteraction.Ignore))
                {
                    if (IsPiloting && hit.transform.IsChildOf(Ship.transform)) continue;
                    var other = hit.collider.GetComponentInParent<Interactable>();
                    if (other != target && !hit.transform.IsChildOf(target.transform)) { blocked = true; break; }
                }
                if (blocked) continue;
                best = distance; focused = target;
            }
            InteractionPrompt = focused ? (IsPiloting ? "[G] " : "[E] ") + focused.prompt : "";
        }

        public void Notify(string message) { LastMessage = message; }
        public void OpenPanel(string panel)
        {
            if (IsTransitioning) return;
            Panel = panel;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
        public void ClosePanel() { Panel = ""; }

        bool Apply(Rule action)
        {
            bool ok = action(State, out var message);
            Notify(message);
            if (ok) SaveStore.Write(State, out _);
            return ok;
        }

        bool AtService(string panel)
        {
            if (IsDocked && !IsPiloting && Panel == panel) return true;
            Notify("Use o terminal correspondente no porto, a pé."); return false;
        }

        public void Execute(string action, string arg = "")
        {
            if (State == null || IsTransitioning) return;
            switch (action)
            {
                case "panel": OpenPanel(arg); break;
                case "talk": DialogueText = arg; OpenPanel("dialogue"); break;
                case "rumor":
                    if (Panel == "dialogue") DialogueText = "Uma nave desapareceu perto do cinturão. Só restou uma antena âmbar. O último pulso dela não veio de uma cidade: veio do planeta que ninguém visita. Procure a caixa-preta entre os destroços.";
                    break;
                case "trade-tip":
                    if (Panel == "dialogue") DialogueText = "O mercado compra sucata por 45 créditos e minério raro por 160. Reserve espaço para a carga dos contratos e combustível para voltar. A Ímã recupera mais sucata; a Sonda extrai mais minério. Aqui os salários vencem a cada viagem.";
                    break;
                case "pilot":
                    if (IsPiloting) break;
                    Ship.SetPiloting(true); ClosePanel();
                    Notify("Cockpit: F navegação; WASD voo; Q/E altitude; X levantar; L pousar; R sensores; G recuperar.");
                    if (IsDocked) OpenPanel("navigation");
                    break;
                case "stand": Ship.SetPiloting(false); ClosePanel(); Notify("Estabilizador ativo. Você pode caminhar pela nave durante o voo."); break;
                case "launch": if (IsPiloting && IsDocked) StartCoroutine(Depart()); else Notify("Sente na cadeira do piloto para decolar."); break;
                case "land":
                    if (!IsPiloting || IsDocked) { Notify("Pouse a partir do cockpit, em órbita."); break; }
                    if (State.location == Destination.Debris) { Notify("Não existe porto no campo de destroços."); break; }
                    StartCoroutine(Land()); break;
                case "travel":
                    if (!IsPiloting || IsDocked) { Notify("Decole primeiro. A navegação orbital funciona durante o voo."); break; }
                    if (!Enum.TryParse(arg, out Destination destination)) break;
                    if (Apply((GameState s, out string m) => GameRules.TryTravel(s, destination, out m))) StartCoroutine(Jump());
                    break;
                case "accept-delivery": if (AtService("jobs")) Apply(GameRules.TryAcceptDelivery); break;
                case "deliver": if (AtService("jobs")) Apply(GameRules.TryDeliverCargo); break;
                case "claim": if (AtService("jobs")) Apply(GameRules.TryClaimReward); break;
                case "sell": if (AtService("market")) Apply(GameRules.TrySellSalvage); break;
                case "sell-rare": if (AtService("market")) Apply(GameRules.TrySellRare); break;
                case "refuel": if (AtService("workshop")) Apply(GameRules.TryRefuel); break;
                case "repair": if (AtService("workshop")) Apply(GameRules.TryRepair); break;
                case "upgrade": if (AtService("workshop")) Apply(GameRules.TryUpgrade); break;
                case "hire":
                    if (AtService("crew") && Apply((GameState s, out string m) => GameRules.TryHire(s, arg, out m))) { crew.Rebuild(); RefreshInteractions(); }
                    break;
                case "buy":
                    if (AtService("dealership") && Enum.TryParse(arg, out ShipClass buy)) Apply((GameState s, out string m) => GameRules.TryBuyShip(s, buy, out m));
                    break;
                case "activate":
                    if (AtService("dealership") && Enum.TryParse(arg, out ShipClass type) && Apply((GameState s, out string m) => GameRules.TryActivateShip(s, type, out m))) Ship.RebuildShell();
                    break;
                case "salvage":
                    if (focused && focused.action == action && Apply((GameState s, out string m) => GameRules.TryCollectSalvage(s, 2, out m))) ConsumeFocused();
                    break;
                case "extract":
                    if (focused && focused.action == action && Apply(GameRules.TryExtractRare)) ConsumeFocused();
                    break;
                case "investigate":
                    if (focused && focused.action == action && focused.argument == arg) Apply((GameState s, out string m) => GameRules.Investigate(s, arg, out m));
                    break;
                case "scan": Scan(); break;
                case "save": SaveStore.Write(State, out var saveMessage); Notify(saveMessage); break;
                case "load":
                    if (SaveStore.Read(out var loaded, out var loadMessage)) { State = loaded; StartCoroutine(Restore()); }
                    Notify(loadMessage); break;
                case "new": State = GameRules.CreateNew(); StartCoroutine(Restore()); break;
                case "rescue": if (Apply(GameRules.TryEmergencyRescue)) StartCoroutine(Restore()); break;
            }
        }

        void ConsumeFocused()
        {
            // Nodes are depleted for this sector visit; revisiting a streamed sector repopulates them.
            focused.gameObject.SetActive(false);
            focused = null;
        }

        IEnumerator Fade(float target)
        {
            while (Mathf.Abs(TransitionAlpha - target) > .01f)
            {
                TransitionAlpha = Mathf.MoveTowards(TransitionAlpha, target, Time.unscaledDeltaTime * 2);
                yield return null;
            }
            TransitionAlpha = target;
        }
        IEnumerator Depart()
        {
            ClosePanel(); IsTransitioning = true; Ship.SetDocked(false);
            Notify("Decolagem autorizada. Subindo para a janela orbital.");
            yield return Ship.VerticalMove(65, 3);
            yield return Fade(1);
            yield return World.Load(State.location, false);
            Ship.transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity);
            yield return Fade(0);
            IsTransitioning = false; RefreshInteractions();
            Notify("Em órbita. F seleciona destino; X permite explorar o interior em voo.");
        }
        IEnumerator Jump()
        {
            ClosePanel(); IsTransitioning = true;
            Notify("Salto por corredor comercial. Carregando setor de destino.");
            yield return Fade(1);
            yield return World.Load(State.location, false);
            Ship.transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity);
            Ship.SetDocked(false);
            yield return Fade(0);
            IsTransitioning = false; RefreshInteractions();
            Notify("Órbita de " + Place(State.location) + ". " + (State.location == Destination.Debris ? "R sensores, G para recuperar alvos próximos." : "L inicia aproximação e pouso."));
        }
        IEnumerator Land()
        {
            ClosePanel(); IsTransitioning = true;
            yield return Fade(1);
            yield return World.Load(State.location, true);
            Ship.transform.SetPositionAndRotation(new Vector3(0, 55, 0), Quaternion.identity);
            yield return Fade(0);
            yield return Ship.VerticalMove(0, 3);
            Ship.SetDocked(true); IsTransitioning = false; RefreshInteractions();
            SaveStore.Write(State, out _);
            Notify("Pouso concluído. X levanta da cadeira; a rampa está liberada.");
        }
        IEnumerator Restore()
        {
            ClosePanel(); IsTransitioning = true;
            yield return Fade(1);
            bool surface = State.location != Destination.Debris;
            yield return World.Load(State.location, surface);
            Ship.transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity);
            Ship.SetDocked(surface); Ship.RebuildShell(); crew.Rebuild();
            if (surface) { Ship.SetPiloting(false); Player.Teleport(new Vector3(0, .2f, -22)); }
            else Ship.SetPiloting(true);
            SaveStore.Write(State, out _);
            yield return Fade(0);
            IsTransitioning = false; RefreshInteractions();
        }

        void Scan()
        {
            if (State.location == Destination.Debris)
                ScanHint = "Eco metálico à frente. Busque a antena âmbar entre os destroços. Aproxime-se e use G.";
            else if (State.location == Destination.Uncharted && State.explorationStage > 0 && State.explorationStage < 4)
            {
                Vector3 origin = IsPiloting ? Ship.transform.position : Player.transform.position;
                Vector3 delta = WorldBuilder.CluePosition(State.explorationStage) - origin;
                if (delta.magnitude > GameRules.SensorRange(State)) ScanHint = "Eco fora do alcance. Melhore sensores ou contrate um explorador.";
                else
                {
                    string direction = (delta.z > 15 ? "N" : delta.z < -15 ? "S" : "") + (delta.x > 15 ? "L" : delta.x < -15 ? "O" : "");
                    int band = Mathf.FloorToInt(delta.magnitude / 40) * 40;
                    ScanHint = "Sinal " + (direction.Length == 0 ? "próximo" : "a " + direction) + ", faixa " + band + "–" + (band + 40) + " m. Coordenadas imprecisas: investigue o terreno. Norte = +Z.";
                }
            }
            else ScanHint = "Nenhuma assinatura catalogada. Recupere registros na região dos destroços para obter pistas.";
            Notify(ScanHint);
        }
        public string ObjectiveText()
        {
            if (State == null) return "Preparando o sistema";
            switch (State.deliveryStage)
            {
                case MissionStage.Available: return "NOVO CONTRATO / Procure o terminal de contratos em Nova Terra.";
                case MissionStage.Accepted: return "TRANSPORTE / Leve 8 unidades à Colônia Industrial. Entregue no terminal local.";
                case MissionStage.Delivered: return "RETORNO / Volte a Nova Terra e receba 850 créditos no terminal de contratos.";
                default: return State.explorationStage < 4 ? "EXPLORAÇÃO / Investigue o sinal nos destroços e siga as pistas do planeta inexplorado." : "FRONTEIRA / Comércio, coleta e frota disponíveis. Use o diário para consultar sua descoberta.";
            }
        }
        public static string Place(Destination destination)
        {
            switch (destination)
            {
                case Destination.NovaTerra: return "Nova Terra";
                case Destination.Industrial: return "Colônia Industrial";
                case Destination.Uncharted: return "Planeta Inexplorado";
                case Destination.Station: return "Estação Meridiano";
                default: return "Campo de Destroços";
            }
        }
        void OnApplicationQuit() { if (State != null) SaveStore.Write(State, out _); }
    }
}

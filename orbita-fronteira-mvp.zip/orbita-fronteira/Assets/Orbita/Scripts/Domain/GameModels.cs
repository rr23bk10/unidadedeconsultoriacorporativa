using System;
using System.Collections.Generic;

namespace Orbita.Domain
{
    public enum Destination { NovaTerra, Industrial, Uncharted, Station, Debris }
    public enum ShipClass { Scout, Hauler, Explorer, Courier, Salvager, Prospector }
    public enum MissionStage { Available, Accepted, Delivered, Completed }

    [Serializable]
    public sealed class GameState
    {
        public int version;
        public int credits;
        public float fuel;
        public float hull;
        public Destination location;
        public ShipClass activeShip;
        public List<ShipClass> ownedShips;
        public List<CrewMember> crew;
        public List<CargoStack> cargo;
        public MissionStage deliveryStage;
        public int explorationStage;
        public List<string> discoveries;
        public int upgrades;
    }

    [Serializable]
    public sealed class CrewMember
    {
        public string id;
        public string name;
        public string role;
        public int level;
        public int wage;
        public float skill;
    }

    [Serializable]
    public sealed class CargoStack
    {
        public string id;
        public int quantity;
    }

    public sealed class ShipSpec
    {
        public string displayName;
        public int price;
        public int capacity;
        public float speed;
        public float fuelCapacity;
        public float sensorRange;
        public float travelFuelCost;
        public int salvageMultiplier;
        public int rareExtractionYield;
    }
}

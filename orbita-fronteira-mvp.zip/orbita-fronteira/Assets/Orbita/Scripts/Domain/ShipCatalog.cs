using System;

namespace Orbita.Domain
{
    public static class ShipCatalog
    {
        // Return an independent specification so callers cannot change the shared catalog.
        public static ShipSpec Get(ShipClass ship)
        {
            switch (ship)
            {
                case ShipClass.Scout: return Spec("Pioneira", 0, 12, 24, 100, 900, 18, 1, 1);
                case ShipClass.Hauler: return Spec("Atlas", 2800, 48, 16, 160, 650, 26, 1, 1);
                case ShipClass.Explorer: return Spec("Horizonte", 4200, 24, 22, 140, 2200, 17, 1, 1);
                case ShipClass.Courier: return Spec("Vetor", 3600, 8, 40, 100, 1100, 32, 1, 1);
                case ShipClass.Salvager: return Spec("Ímã", 4400, 40, 18, 160, 1250, 24, 2, 1);
                case ShipClass.Prospector: return Spec("Sonda", 5200, 22, 20, 140, 2800, 22, 1, 3);
                default: throw new ArgumentOutOfRangeException(nameof(ship));
            }
        }

        private static ShipSpec Spec(string name, int price, int capacity, float speed,
            float fuel, float sensors, float travelFuel, int salvage, int rare)
        {
            return new ShipSpec
            {
                displayName = name, price = price, capacity = capacity, speed = speed,
                fuelCapacity = fuel, sensorRange = sensors, travelFuelCost = travelFuel,
                salvageMultiplier = salvage, rareExtractionYield = rare
            };
        }
    }
}

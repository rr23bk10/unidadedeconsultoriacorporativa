using System;
using System.Collections.Generic;

namespace Orbita.Domain
{
    /// <summary>Pure, deterministic game rules shared by Unity and the console checks.</summary>
    public static class GameRules
    {
        public const int CurrentVersion = 1;
        public const int DeliveryQuantity = 8;
        public const int DeliveryReward = 850;
        public const int ExplorationReward = 2200;
        public const int SalvageUnitPrice = 45;
        public const int RareUnitPrice = 160;
        public const string DeliveryCargoId = "delivery_goods";
        public const string SalvageCargoId = "salvage";
        public const string RareCargoId = "rare_ore";
        public const string ArtifactCargoId = "artifact";
        private const int MaximumCredits = 1000000000;
        private static readonly string[] Clues = { "debris_signal", "coordinates", "ruin", "treasure" };

        public static GameState CreateNew()
        {
            return new GameState
            {
                version = CurrentVersion, credits = 1200, fuel = 100, hull = 100,
                location = Destination.NovaTerra, activeShip = ShipClass.Scout,
                ownedShips = new List<ShipClass> { ShipClass.Scout },
                crew = new List<CrewMember>(), cargo = new List<CargoStack>(),
                deliveryStage = MissionStage.Available, explorationStage = 0,
                discoveries = new List<string>(), upgrades = 0
            };
        }

        /// <summary>
        /// Repairs older or incomplete saves in place. False means null or an unsupported
        /// future save version; in either case the supplied state is left unchanged.
        /// No reward or money is ever granted by loading a save.
        /// </summary>
        public static bool Validate(GameState state)
        {
            if (state == null || state.version > CurrentVersion) return false;
            state.version = CurrentVersion;
            state.credits = Clamp(state.credits, 0, MaximumCredits);
            state.upgrades = Clamp(state.upgrades, 0, 3);
            if (!Enum.IsDefined(typeof(Destination), state.location)) state.location = Destination.NovaTerra;
            if (!Enum.IsDefined(typeof(ShipClass), state.activeShip)) state.activeShip = ShipClass.Scout;
            if (!Enum.IsDefined(typeof(MissionStage), state.deliveryStage)) state.deliveryStage = MissionStage.Available;
            state.explorationStage = Clamp(state.explorationStage, 0, Clues.Length);
            state.fuel = CleanFloat(state.fuel, 0, ShipCatalog.Get(state.activeShip).fuelCapacity);
            state.hull = CleanFloat(state.hull, 0, 100);

            var owned = new List<ShipClass>();
            if (state.ownedShips != null)
                foreach (var ship in state.ownedShips)
                    if (Enum.IsDefined(typeof(ShipClass), ship) && !owned.Contains(ship)) owned.Add(ship);
            if (!owned.Contains(ShipClass.Scout)) owned.Insert(0, ShipClass.Scout);
            if (!owned.Contains(state.activeShip)) owned.Add(state.activeShip);
            state.ownedShips = owned;

            var normalizedCrew = new List<CrewMember>();
            if (state.crew != null)
            {
                foreach (var member in state.crew)
                {
                    if (member == null) continue;
                    string role = NormalizeRole(member.role);
                    if (role == null || normalizedCrew.Exists(c => c.role == role)) continue;
                    member.role = role;
                    member.id = role;
                    if (string.IsNullOrWhiteSpace(member.name)) member.name = CrewName(role);
                    member.level = Clamp(member.level, 1, 5);
                    member.wage = RoleWage(role);
                    member.skill = CleanFloat(member.skill, 0.1f, 0.5f);
                    normalizedCrew.Add(member);
                }
            }
            state.crew = normalizedCrew;
            NormalizeCargo(state);

            // Discoveries are canonical milestones, never untrusted text executed as a clue.
            state.discoveries = new List<string>();
            for (int i = 0; i < state.explorationStage; i++) state.discoveries.Add(Clues[i]);
            return true;
        }

        public static int CargoUsed(GameState state)
        {
            if (state == null || state.cargo == null) return 0;
            long used = 0;
            foreach (var stack in state.cargo)
                if (stack != null && stack.quantity > 0) used += stack.quantity;
            return (int)Math.Min(int.MaxValue, used);
        }

        public static int CargoCapacity(GameState state)
        {
            if (state == null || !Enum.IsDefined(typeof(ShipClass), state.activeShip)) return 0;
            return ShipCatalog.Get(state.activeShip).capacity + Clamp(state.upgrades, 0, 3) * 4
                + (HasCrew(state, "cargo") ? 8 : 0);
        }

        public static float SensorRange(GameState state)
        {
            if (state == null || !Enum.IsDefined(typeof(ShipClass), state.activeShip)) return 0;
            return ShipCatalog.Get(state.activeShip).sensorRange * (HasCrew(state, "explorer") ? 1.35f : 1f);
        }

        public static int CrewWages(GameState state)
        {
            int wages = 0;
            if (state != null && state.crew != null)
                foreach (var member in state.crew)
                    if (member != null) wages += Math.Max(0, member.wage);
            return wages;
        }

        public static float TravelFuelCost(GameState state, Destination target)
        {
            if (state == null || !Enum.IsDefined(typeof(ShipClass), state.activeShip)) return 0;
            if (state.location == target) return 0;
            float distance = state.location == Destination.Uncharted || target == Destination.Uncharted ? 1.35f : 1f;
            float pilot = HasCrew(state, "pilot") ? 0.8f : 1f;
            return (float)Math.Round(ShipCatalog.Get(state.activeShip).travelFuelCost * distance * pilot, 2);
        }

        public static bool TryAcceptDelivery(GameState state, out string message)
        {
            if (!Ready(state, out message)) return false;
            if (state.location != Destination.NovaTerra) return Fail("Aceite o contrato no terminal de Nova Terra.", out message);
            if (state.deliveryStage != MissionStage.Available) return Fail("Este contrato já foi aceito ou concluído.", out message);
            if (!HasSpace(state, DeliveryQuantity)) return Fail("Reserve 8 unidades de espaço para a carga do contrato.", out message);
            AddCargo(state, DeliveryCargoId, DeliveryQuantity);
            state.deliveryStage = MissionStage.Accepted;
            return Success("Contrato aceito: leve 8 unidades ao planeta industrial e volte a Nova Terra.", out message);
        }

        public static bool TryDeliverCargo(GameState state, out string message)
        {
            if (!Ready(state, out message)) return false;
            if (state.location != Destination.Industrial) return Fail("A entrega é feita no planeta industrial.", out message);
            if (state.deliveryStage != MissionStage.Accepted) return Fail("Nenhuma entrega aceita está pendente.", out message);
            if (Quantity(state, DeliveryCargoId) < DeliveryQuantity) return Fail("A carga do contrato está incompleta.", out message);
            RemoveCargo(state, DeliveryCargoId);
            state.deliveryStage = MissionStage.Delivered;
            return Success("Entrega registrada. Retorne a Nova Terra para receber 850 créditos.", out message);
        }

        public static bool TryClaimReward(GameState state, out string message)
        {
            if (!Ready(state, out message)) return false;
            if (state.location != Destination.NovaTerra) return Fail("O pagamento é liberado em Nova Terra.", out message);
            if (state.deliveryStage != MissionStage.Delivered) return Fail("Não há pagamento pendente.", out message);
            AddCredits(state, DeliveryReward);
            state.deliveryStage = MissionStage.Completed;
            return Success("Contrato concluído: +850 créditos.", out message);
        }

        public static bool TryCollectSalvage(GameState state, int amount, out string message)
        {
            if (!Ready(state, out message)) return false;
            if (state.location != Destination.Debris) return Fail("A sucata é coletada no campo de destroços.", out message);
            if (amount <= 0) return Fail("Selecione uma quantidade positiva.", out message);
            long yield = (long)amount * ShipCatalog.Get(state.activeShip).salvageMultiplier;
            if (yield > int.MaxValue || !HasSpace(state, (int)yield)) return Fail("Porão cheio: venda carga ou use uma nave maior.", out message);
            float cost = amount * 0.5f;
            if (state.fuel < cost) return Fail("Combustível insuficiente para os drones de salvamento.", out message);
            state.fuel -= cost;
            AddCargo(state, SalvageCargoId, (int)yield);
            return Success("Sucata recuperada: +" + yield + " unidades.", out message);
        }

        public static bool TrySellSalvage(GameState state, out string message)
        {
            return TrySell(state, SalvageCargoId, SalvageUnitPrice, "sucata", out message);
        }

        public static bool TryExtractRare(GameState state, out string message)
        {
            if (!Ready(state, out message)) return false;
            if (state.location != Destination.Debris && state.location != Destination.Uncharted)
                return Fail("Procure depósitos nos destroços ou no planeta desconhecido.", out message);
            int yield = ShipCatalog.Get(state.activeShip).rareExtractionYield;
            if (!HasSpace(state, yield)) return Fail("Não há espaço para o minério raro.", out message);
            if (state.fuel < 4) return Fail("São necessárias 4 unidades de combustível para extrair minério.", out message);
            state.fuel -= 4;
            AddCargo(state, RareCargoId, yield);
            return Success("Depósito extraído: +" + yield + " minério(s) raro(s).", out message);
        }

        public static bool TrySellRare(GameState state, out string message)
        {
            return TrySell(state, RareCargoId, RareUnitPrice, "minério raro", out message);
        }

        public static bool TryRefuel(GameState state, out string message)
        {
            if (!Ready(state, out message)) return false;
            if (!IsPort(state.location)) return Fail("Reabasteça em Nova Terra, na estação ou no planeta industrial.", out message);
            float maximum = ShipCatalog.Get(state.activeShip).fuelCapacity;
            float missing = maximum - state.fuel;
            if (missing <= 0.001f) return Fail("O tanque já está cheio.", out message);
            int price = (int)Math.Ceiling(missing * 2);
            if (state.credits < price) return Fail("Reabastecimento completo custa " + price + " créditos.", out message);
            state.credits -= price;
            state.fuel = maximum;
            return Success("Tanque completo por " + price + " créditos.", out message);
        }

        public static bool TryRepair(GameState state, out string message)
        {
            if (!Ready(state, out message)) return false;
            if (!IsPort(state.location)) return Fail("Reparos exigem um porto.", out message);
            if (state.hull >= 100) return Fail("O casco já está íntegro.", out message);
            int price = (int)Math.Ceiling((100 - state.hull) * 4 * (HasCrew(state, "engineer") ? 0.7f : 1f));
            if (state.credits < price) return Fail("O reparo custa " + price + " créditos.", out message);
            state.credits -= price;
            state.hull = 100;
            return Success("Casco restaurado por " + price + " créditos.", out message);
        }

        public static bool TryUpgrade(GameState state, out string message)
        {
            if (!Ready(state, out message)) return false;
            if (!IsHangar(state.location)) return Fail("Melhore a frota no hangar de Nova Terra ou da estação.", out message);
            if (state.upgrades >= 3) return Fail("Todos os três módulos de porão já foram instalados.", out message);
            int price = (state.upgrades + 1) * 600;
            if (state.credits < price) return Fail("O próximo módulo custa " + price + " créditos.", out message);
            state.credits -= price;
            state.upgrades++;
            return Success("Módulo de frota instalado: +4 unidades de porão em todas as naves.", out message);
        }

        public static bool TryBuyShip(GameState state, ShipClass ship, out string message)
        {
            if (!Ready(state, out message)) return false;
            if (!Enum.IsDefined(typeof(ShipClass), ship)) return Fail("Classe de nave desconhecida.", out message);
            if (!IsHangar(state.location)) return Fail("Compre naves em Nova Terra ou na estação.", out message);
            if (state.ownedShips.Contains(ship)) return Fail("Você já possui essa nave.", out message);
            var spec = ShipCatalog.Get(ship);
            if (state.credits < spec.price) return Fail("Esta nave custa " + spec.price + " créditos.", out message);
            state.credits -= spec.price;
            state.ownedShips.Add(ship);
            return Success(spec.displayName + " adquirida. Selecione-a no hangar para pilotar.", out message);
        }

        public static bool TryActivateShip(GameState state, ShipClass ship, out string message)
        {
            if (!Ready(state, out message)) return false;
            if (!Enum.IsDefined(typeof(ShipClass), ship)) return Fail("Classe de nave desconhecida.", out message);
            if (!IsHangar(state.location)) return Fail("Troque de nave em Nova Terra ou na estação.", out message);
            if (!state.ownedShips.Contains(ship)) return Fail("Compre a nave antes de pilotá-la.", out message);
            if (state.activeShip == ship) return Fail("Essa nave já está selecionada.", out message);
            int capacity = ShipCatalog.Get(ship).capacity + state.upgrades * 4 + (HasCrew(state, "cargo") ? 8 : 0);
            if (CargoUsed(state) > capacity) return Fail("A carga atual não cabe nessa nave.", out message);
            state.activeShip = ship;
            // Fuel is transferred, never created by switching ships.
            state.fuel = Math.Min(state.fuel, ShipCatalog.Get(ship).fuelCapacity);
            return Success("Nave ativa: " + ShipCatalog.Get(ship).displayName + ".", out message);
        }

        public static bool TryHire(GameState state, string role, out string message)
        {
            if (!Ready(state, out message)) return false;
            string canonical = NormalizeRole(role);
            if (canonical == null) return Fail("Especialidade de tripulante desconhecida.", out message);
            if (!IsHangar(state.location)) return Fail("Contrate tripulantes em Nova Terra ou na estação.", out message);
            if (HasCrew(state, canonical)) return Fail("Você já possui um tripulante dessa especialidade.", out message);
            int price = RoleHirePrice(canonical);
            if (state.credits < price) return Fail("A contratação custa " + price + " créditos.", out message);
            state.credits -= price;
            state.crew.Add(new CrewMember
            {
                id = canonical, name = CrewName(canonical), role = canonical,
                level = 1, wage = RoleWage(canonical), skill = 0.2f
            });
            return Success(CrewName(canonical) + " contratado(a). Salário por viagem: " + RoleWage(canonical) + ".", out message);
        }

        public static bool TryTravel(GameState state, Destination target, out string message)
        {
            if (!Ready(state, out message)) return false;
            if (!Enum.IsDefined(typeof(Destination), target)) return Fail("Destino desconhecido.", out message);
            if (state.location == target) return Fail("Você já está nesse destino.", out message);
            if (state.hull <= 0) return Fail("Casco avariado: solicite resgate de emergência.", out message);
            float fuel = TravelFuelCost(state, target);
            int wages = CrewWages(state);
            if (state.fuel < fuel) return Fail("Combustível insuficiente. Reabasteça ou solicite resgate.", out message);
            if (state.credits < wages) return Fail("São necessários " + wages + " créditos para os salários desta viagem.", out message);
            // All prerequisites are checked before any payment or movement occurs.
            state.fuel -= fuel;
            state.credits -= wages;
            state.hull = Math.Max(0, state.hull - (HasCrew(state, "engineer") ? 1 : 2));
            state.location = target;
            return Success("Viagem concluída. Combustível: -" + fuel + "; salários: -" + wages + ".", out message);
        }

        public static bool Investigate(GameState state, string clueId, out string message)
        {
            if (!Ready(state, out message)) return false;
            if (state.explorationStage >= Clues.Length) return Fail("O mistério já foi resolvido; a recompensa é única.", out message);
            if (clueId != Clues[state.explorationStage]) return Fail("Faltam pistas anteriores para interpretar esta descoberta.", out message);
            Destination required = state.explorationStage == 0 ? Destination.Debris : Destination.Uncharted;
            if (state.location != required) return Fail("A pista precisa ser investigada no setor correspondente.", out message);
            if (state.explorationStage == 3 && !HasSpace(state, 1)) return Fail("Libere uma unidade de porão para o artefato.", out message);

            int stage = state.explorationStage++;
            state.discoveries.Add(Clues[stage]);
            switch (stage)
            {
                case 0: return Success("Uma gravação nos destroços cita uma estrela pálida e um mundo além das rotas comerciais.", out message);
                case 1: return Success("A triangulação delimita uma região: procure três pilares sob a sombra de uma cratera.", out message);
                case 2: return Success("Nas ruínas, o relevo mostra um arco partido voltado para o brilho azul. O sinal vem além dele.", out message);
                default:
                    AddCargo(state, ArtifactCargoId, 1);
                    AddCredits(state, ExplorationReward);
                    return Success("Tesouro encontrado: um artefato antigo e +2200 créditos de descoberta.", out message);
            }
        }

        /// <summary>
        /// Prevents a stranded save from becoming unplayable. Rescue loses trade cargo,
        /// dismisses the crew, charges up to 200 credits and returns to Nova Terra with
        /// 60% fuel and at least 50% hull. Quest cargo and the unique artifact survive.
        /// </summary>
        public static bool TryEmergencyRescue(GameState state, out string message)
        {
            if (!Ready(state, out message)) return false;
            float cheapest = float.MaxValue;
            foreach (Destination destination in Enum.GetValues(typeof(Destination)))
                if (destination != state.location) cheapest = Math.Min(cheapest, TravelFuelCost(state, destination));
            if (state.hull > 0 && state.fuel >= cheapest && state.credits >= CrewWages(state))
                return Fail("A nave pode viajar; o resgate atende somente emergências.", out message);
            state.credits = Math.Max(0, state.credits - 200);
            state.location = Destination.NovaTerra;
            state.crew.Clear();
            RemoveCargo(state, SalvageCargoId);
            RemoveCargo(state, RareCargoId);
            // A cargo operator may have made a tiny ship large enough for both quest
            // items. Return to the starter ship if losing that bonus would delete one.
            int protectedCargo = (state.deliveryStage == MissionStage.Accepted ? DeliveryQuantity : 0)
                + (state.explorationStage == 4 ? Math.Min(Quantity(state, ArtifactCargoId), 1) : 0);
            if (protectedCargo > CargoCapacity(state)) state.activeShip = ShipClass.Scout;
            float tank = ShipCatalog.Get(state.activeShip).fuelCapacity;
            state.fuel = Math.Min(tank, Math.Max(state.fuel, tank * 0.6f));
            state.hull = Math.Max(state.hull, 50);
            NormalizeCargo(state);
            return Success("Resgate concluído em Nova Terra. A tripulação foi dispensada e a carga comercial cobriu parte do resgate; contrato e artefato preservados.", out message);
        }

        private static bool TrySell(GameState state, string cargoId, int price, string label, out string message)
        {
            if (!Ready(state, out message)) return false;
            if (!IsPort(state.location)) return Fail("Venda carga em Nova Terra, na estação ou no planeta industrial.", out message);
            int quantity = Quantity(state, cargoId);
            if (quantity <= 0) return Fail("Você não possui " + label + " para vender.", out message);
            long proceeds = (long)quantity * price;
            RemoveCargo(state, cargoId);
            AddCredits(state, proceeds);
            return Success("Venda de " + label + ": +" + proceeds + " créditos.", out message);
        }

        private static bool Ready(GameState state, out string message)
        {
            message = string.Empty;
            if (state == null || state.version != CurrentVersion || state.cargo == null || state.crew == null
                || state.ownedShips == null || state.discoveries == null
                || !Enum.IsDefined(typeof(ShipClass), state.activeShip)
                || !Enum.IsDefined(typeof(Destination), state.location)
                || !Enum.IsDefined(typeof(MissionStage), state.deliveryStage)
                || state.credits < 0 || !Finite(state.fuel) || !Finite(state.hull)
                || state.fuel < 0 || state.hull < 0 || state.explorationStage < 0 || state.explorationStage > 4)
                return Fail("Estado inválido: valide o arquivo salvo antes de continuar.", out message);
            return true;
        }

        private static void NormalizeCargo(GameState state)
        {
            var normalized = new List<CargoStack>();
            int remaining = CargoCapacity(state);
            if (state.deliveryStage == MissionStage.Accepted)
            {
                normalized.Add(new CargoStack { id = DeliveryCargoId, quantity = DeliveryQuantity });
                remaining -= DeliveryQuantity;
            }
            foreach (string id in new[] { ArtifactCargoId, RareCargoId, SalvageCargoId })
            {
                int amount = Math.Min(Math.Max(remaining, 0), Quantity(state, id));
                if (id == ArtifactCargoId) amount = Math.Min(amount, state.explorationStage == 4 ? 1 : 0);
                if (amount <= 0) continue;
                normalized.Add(new CargoStack { id = id, quantity = amount });
                remaining -= amount;
            }
            state.cargo = normalized;
        }

        private static bool HasSpace(GameState state, int quantity)
        {
            return quantity >= 0 && (long)CargoUsed(state) + quantity <= CargoCapacity(state);
        }

        private static int Quantity(GameState state, string id)
        {
            long quantity = 0;
            if (state.cargo != null)
                foreach (var stack in state.cargo)
                    if (stack != null && stack.id == id && stack.quantity > 0) quantity += stack.quantity;
            return (int)Math.Min(int.MaxValue, quantity);
        }

        private static void AddCargo(GameState state, string id, int quantity)
        {
            var stack = state.cargo.Find(c => c != null && c.id == id);
            if (stack == null) state.cargo.Add(new CargoStack { id = id, quantity = quantity });
            else stack.quantity += quantity;
        }

        private static void RemoveCargo(GameState state, string id)
        {
            state.cargo.RemoveAll(c => c != null && c.id == id);
        }

        private static void AddCredits(GameState state, long amount)
        {
            state.credits = (int)Math.Min(MaximumCredits, state.credits + amount);
        }

        private static bool HasCrew(GameState state, string role)
        {
            return state != null && state.crew != null && state.crew.Exists(c => c != null && c.role == role);
        }

        private static string NormalizeRole(string role)
        {
            if (string.IsNullOrWhiteSpace(role)) return null;
            switch (role.Trim().ToLowerInvariant())
            {
                case "pilot": case "piloto": return "pilot";
                case "engineer": case "engenheiro": case "mecânico": case "mecanico": return "engineer";
                case "cargo": case "operador": case "operador de carga": return "cargo";
                case "explorer": case "explorador": case "scientist": case "cientista": return "explorer";
                default: return null;
            }
        }

        private static string CrewName(string role)
        {
            switch (role)
            {
                case "pilot": return "Lia, piloto";
                case "engineer": return "Caio, mecânico";
                case "cargo": return "Ravi, operador de carga";
                default: return "Nara, exploradora";
            }
        }

        private static int RoleWage(string role)
        {
            switch (role)
            {
                case "pilot": return 35;
                case "engineer": return 30;
                case "cargo": return 25;
                default: return 40;
            }
        }

        private static int RoleHirePrice(string role)
        {
            switch (role)
            {
                case "pilot": return 250;
                case "engineer": return 220;
                case "cargo": return 180;
                default: return 280;
            }
        }

        private static bool IsPort(Destination destination)
        {
            return destination == Destination.NovaTerra || destination == Destination.Industrial || destination == Destination.Station;
        }

        private static bool IsHangar(Destination destination)
        {
            return destination == Destination.NovaTerra || destination == Destination.Station;
        }

        private static int Clamp(int value, int minimum, int maximum) { return Math.Max(minimum, Math.Min(maximum, value)); }
        private static bool Finite(float value) { return !float.IsNaN(value) && !float.IsInfinity(value); }
        private static float CleanFloat(float value, float minimum, float maximum) { return Finite(value) ? Math.Max(minimum, Math.Min(maximum, value)) : minimum; }
        private static bool Fail(string text, out string message) { message = text; return false; }
        private static bool Success(string text, out string message) { message = text; return true; }
    }
}
